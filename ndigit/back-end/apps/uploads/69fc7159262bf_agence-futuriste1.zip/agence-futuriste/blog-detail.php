<?php 
require_once 'includes/header.php'; 
require_once 'config/db.php'; 
require_once 'includes/functions.php';

$slug = $_GET['slug'] ?? '';

$tous_articles = [
    ['titre'=>'IA Générative et Web Dev 2025','slug'=>'ia-webdev-2025','excerpt'=>'Comment GPT-4 et Claude transforment la façon dont nous codons.','categorie'=>'Dev','image'=>'projet1.jpg','temps_lecture'=>12,'created_at'=>date('Y-m-d'),'auteur'=>'Alice Leclerc','contenu'=>'<p>L\'IA générative a révolutionné le développement web en 2024-2025. Vous écrivez les commentaires, l\'IA génère le code. Productivité en hausse de +300%.</p><p>Chez FUTURISTE, nous utilisons Claude Code Assistant sur tous nos nouveaux projets. Les résultats sont concluants : moins de bugs, plus de features livrées en moins de temps.</p><h2>Comment ça fonctionne ?</h2><p>L\'IA analyse le contexte de votre code, comprend vos intentions via les commentaires et génère du code propre et optimisé. Le développeur reste maître de la logique métier.</p><h2>Notre verdict</h2><p>Indispensable en 2025. Tout développeur qui n\'utilise pas l\'IA perd un avantage concurrentiel majeur. Nous recommandons Claude Code pour sa précision et sa compréhension du contexte.</p>'],
    ['titre'=>'Three.js 2025 - Nouvelles Features','slug'=>'threejs-2025','excerpt'=>'Mesh instancing, shadows dynamiques avancées, performance 2x plus rapide.','categorie'=>'3D/WebGL','image'=>'projet2.jpg','temps_lecture'=>8,'created_at'=>date('Y-m-d',strtotime('-1 day')),'auteur'=>'Claude Petit','contenu'=>'<p>Three.js sort sa version majeure avec des améliorations considérables pour les développeurs 3D web.</p><h2>Mesh Instancing</h2><p>Le mesh instancing permet désormais d\'afficher plus d\'un million d\'objets 3D simultanément avec des performances optimales. Idéal pour les visualisations de données massives.</p><h2>Shadows Dynamiques</h2><p>Les ombres dynamiques sont enfin fluides et réalistes. Le nouveau système de shadow mapping réduit les artefacts visuels de 80%.</p><h2>Support WebGPU</h2><p>Le support WebGPU (expérimental) ouvre la porte à des performances 10x supérieures au WebGL classique. L\'avenir du 3D web commence maintenant.</p>'],
    ['titre'=>'Migration E-Commerce: 0 → 2M visites/mois','slug'=>'ecommerce-growth-story','excerpt'=>'Case study complet. Avant: Legacy PHP lent. Après: Next.js et AI recommendations.','categorie'=>'Case Study','image'=>'projet3.jpg','temps_lecture'=>15,'created_at'=>date('Y-m-d',strtotime('-2 days')),'auteur'=>'Marc Delorme','contenu'=>'<p>Un client fintech avait un e-commerce legacy en PHP faisant 10 000 visites par mois. Voici comment nous l\'avons transformé en machine à croissance.</p><h2>Le problème</h2><p>Site lent (LCP &gt; 8 secondes), pas de personnalisation, UX datée de 2015. Taux de conversion : 0,8%. Revenu stagnant depuis 3 ans.</p><h2>Notre solution</h2><p>Refonte complète en Next.js pour le frontend, Node.js pour le backend, et un modèle ML maison pour les recommandations personnalisées.</p><h2>Les résultats en 6 mois</h2><p>2 millions de visites par mois, conversion à +340%, revenu en hausse de +500%. ROI du projet atteint en 4 mois.</p>'],
    ['titre'=>'Flutter vs React Native 2025','slug'=>'flutter-vs-react-native','excerpt'=>'Comparaison approfondie. Flutter gagne sur performance. React Native sur écosystème.','categorie'=>'Mobile','image'=>'projet4.jpg','temps_lecture'=>10,'created_at'=>date('Y-m-d',strtotime('-3 days')),'auteur'=>'Guillaume Durand','contenu'=>'<p>Le débat sur le développement mobile cross-platform continue en 2025. Voici notre analyse après avoir livré 20+ apps avec les deux technologies.</p><h2>Flutter : les points forts</h2><p>Performance supérieure avec un rendu natif à 60fps constants. Interface cohérente sur iOS et Android. Dart est un langage agréable à écrire.</p><h2>React Native : les points forts</h2><p>Écosystème JavaScript mature, réutilisation de code avec le web, communauté massive. Plus facile à recruter.</p><h2>Notre verdict 2025</h2><p>Flutter pour les apps performance-critical. React Native pour itérer rapidement et partager du code avec une webapp existante.</p>'],
    ['titre'=>'RAG Implementation Avancée','slug'=>'rag-advanced','excerpt'=>'Retrieval Augmented Generation sans hallucinations. Architecture production.','categorie'=>'IA/ML','image'=>'projet5.jpg','temps_lecture'=>18,'created_at'=>date('Y-m-d',strtotime('-4 days')),'auteur'=>'Sarah Bouvier','contenu'=>'<p>Le RAG (Retrieval Augmented Generation) est la technique qui permet aux LLM d\'accéder à vos données privées sans hallucinations.</p><h2>Comment fonctionne le RAG ?</h2><p>Vos documents sont découpés en chunks, vectorisés et stockés dans une base vectorielle. À chaque question, les chunks pertinents sont récupérés et injectés dans le contexte du LLM.</p><h2>Notre stack de production</h2><p>LangChain pour l\'orchestration, Pinecone comme base vectorielle, Claude comme LLM. Latence moyenne : moins de 500ms par requête.</p><h2>Résultats clients</h2><p>Déployé pour 5 clients. Précision des réponses : 99,2%. Zéro hallucination sur les données métier critiques.</p>'],
    ['titre'=>'CSS 2025 Features Vous Manquez','slug'=>'css-2025-features','excerpt'=>'Container queries, sélecteur :has(), CSS nesting natif. Le futur du design web est là.','categorie'=>'Frontend','image'=>'projet6.jpg','temps_lecture'=>7,'created_at'=>date('Y-m-d',strtotime('-5 days')),'auteur'=>'Émilie Moreau','contenu'=>'<p>CSS évolue à une vitesse impressionnante. Voici les features que vous devriez utiliser dès aujourd\'hui.</p><h2>Container Queries</h2><p>Enfin ! Les container queries permettent de créer des composants vraiment responsive basés sur la taille de leur conteneur parent, pas du viewport.</p><h2>Le sélecteur :has()</h2><p>Le "sélecteur parent" tant attendu. Vous pouvez maintenant styler un élément en fonction de ses enfants. Révolutionnaire.</p><h2>CSS Nesting Natif</h2><p>Plus besoin de Sass pour le nesting. CSS supporte nativement l\'imbrication de sélecteurs avec une syntaxe propre et lisible.</p>'],
    ['titre'=>'Erreurs Smart Contracts Coûtent Cher','slug'=>'smart-contract-errors','excerpt'=>'Top 10 bugs Solidity. Reentrancy, overflow, gas optimization fails.','categorie'=>'Web3','image'=>'projet7.jpg','temps_lecture'=>14,'created_at'=>date('Y-m-d',strtotime('-6 days')),'auteur'=>'Amélie Fontaine','contenu'=>'<p>Les erreurs dans les smart contracts ont coûté des milliards de dollars à l\'écosystème crypto. Voici les bugs les plus critiques à éviter.</p><h2>1. Reentrancy Attack</h2><p>La fameuse attaque qui a causé le hack TheDAO en 2016 (60M$). Un contrat malveillant rappelle votre fonction avant que le premier appel soit terminé.</p><h2>2. Integer Overflow</h2><p>Avant Solidity 0.8, les dépassements d\'entiers n\'étaient pas gérés automatiquement. Toujours utiliser SafeMath ou Solidity 0.8+.</p><h2>Notre processus</h2><p>Audit de code obligatoire par un tiers avant tout déploiement en production. Nous utilisons Slither et MythX pour l\'analyse statique automatique.</p>'],
    ['titre'=>'UX Research: 10K Utilisateurs Testés','slug'=>'ux-research-10k','excerpt'=>'Méthodologie research complète. Insights qui changent tout. Le testing continu sauve les projets.','categorie'=>'UX/Design','image'=>'projet1.jpg','temps_lecture'=>9,'created_at'=>date('Y-m-d',strtotime('-7 days')),'auteur'=>'Émilie Moreau','contenu'=>'<p>Nous avons testé plus de 10 000 utilisateurs sur l\'ensemble de nos projets. Voici ce que nous avons appris.</p><h2>Notre méthodologie</h2><p>Surveys quantitatifs, heatmaps Hotjar, session recordings, interviews qualitatives. Chaque projet passe par minimum 3 rounds de tests utilisateurs.</p><h2>Les insights qui changent tout</h2><p>80% des utilisateurs abandonnent un formulaire si plus de 5 champs. Les CTA en vert convertissent 23% mieux que ceux en bleu. Le mobile représente 73% du trafic.</p><h2>Testing continu</h2><p>Le testing n\'est pas un événement, c\'est un processus. Nos clients qui testent chaque mois voient leur conversion augmenter de 5 à 15% par trimestre.</p>'],
    ['titre'=>'Microservices vs Monolithe 2025','slug'=>'microservices-vs-monolith','excerpt'=>'Quand utiliser quoi? Monolithe rapide pour MVP. Microservices pour scale.','categorie'=>'Architecture','image'=>'projet2.jpg','temps_lecture'=>11,'created_at'=>date('Y-m-d',strtotime('-8 days')),'auteur'=>'Guillaume Durand','contenu'=>'<p>Le débat architectural le plus important de la décennie. Voici notre analyse complète après des dizaines de projets des deux côtés.</p><h2>Le Monolithe : sous-estimé</h2><p>Simple à développer, déployer et debugger. Idéal pour les MVPs et les équipes de moins de 10 développeurs. Netflix et Shopify ont commencé en monolithe.</p><h2>Les Microservices : quand ça vaut le coup</h2><p>Scalabilité indépendante par service, technologies différentes par équipe, résilience améliorée. Mais complexité opérationnelle x10.</p><h2>Notre recommandation</h2><p>Commencez en monolithe bien structuré (3 à 6 mois), puis migrez vers les microservices si vous avez un vrai besoin de scale. Ne sur-architecturez pas trop tôt.</p>'],
];

$article = null;
foreach($tous_articles as $a) {
    if($a['slug'] === $slug) {
        $article = $a;
        break;
    }
}

if(!$article) {
    header('Location: blog.php');
    exit;
}

$articles_similaires = array_values(array_filter(
    $tous_articles,
    fn($a) => $a['slug'] !== $article['slug']
));
$articles_similaires = array_slice($articles_similaires, 0, 3);
?>

<main>
    <section class="article-hero" style="background-image: linear-gradient(180deg, rgba(2,4,8,0.25) 0%, rgba(2,4,8,0.72) 45%, rgba(2,4,8,0.96) 100%), url('assets/images/<?= htmlspecialchars($article['image']) ?>');">
        <canvas id="blog-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="container article-hero-inner">
            <nav class="breadcrumb" aria-label="Fil d'Ariane">
                <a href="index.php">Accueil</a>
                <span>&gt;</span>
                <a href="blog.php">Blog</a>
                <span>&gt;</span>
                <span><?= htmlspecialchars($article['categorie']) ?></span>
            </nav>

            <a href="blog.php" class="back-link">← Retour au blog</a>

            <span class="category-pill"><?= htmlspecialchars($article['categorie']) ?></span>

            <h1 class="article-title-premium"><?= htmlspecialchars($article['titre']) ?></h1>
            <p class="article-hero-excerpt"><?= htmlspecialchars($article['excerpt']) ?></p>

            <div class="article-meta-row">
                <span>Auteur : <?= htmlspecialchars($article['auteur'] ?? 'FUTURISTE') ?></span>
                <span>Publié le : <?= htmlspecialchars(date('d/m/Y', strtotime($article['created_at']))) ?></span>
                <span>Temps de lecture : <?= htmlspecialchars((string) $article['temps_lecture']) ?> min</span>
            </div>
        </div>
    </section>

    <section class="section article-layout-section">
        <div class="container article-layout">
            <div class="article-main-column">
                <div class="glass article-intro-card">
                    <p><?= htmlspecialchars($article['excerpt']) ?></p>
                </div>

                <article class="article-body-premium glass">
                    <?= $article['contenu'] ?>
                </article>
            </div>

            <aside class="article-sidebar">
                <div class="glass sidebar-card">
                    <h3>À propos de l'auteur</h3>
                    <div class="author-box">
                        <div class="author-avatar"><?= htmlspecialchars(strtoupper(substr($article['auteur'] ?? 'F', 0, 1))) ?></div>
                        <div>
                            <p class="author-name"><?= htmlspecialchars($article['auteur'] ?? 'FUTURISTE') ?></p>
                            <p class="author-role">Expert FUTURISTE en stratégie digitale, innovation produit et expériences premium.</p>
                        </div>
                    </div>
                </div>

                <div class="glass sidebar-card">
                    <h3>Partager l'article</h3>
                    <div class="share-buttons">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode('http://localhost/agence-futuriste/blog-detail.php?slug=' . ($article['slug'] ?? '')) ?>" target="_blank" rel="noopener noreferrer">Facebook</a>
                        <a href="https://twitter.com/intent/tweet?url=<?= urlencode('http://localhost/agence-futuriste/blog-detail.php?slug=' . ($article['slug'] ?? '')) ?>&text=<?= urlencode($article['titre'] ?? '') ?>" target="_blank" rel="noopener noreferrer">Twitter</a>
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= urlencode('http://localhost/agence-futuriste/blog-detail.php?slug=' . ($article['slug'] ?? '')) ?>" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                    </div>
                </div>

                <div class="glass sidebar-card">
                    <h3>Articles récents</h3>
                    <div class="recent-links">
                        <?php foreach ($articles_similaires as $similaire): ?>
                            <a href="blog-detail.php?slug=<?= htmlspecialchars($similaire['slug']) ?>">
                                <span><?= htmlspecialchars($similaire['titre']) ?></span>
                                <small><?= htmlspecialchars($similaire['categorie']) ?></small>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </aside>
        </div>
    </section>

    <section class="section more-section">
        <div class="container">
            <div class="section-heading">
                <span class="eyebrow">Recommandations</span>
                <h2>Vous aimerez aussi</h2>
            </div>

            <div class="more-grid">
                <?php foreach ($articles_similaires as $index => $similaire): ?>
                    <article class="glass more-card" style="animation: fadeInUp 0.8s ease forwards; animation-delay: <?= 0.1 * $index ?>s; opacity: 0;">
                        <a href="blog-detail.php?slug=<?= htmlspecialchars($similaire['slug']) ?>" class="more-card-link">
                            <div class="more-card-image" style="background-image: linear-gradient(180deg, rgba(2,4,8,0.1), rgba(2,4,8,0.8)), url('assets/images/<?= htmlspecialchars($similaire['image']) ?>');">
                                <span class="category-pill small"><?= htmlspecialchars($similaire['categorie']) ?></span>
                            </div>
                            <div class="more-card-body">
                                <h3><?= htmlspecialchars($similaire['titre']) ?></h3>
                                <p><?= htmlspecialchars($similaire['excerpt']) ?></p>
                                <div class="more-meta">
                                    <span><?= htmlspecialchars($similaire['auteur'] ?? 'FUTURISTE') ?></span>
                                    <span><?= htmlspecialchars((string) $similaire['temps_lecture']) ?> min</span>
                                </div>
                            </div>
                        </a>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
</main>

<style>
.article-hero {
    position: relative;
    min-height: 60vh;
    display: flex;
    align-items: flex-end;
    background-size: cover;
    background-position: center;
    overflow: hidden;
}

.article-hero-inner {
    position: relative;
    z-index: 2;
    width: 100%;
    padding-top: 140px;
    padding-bottom: 4rem;
}

.breadcrumb {
    display: flex;
    gap: 0.7rem;
    align-items: center;
    flex-wrap: wrap;
    margin-bottom: 1rem;
    color: #a0a9c4;
    font-size: 0.95rem;
}

.breadcrumb a {
    color: #a0a9c4;
    text-decoration: none;
}

.breadcrumb a:hover,
.back-link:hover {
    color: #00FFFF;
}

.back-link {
    display: inline-block;
    color: #00FFFF;
    text-decoration: none;
    font-weight: 600;
    margin-bottom: 1.5rem;
}

.category-pill {
    display: inline-flex;
    align-items: center;
    background: linear-gradient(135deg, #00FFFF, #7B2FFF);
    color: #020408;
    padding: 0.45rem 0.9rem;
    border-radius: 999px;
    font-size: 0.8rem;
    font-weight: 700;
    margin-bottom: 1.25rem;
}

.category-pill.small {
    margin: 1rem;
    padding: 0.35rem 0.7rem;
    font-size: 0.72rem;
}

.article-title-premium {
    max-width: 940px;
    color: #FFFFFF;
    font-family: 'Orbitron', sans-serif;
    font-size: clamp(2.4rem, 5vw, 4.3rem);
    line-height: 1.08;
    margin-bottom: 1rem;
}

.article-hero-excerpt {
    max-width: 760px;
    color: #a0a9c4;
    font-size: 1.1rem;
    line-height: 1.8;
    margin-bottom: 1.75rem;
}

.article-meta-row {
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
    color: #FFFFFF;
    font-size: 0.95rem;
}

.article-layout-section {
    background:
        radial-gradient(circle at top left, rgba(0,255,255,0.05), transparent 35%),
        radial-gradient(circle at top right, rgba(123,47,255,0.08), transparent 32%),
        #020408;
}

.article-layout {
    display: grid;
    grid-template-columns: minmax(0, 7fr) minmax(280px, 3fr);
    gap: 2rem;
    align-items: start;
}

.article-main-column,
.article-sidebar {
    min-width: 0;
}

.article-intro-card,
.article-body-premium,
.sidebar-card,
.more-card {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
}

.article-intro-card {
    padding: 2rem;
    border-radius: 18px;
    margin-bottom: 1.5rem;
    border-left: 3px solid #00FFFF;
}

.article-intro-card p {
    color: #FFFFFF;
    font-size: 1.15rem;
    line-height: 1.9;
    margin: 0;
}

.article-body-premium {
    padding: 2.5rem;
    border-radius: 22px;
    color: #a0a9c4;
    line-height: 1.95;
    font-size: 1.05rem;
}

.article-body-premium h2 {
    color: #FFFFFF;
    font-family: 'Orbitron', sans-serif;
    font-size: 1.45rem;
    line-height: 1.3;
    margin: 2.5rem 0 1rem;
    padding-left: 1rem;
    border-left: 3px solid #00FFFF;
}

.article-body-premium p {
    margin-bottom: 1.4rem;
}

.article-sidebar {
    display: grid;
    gap: 1.25rem;
    position: sticky;
    top: 120px;
}

.sidebar-card {
    border-radius: 18px;
    padding: 1.6rem;
}

.sidebar-card h3 {
    margin: 0 0 1rem;
    color: #FFFFFF;
    font-family: 'Orbitron', sans-serif;
    font-size: 1rem;
}

.author-box {
    display: flex;
    gap: 1rem;
    align-items: flex-start;
}

.author-avatar {
    width: 58px;
    height: 58px;
    border-radius: 50%;
    background: linear-gradient(135deg, #00FFFF, #7B2FFF);
    color: #020408;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Orbitron', sans-serif;
    font-weight: 900;
    flex-shrink: 0;
}

.author-name {
    color: #FFFFFF;
    font-weight: 700;
    margin: 0 0 0.35rem;
}

.author-role {
    color: #a0a9c4;
    margin: 0;
    line-height: 1.7;
    font-size: 0.95rem;
}

.share-buttons {
    display: grid;
    gap: 0.75rem;
}

.share-buttons a,
.recent-links a {
    text-decoration: none;
    color: #FFFFFF;
    background: linear-gradient(135deg, rgba(0,255,255,0.08), rgba(123,47,255,0.08));
    border: 1px solid rgba(0,255,255,0.16);
    border-radius: 12px;
    padding: 0.85rem 1rem;
    transition: transform 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
}

.share-buttons a:hover,
.recent-links a:hover,
.more-card:hover {
    transform: translateY(-3px);
    border-color: rgba(0,255,255,0.35);
    box-shadow: 0 0 24px rgba(0,255,255,0.12);
}

.recent-links {
    display: grid;
    gap: 0.85rem;
}

.recent-links a {
    display: block;
}

.recent-links a span {
    display: block;
    font-weight: 700;
    margin-bottom: 0.25rem;
}

.recent-links a small {
    color: #a0a9c4;
}

.more-section {
    background:
        linear-gradient(180deg, rgba(123,47,255,0.04), transparent 55%),
        #020408;
}

.section-heading {
    margin-bottom: 2rem;
}

.section-heading .eyebrow {
    display: inline-block;
    color: #FF2D78;
    text-transform: uppercase;
    letter-spacing: 0.18em;
    font-size: 0.78rem;
    margin-bottom: 0.75rem;
}

.section-heading h2 {
    margin: 0;
    color: #FFFFFF;
    font-family: 'Orbitron', sans-serif;
    font-size: clamp(1.9rem, 4vw, 3rem);
}

.more-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 1.5rem;
}

.more-card {
    border-radius: 20px;
    overflow: hidden;
    transition: transform 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
}

.more-card-link {
    color: inherit;
    text-decoration: none;
    display: block;
}

.more-card-image {
    height: 220px;
    background-size: cover;
    background-position: center;
    display: flex;
    align-items: flex-start;
}

.more-card-body {
    padding: 1.4rem;
}

.more-card-body h3 {
    margin: 0 0 0.8rem;
    color: #FFFFFF;
    font-size: 1.1rem;
    line-height: 1.4;
}

.more-card-body p {
    margin: 0 0 1rem;
    color: #a0a9c4;
    line-height: 1.7;
}

.more-meta {
    display: flex;
    justify-content: space-between;
    gap: 1rem;
    color: #00ff88;
    font-size: 0.85rem;
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}

@media (max-width: 1024px) {
    .article-layout,
    .more-grid {
        grid-template-columns: 1fr;
    }

    .article-sidebar {
        position: static;
    }
}

@media (max-width: 768px) {
    .article-hero-inner {
        padding-bottom: 3rem;
    }

    .article-body-premium,
    .article-intro-card,
    .sidebar-card {
        padding: 1.4rem;
    }

    .article-meta-row {
        gap: 0.75rem;
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>
