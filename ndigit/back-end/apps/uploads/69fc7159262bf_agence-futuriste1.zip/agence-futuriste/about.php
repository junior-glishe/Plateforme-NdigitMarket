<?php 
require_once 'includes/header.php'; 
require_once 'config/db.php'; 
require_once 'includes/functions.php';
$page_script = 'assets/js/about.js';
?>

<main>
    <!-- HERO SECTION -->
    <section class="hero" style="padding-top: 120px;">
        <canvas id="about-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container" style="position: relative; z-index: 2;">
            <h1 class="hero-title" style="color: #FFFFFF; -webkit-text-fill-color: #FFFFFF; background: none; text-shadow: 0 0 40px rgba(255,255,255,0.3), 0 0 80px rgba(0,255,255,0.15);">NOTRE ADN</h1>
            <p class="hero-subtitle" style="font-size: 1.3rem; max-width: 900px; margin: 0 auto;">
                Depuis 2016, nous repoussons les limites du possible digital. Chaque pixel, chaque ligne de code est pensée pour transformer votre vision en expérience mémorable.
            </p>
        </div>
    </section>

    <!-- TIMELINE SECTION -->
    <section class="section" style="background: rgba(123,47,255,0.03);">
        <div class="container">
            <h2 class="section-title text-gradient" style="text-align: center; margin-bottom: 4rem;">NOTRE HISTOIRE</h2>
            
            <div style="position: relative; max-width: 900px; margin: 0 auto;">
                <!-- Timeline SVG vertical line -->
                <svg style="position: absolute; left: 50%; top: 0; bottom: 0; width: 2px; transform: translateX(-50%); z-index: 0;" preserveAspectRatio="none">
                    <line x1="1" y1="0" x2="1" y2="100%" stroke="rgba(0,255,255,0.2)" stroke-width="2" />
                </svg>

                <!-- 2016 -->
                <div style="display: flex; margin-bottom: 4rem; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0s;">
                    <div style="width: 50%; text-align: right; padding-right: 3rem;">
                        <h3 style="font-family: 'Orbitron'; font-size: 1.5rem; color: #00FFFF; margin-bottom: 0.5rem;">2016</h3>
                        <h4 style="font-size: 1.1rem; margin-bottom: 1rem;">Fondation FUTURISTE</h4>
                        <p style="color: var(--text-muted); line-height: 1.6;">3 développeurs passionnés, un garage à Paris, une obsession : créer le web de demain. Premier client : une startup fintech qui cherchait l'impossible.</p>
                    </div>
                    <div style="width: 50%;"></div>
                </div>

                <!-- 2017 -->
                <div style="display: flex; margin-bottom: 4rem; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.2s;">
                    <div style="width: 50%;"></div>
                    <div style="width: 50%; padding-left: 3rem;">
                        <h3 style="font-family: 'Orbitron'; font-size: 1.5rem; color: #7B2FFF; margin-bottom: 0.5rem;">2017</h3>
                        <h4 style="font-size: 1.1rem; margin-bottom: 1rem;">Premier Grand Projet</h4>
                        <p style="color: var(--text-muted); line-height: 1.6;">Refonte complète de l'identité digitale d'une marque de luxe. Le site fait +340% de conversions. Les appels entrants explosent.</p>
                    </div>
                </div>

                <!-- 2018 -->
                <div style="display: flex; margin-bottom: 4rem; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.4s;">
                    <div style="width: 50%; text-align: right; padding-right: 3rem;">
                        <h3 style="font-family: 'Orbitron'; font-size: 1.5rem; color: #FF2D78; margin-bottom: 0.5rem;">2018</h3>
                        <h4 style="font-size: 1.1rem; margin-bottom: 1rem;">Division Web3 & Metaverse</h4>
                        <p style="color: var(--text-muted); line-height: 1.6;">Premiers smart contracts, premières expériences NFT pour LVMH et Balenciaga. On devient la référence FR du digital luxe.</p>
                    </div>
                    <div style="width: 50%;"></div>
                </div>

                <!-- 2020 -->
                <div style="display: flex; margin-bottom: 4rem; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.6s;">
                    <div style="width: 50%;"></div>
                    <div style="width: 50%; padding-left: 3rem;">
                        <h3 style="font-family: 'Orbitron'; font-size: 1.5rem; color: #00FF88; margin-bottom: 0.5rem;">2020</h3>
                        <h4 style="font-size: 1.1rem; margin-bottom: 1rem;">IA Studio Launch</h4>
                        <p style="color: var(--text-muted); line-height: 1.6;">Pendant que le monde s'arrête, on s'adapte. Lancement de notre division Machine Learning. 12 modèles IA déployés en 18 mois.</p>
                    </div>
                </div>

                <!-- 2022 -->
                <div style="display: flex; margin-bottom: 4rem; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.8s;">
                    <div style="width: 50%; text-align: right; padding-right: 3rem;">
                        <h3 style="font-family: 'Orbitron'; font-size: 1.5rem; color: #FFCC00; margin-bottom: 0.5rem;">2022</h3>
                        <h4 style="font-size: 1.1rem; margin-bottom: 1rem;">100 Projets AAA</h4>
                        <p style="color: var(--text-muted); line-height: 1.6;">SpaceX, BNP Paribas, L'Oréal, Airbus. Notre portfolio devient une référence internationale. 32 experts rejoignent l'équipe.</p>
                    </div>
                    <div style="width: 50%;"></div>
                </div>

                <!-- 2024 -->
                <div style="opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 1s;">
                    <div style="display: flex;">
                        <div style="width: 50%;"></div>
                        <div style="width: 50%; padding-left: 3rem;">
                            <h3 style="font-family: 'Orbitron'; font-size: 1.5rem; background: linear-gradient(135deg, #00FFFF, #7B2FFF); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; margin-bottom: 0.5rem;">2024</h3>
                            <h4 style="font-size: 1.1rem; margin-bottom: 1rem;">Vers le Web4</h4>
                            <p style="color: var(--text-muted); line-height: 1.6;">AR/VR, IA générative, interfaces cerveau-machine. On ne suit pas les tendances, on les crée. 150+ projets, 45 experts, 99.2% de satisfaction client.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- MISSION VISION VALUES -->
    <section class="section">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 3rem; margin-bottom: 4rem;">
                <!-- Mission -->
                <div class="glass" style="padding: 2rem; border-radius: 12px; backdrop-filter: blur(10px);">
                    <h3 style="font-family: 'Orbitron'; color: #00FFFF; margin-bottom: 1rem;">MISSION</h3>
                    <p style="line-height: 1.8; color: var(--text-muted);">Transformer chaque contrainte technique en avantage compétitif. Nos clients ne commandent pas un site web — ils investissent dans une arme de croissance digitale sur-mesure.</p>
                </div>

                <!-- Vision -->
                <div class="glass" style="padding: 2rem; border-radius: 12px; backdrop-filter: blur(10px);">
                    <h3 style="font-family: 'Orbitron'; color: #7B2FFF; margin-bottom: 1rem;">VISION</h3>
                    <p style="line-height: 1.8; color: var(--text-muted);">Être la première agence au monde à déployer des interfaces neuronales commerciales d'ici 2030. Nous préparons déjà les outils.</p>
                </div>

                <!-- Values teaser -->
                <div class="glass" style="padding: 2rem; border-radius: 12px; backdrop-filter: blur(10px);">
                    <h3 style="font-family: 'Orbitron'; color: #FF2D78; margin-bottom: 1rem;">VALEURS</h3>
                    <p style="line-height: 1.8; color: var(--text-muted);">Innovation radicale, Excellence obsessionnelle, Transparence totale, Passion contagieuse. Ces 4 piliers guident chaque décision.</p>
                </div>
            </div>

            <!-- Values detail grid -->
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 2rem;">
                <div style="border-left: 3px solid #00FFFF; padding-left: 2rem;">
                    <h4 style="color: #00FFFF; margin-bottom: 0.5rem;">Innovation Radicale</h4>
                    <p style="color: var(--text-muted); line-height: 1.6;">On refuse le copier-coller. Chaque projet repart d'une page blanche. Les solutions qu'on crée n'existent nulle part ailleurs.</p>
                </div>
                <div style="border-left: 3px solid #7B2FFF; padding-left: 2rem;">
                    <h4 style="color: #7B2FFF; margin-bottom: 0.5rem;">Excellence Obsessionnelle</h4>
                    <p style="color: var(--text-muted); line-height: 1.6;">99% ne suffit pas. On cherche le 99.9% à chaque livraison. Les détails font la différence.</p>
                </div>
                <div style="border-left: 3px solid #FF2D78; padding-left: 2rem;">
                    <h4 style="color: #FF2D78; margin-bottom: 0.5rem;">Transparence Totale</h4>
                    <p style="color: var(--text-muted); line-height: 1.6;">Vous savez où va chaque euro investi, à chaque étape du projet. Pas de surprises, jamais.</p>
                </div>
                <div style="border-left: 3px solid #00FF88; padding-left: 2rem;">
                    <h4 style="color: #00FF88; margin-bottom: 0.5rem;">Passion Contagieuse</h4>
                    <p style="color: var(--text-muted); line-height: 1.6;">On aime ce qu'on fait. Ça se voit dans chaque détail, chaque interaction, chaque pixel.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- TERMINAL STATS -->
    <section class="section" style="background: rgba(0,255,255,0.05);">
        <div class="container">
            <div style="background: #020408; border: 1px solid rgba(0,255,255,0.2); border-radius: 8px; padding: 2rem; font-family: 'Share Tech Mono'; font-size: 0.9rem; overflow-x: auto;">
                <div style="color: #00FFFF;">$ NEXUS_STATUS</div>
                <div style="color: #7A9BB5; margin: 1rem 0;">█████████████ OPERATIONAL</div>
                
                <div style="color: #00FFFF; margin-top: 1.5rem;">$ STATS_LIVE</div>
                <div style="color: #7A9BB5; display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-top: 1rem;">
                    <div>
                        <div style="color: #FFCC00;">PROJETS_DELIVERED</div>
                        <div style="font-size: 1.3rem; margin-top: 0.5rem;">157</div>
                    </div>
                    <div>
                        <div style="color: #00FFFF;">CLIENT_SATISFACTION</div>
                        <div style="font-size: 1.3rem; margin-top: 0.5rem;">99.2%</div>
                    </div>
                    <div>
                        <div style="color: #7B2FFF;">TECHNOS_MASTERED</div>
                        <div style="font-size: 1.3rem; margin-top: 0.5rem;">47</div>
                    </div>
                    <div>
                        <div style="color: #FF2D78;">AI_MODELS_DEPLOYED</div>
                        <div style="font-size: 1.3rem; margin-top: 0.5rem;">23</div>
                    </div>
                </div>
                
                <div style="color: #7A9BB5; display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-top: 1rem;">
                    <div>
                        <div style="color: #00FF88;">3D_SCENES_RENDERED</div>
                        <div style="font-size: 1.3rem; margin-top: 0.5rem;">892K+</div>
                    </div>
                    <div>
                        <div style="color: #FFB84D;">UPTIME_GUARANTEE</div>
                        <div style="font-size: 1.3rem; margin-top: 0.5rem;">99.9%</div>
                    </div>
                    <div>
                        <div style="color: #00FFFF;">COUNTRIES_SERVED</div>
                        <div style="font-size: 1.3rem; margin-top: 0.5rem;">18</div>
                    </div>
                    <div>
                        <div style="color: #FF6B9D;">AWARDS_WON</div>
                        <div style="font-size: 1.3rem; margin-top: 0.5rem;">12</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- TEAM NUMBERS -->
    <section class="section">
        <div class="container">
            <h2 class="section-title text-gradient" style="text-align: center; margin-bottom: 3rem;">L'ÉQUIPE EN CHIFFRES</h2>
            
            <div style="position: relative; border-radius: 12px; overflow: hidden; margin-bottom: 3rem; height: 300px; background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));">
                <img src="/agence-futuriste/assets/images/projet8.jpg" 
                     alt="Team FUTURISTE"
                     style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; opacity: 0.15; filter: blur(5px);"
                     onerror="this.style.display='none';">
                <div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; flex-direction: column; z-index: 2; text-align: center;">
                    <h3 style="font-size: 2.5rem; font-family: 'Orbitron'; margin-bottom: 1rem;">45 Experts</h3>
                    <p style="font-size: 1.1rem; color: var(--text-muted);">Répartis en 6 pôles spécialisés</p>
                </div>
            </div>

            <!-- Team specialties badges -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem;">
                <div class="glass" style="padding: 2rem; text-align: center; border-radius: 12px;">
                    <div style="background: linear-gradient(135deg, #00FFFF, #7B2FFF); width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #000;">FE</div>
                    <p style="font-weight: 600;">Frontend Elite</p>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 0.5rem;">React, Next.js, Three.js</p>
                </div>
                <div class="glass" style="padding: 2rem; text-align: center; border-radius: 12px;">
                    <div style="background: linear-gradient(135deg, #7B2FFF, #FF2D78); width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #fff;">BA</div>
                    <p style="font-weight: 600;">Backend Architects</p>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 0.5rem;">Node.js, Python, Rust</p>
                </div>
                <div class="glass" style="padding: 2rem; text-align: center; border-radius: 12px;">
                    <div style="background: linear-gradient(135deg, #FF2D78, #FFCC00); width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #000;">AI</div>
                    <p style="font-weight: 600;">IA Engineers</p>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 0.5rem;">TensorFlow, PyTorch, LLMs</p>
                </div>
                <div class="glass" style="padding: 2rem; text-align: center; border-radius: 12px;">
                    <div style="background: linear-gradient(135deg, #00FF88, #00FFFF); width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #000;">3D</div>
                    <p style="font-weight: 600;">3D Artists</p>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 0.5rem;">Blender, Unity, WebGL</p>
                </div>
                <div class="glass" style="padding: 2rem; text-align: center; border-radius: 12px;">
                    <div style="background: linear-gradient(135deg, #4495FF, #7B2FFF); width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #fff;">UX</div>
                    <p style="font-weight: 600;">UX Strategists</p>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 0.5rem;">Figma, Research, Testing</p>
                </div>
                <div class="glass" style="padding: 2rem; text-align: center; border-radius: 12px;">
                    <div style="background: linear-gradient(135deg, #FFB84D, #FF6B35); width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #fff;">DO</div>
                    <p style="font-weight: 600;">DevOps Masters</p>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 0.5rem;">Kubernetes, AWS, GCP</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA BOTTOM -->
    <section class="section" style="background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));">
        <div class="container" style="text-align: center;">
            <h2 style="font-size: 2rem; margin-bottom: 1.5rem;">Prêt à transformer votre vision digitale?</h2>
            <p style="color: var(--text-muted); margin-bottom: 2rem; font-size: 1.1rem;">Contactez-nous dès aujourd'hui pour une session de stratégie gratuite.</p>
            <a href="contact.php" class="btn btn-primary" style="display: inline-block; padding: 1rem 3rem; font-size: 1.1rem;">DÉMARRER UN PROJET</a>
        </div>
    </section>
</main>

<style>
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>
