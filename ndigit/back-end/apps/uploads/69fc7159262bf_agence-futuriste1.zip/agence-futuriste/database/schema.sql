CREATE DATABASE IF NOT EXISTS nexus_digital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nexus_digital;

CREATE TABLE articles (
  id INT PRIMARY KEY AUTO_INCREMENT,
  titre VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE NOT NULL,
  contenu LONGTEXT,
  extrait TEXT,
  image_url VARCHAR(500),
  categorie VARCHAR(100),
  auteur_id INT,
  tags JSON,
  vues INT DEFAULT 0,
  temps_lecture INT DEFAULT 5,
  publie TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE projets (
  id INT PRIMARY KEY AUTO_INCREMENT,
  titre VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE,
  description TEXT,
  description_longue LONGTEXT,
  client VARCHAR(255),
  categorie ENUM('web','mobile','branding','ia') NOT NULL,
  technos JSON,
  images JSON,
  url_live VARCHAR(500),
  featured TINYINT(1) DEFAULT 0,
  ordre INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE team_members (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nom VARCHAR(100),
  prenom VARCHAR(100),
  role VARCHAR(255),
  bio TEXT,
  photo_url VARCHAR(500),
  linkedin VARCHAR(500),
  github VARCHAR(500),
  twitter VARCHAR(500),
  couleur_accent VARCHAR(20) DEFAULT '#00FFFF',
  ordre INT DEFAULT 0,
  actif TINYINT(1) DEFAULT 1
);

CREATE TABLE temoignages (
  id INT PRIMARY KEY AUTO_INCREMENT,
  client_nom VARCHAR(255),
  client_entreprise VARCHAR(255),
  client_photo VARCHAR(500),
  contenu TEXT,
  note TINYINT CHECK (note BETWEEN 1 AND 5),
  service VARCHAR(100),
  valide TINYINT(1) DEFAULT 0
);

CREATE TABLE faq (
  id INT PRIMARY KEY AUTO_INCREMENT,
  question TEXT,
  reponse TEXT,
  categorie ENUM('general','technique','tarifs','support') DEFAULT 'general',
  ordre INT DEFAULT 0,
  actif TINYINT(1) DEFAULT 1
);

CREATE TABLE contact_messages (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nom VARCHAR(255),
  email VARCHAR(255),
  entreprise VARCHAR(255),
  budget VARCHAR(100),
  service VARCHAR(100),
  message TEXT,
  lu TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE services (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nom VARCHAR(255),
  slug VARCHAR(255),
  description TEXT,
  description_courte VARCHAR(500),
  icone VARCHAR(100),
  features JSON,
  ordre INT DEFAULT 0
);

CREATE TABLE newsletter (
  id INT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(255) UNIQUE,
  actif TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);