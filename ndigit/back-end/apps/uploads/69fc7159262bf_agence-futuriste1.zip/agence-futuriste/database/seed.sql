USE nexus_digital;

-- Services
INSERT INTO services (nom, slug, description, description_courte, icone, features, ordre) VALUES
('Développement Web', 'web', 'Sites et applications web performantes', 'Web moderne ultra-performant', 'web', '["React","Next.js","PHP","Node.js","API REST"]', 1),
('Applications Mobiles', 'mobile', 'iOS & Android natif et cross-platform', 'Apps mobiles natives', 'mobile', '["React Native","Flutter","Swift","Kotlin"]', 2),
('Identité Visuelle', 'branding', 'Création de marques mémorables', 'Branding & Design', 'brush', '["Logo","Charte graphique","UI/UX","Motion Design"]', 3),
('Intelligence Artificielle', 'ia', 'Solutions IA/ML sur mesure', 'IA & Machine Learning', 'brain', '["TensorFlow","PyTorch","NLP","Computer Vision"]', 4),
('E-commerce', 'ecommerce', 'Plateformes de vente performantes', 'Boutiques en ligne', 'cart', '["Shopify","Magento","WooCommerce","Stripe"]', 5),
('Consulting Digital', 'consulting', 'Stratégie et transformation digitale', 'Accompagnement stratégique', 'chart', '["Audit","Stratégie","Formation","ROI"]', 6);

-- Projets
INSERT INTO projets (titre, slug, description, description_longue, client, categorie, technos, images, url_live, featured, ordre) VALUES
('Nexus Bank', 'nexus-bank', 'Refonte plateforme bancaire', 'Application bancaire complète avec authentification biométrique et IA antifraude', 'Banque Nationale', 'web', '["React","Node.js","MongoDB","WebSocket"]', '["assets/images/placeholder/bank1.jpg","assets/images/placeholder/bank2.jpg"]', 'https://nexusbank.com', 1, 1),
('SpaceX Dashboard', 'spacex-dashboard', 'Tableau de bord missions spatiales', 'Interface temps réel pour suivi des lancements SpaceX', 'SpaceX', 'web', '["Vue.js","Three.js","Socket.io","D3.js"]', '["assets/images/placeholder/spacex1.jpg"]', NULL, 1, 2),
('Quantum Fitness', 'quantum-fitness', 'App fitness IA', 'Application coaching personnalisé par IA', 'Quantum Fitness', 'mobile', '["React Native","TensorFlow Lite","Firebase"]', '["assets/images/placeholder/fitness1.jpg"]', 'https://quantumfit.com', 0, 3),
('CyberCity', 'cybercity', 'Plateforme smart city', 'Gestion intelligente des villes du futur', 'Mairie de Paris', 'ia', '["Python","AWS IoT","Computer Vision"]', '["assets/images/placeholder/city1.jpg"]', NULL, 1, 4),
('Neon Games', 'neon-games', 'Plateforme gaming', 'Marketplace jeux indépendants', 'Neon Games', 'web', '["Next.js","Prisma","Tailwind"]', '["assets/images/placeholder/games1.jpg"]', NULL, 0, 5),
('AI Assistant', 'ai-assistant', 'Assistant virtuel entreprise', 'IA conversationnelle multilingue', 'CorpTech', 'ia', '["GPT-4","Dialogflow","Rasa"]', '["assets/images/placeholder/ai1.jpg"]', NULL, 0, 6);

-- Team Members
INSERT INTO team_members (nom, prenom, role, bio, photo_url, linkedin, github, twitter, couleur_accent, ordre, actif) VALUES
('Martin', 'Alexis', 'Lead Developer', '10+ ans en Fullstack JS. Passionné par Three.js et WebGL.', 'assets/images/placeholder/team1.jpg', 'https://linkedin.com/in/alexismartin', 'https://github.com/alexismartin', NULL, '#00FFFF', 1, 1),
('Dubois', 'Léa', 'UI/UX Designer', 'Spécialiste design futuriste et animations 3D.', 'assets/images/placeholder/team2.jpg', 'https://linkedin.com/in/leadubois', NULL, 'https://twitter.com/leadubois', '#FF2D78', 2, 1),
('Leroy', 'Thomas', 'CTO & IA', 'Expert Machine Learning et architectures cloud.', 'assets/images/placeholder/team3.jpg', 'https://linkedin.com/in/thomasleroy', 'https://github.com/thomasleroy', NULL, '#7B2FFF', 3, 1),
('Moreau', 'Emma', 'DevOps Engineer', 'Infrastructure as Code et performance extrême.', 'assets/images/placeholder/team4.jpg', 'https://linkedin.com/in/emmamoreau', NULL, NULL, '#00FF88', 4, 1),
('Roux', 'Pierre', 'Mobile Lead', 'iOS & Android natif. React Native expert.', 'assets/images/placeholder/team5.jpg', 'https://linkedin.com/in/pierreroux', NULL, NULL, '#FFAA00', 5, 1),
('Blanc', 'Sophie', 'Product Owner', 'Gestion de projets agiles et MVP.', 'assets/images/placeholder/team6.jpg', 'https://linkedin.com/in/sophieblanc', NULL, NULL, '#FF6B9D', 6, 1),
('Garcia', 'Lucas', '3D Artist', 'Création assets 3D et animations WebGL.', 'assets/images/placeholder/team7.jpg', NULL, 'https://github.com/lucasgarcia', NULL, '#00D4FF', 7, 1),
('Simon', 'Julie', 'Marketing Digital', 'Growth hacking et SEO technique.', 'assets/images/placeholder/team8.jpg', 'https://linkedin.com/in/juliesimon', NULL, NULL, '#A100FF', 8, 1);

-- Articles
INSERT INTO articles (titre, slug, contenu, extrait, image_url, categorie, auteur_id, tags, vues, temps_lecture, publie) VALUES
('L''avenir du Web3 et Metaverse', 'web3-metaverse', '<h2>Introduction au Web3</h2><p>Le Web3 représente la prochaine évolution d''Internet...</p>', 'Découvrez comment le Web3 va transformer le digital', 'assets/images/placeholder/blog1.jpg', 'tech', 1, '["web3","metaverse","blockchain"]', 1250, 8, 1),
('Three.js : Maîtriser les shaders', 'threejs-shaders', '<h2>Shaders personnalisés</h2><p>Les shaders GLSL permettent des effets visuels...</p>', 'Guide complet des shaders Three.js', 'assets/images/placeholder/blog2.jpg', 'dev', 1, '["threejs","webgl","shaders"]', 980, 12, 1),
('IA Générative en production', 'ia-generative', '<h2>Implémenter GPT-4</h2><p>Comment déployer des modèles IA en production...</p>', 'Déployer l''IA générative à l''échelle', 'assets/images/placeholder/blog3.jpg', 'ia', 3, '["ia","gpt4","production"]', 2100, 10, 1);

-- Témoignages
INSERT INTO temoignages (client_nom, client_entreprise, client_photo, contenu, note, service, valide) VALUES
('Jean Dupont', 'TechCorp', 'assets/images/placeholder/client1.jpg', 'Nexus Digital a transformé notre présence digitale. Résultats exceptionnels !', 5, 'Développement Web', 1),
('Marie Lambert', 'StartUp Valley', 'assets/images/placeholder/client2.jpg', 'Équipe ultra-compétente et réactive. Délais respectés.', 5, 'Applications Mobiles', 1),
('Paul Martin', 'GlobalBank', 'assets/images/placeholder/client3.jpg', 'Plateforme bancaire sécurisée et moderne. Excellent travail.', 5, 'E-commerce', 1);

-- FAQ
INSERT INTO faq (question, reponse, categorie, ordre, actif) VALUES
('Combien de temps pour un projet web ?', 'Le délai varie de 4 à 12 semaines selon la complexité. Nous fournissons un planning détaillé dès la première réunion.', 'general', 1, 1),
('Quels frameworks utilisez-vous ?', 'React/Next.js pour le frontend, Node.js/PHP pour le backend, Three.js pour le 3D.', 'technique', 1, 1),
('Proposez-vous un contrat maintenance ?', 'Oui, forfaits mensuels incluant mises à jour, sécurité et support technique 24/7.', 'tarifs', 1, 1),
('Comment fonctionne votre processus ?', '5 étapes : Découverte → Design → Développement → Tests → Livraison.', 'general', 2, 1);

-- Newsletter (exemple)
INSERT INTO newsletter (email) VALUES ('demo@example.com');