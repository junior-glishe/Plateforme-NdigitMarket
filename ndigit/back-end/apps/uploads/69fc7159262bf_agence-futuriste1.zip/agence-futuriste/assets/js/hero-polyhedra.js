document.addEventListener('DOMContentLoaded', function () {
    const heroCanvases = document.querySelectorAll('.hero-canvas[data-wireframe-hero="polyhedra"]');

    heroCanvases.forEach((canvas) => {
        if (typeof THREE === 'undefined') {
            return;
        }

        const heroSection = canvas.closest('.hero');
        if (!heroSection) {
            return;
        }

        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({
            canvas,
            alpha: true,
            antialias: true
        });

        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
        renderer.setClearColor(0x000000, 0);

        const geometries = [
            new THREE.BoxGeometry(0.6, 0.6, 0.6),
            new THREE.OctahedronGeometry(0.55),
            new THREE.TetrahedronGeometry(0.6),
            new THREE.IcosahedronGeometry(0.5)
        ];
        const palette = [0x00ffff, 0x7b2fff];
        const shapes = [];

        for (let i = 0; i < 14; i++) {
            const mesh = new THREE.Mesh(
                geometries[i % geometries.length],
                new THREE.MeshBasicMaterial({
                    color: palette[i % palette.length],
                    wireframe: true,
                    transparent: true,
                    opacity: 0.55 + Math.random() * 0.2
                })
            );

            const scale = 0.65 + Math.random() * 1.75;
            mesh.scale.setScalar(scale);
            mesh.position.set(
                (Math.random() - 0.5) * 9,
                (Math.random() - 0.5) * 6,
                (Math.random() - 0.5) * 8
            );
            mesh.rotation.set(
                Math.random() * Math.PI,
                Math.random() * Math.PI,
                Math.random() * Math.PI
            );

            shapes.push({
                mesh,
                baseY: mesh.position.y,
                drift: 0.003 + Math.random() * 0.005,
                rotX: 0.002 + Math.random() * 0.006,
                rotY: 0.003 + Math.random() * 0.007,
                phase: Math.random() * Math.PI * 2
            });

            scene.add(mesh);
        }

        camera.position.z = 4.8;

        function resize() {
            const width = heroSection.clientWidth || window.innerWidth;
            const height = heroSection.clientHeight || window.innerHeight;

            camera.aspect = width / Math.max(height, 1);
            camera.updateProjectionMatrix();
            renderer.setSize(width, height, false);
        }

        resize();
        window.addEventListener('resize', resize);

        let time = 0;

        function animate() {
            time += 0.01;

            shapes.forEach((shape, index) => {
                shape.mesh.rotation.x += shape.rotX;
                shape.mesh.rotation.y += shape.rotY;
                shape.mesh.position.y = shape.baseY + Math.sin(time + shape.phase + index * 0.2) * (0.15 + shape.drift * 20);
                shape.mesh.position.x += Math.sin(time * 0.35 + shape.phase) * 0.0008;
            });

            scene.rotation.y = Math.sin(time * 0.25) * 0.12;
            camera.position.x = Math.sin(time * 0.18) * 0.35;
            camera.position.y = Math.cos(time * 0.14) * 0.12;
            camera.lookAt(0, 0, 0);

            renderer.render(scene, camera);
            requestAnimationFrame(animate);
        }

        animate();
    });
});
