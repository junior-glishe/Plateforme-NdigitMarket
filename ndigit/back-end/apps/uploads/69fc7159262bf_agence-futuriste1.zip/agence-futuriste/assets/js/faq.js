// FAQ.JS - Animations FAQ
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. ONGLETS
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.dataset.tab;
            
            // Active tab
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // Show content
            tabContents.forEach(content => {
                content.style.display = content.id === `tab-${targetTab}` ? 'block' : 'none';
            });
            
            // Animation slide
            const activeContent = document.getElementById(`tab-${targetTab}`);
            activeContent.style.opacity = '0';
            activeContent.style.transform = 'translateY(30px)';
            setTimeout(() => {
                activeContent.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
                activeContent.style.opacity = '1';
                activeContent.style.transform = 'translateY(0)';
            }, 50);
        });
    });
    
    // 2. ACCORDÉON FAQ
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        const arrow = item.querySelector('.faq-arrow');
        
        question.addEventListener('click', () => {
            const isOpen = answer.style.maxHeight !== '0px';
            
            if (isOpen) {
                // Fermer
                answer.style.maxHeight = '0px';
                arrow.style.transform = 'rotate(0deg)';
            } else {
                // Ouvrir
                const scrollHeight = answer.scrollHeight;
                answer.style.maxHeight = scrollHeight + 'px';
                arrow.style.transform = 'rotate(180deg)';
            }
        });
    });
    
    // 3. PARTICULES "?" HERO
    const faqCanvas = document.getElementById('faq-particles');
    if (faqCanvas) {
        const ctx = faqCanvas.getContext('2d');
        faqCanvas.width = window.innerWidth;
        faqCanvas.height = window.innerHeight;
        
        const questionMark = '?';
        const fontSize = 300;
        ctx.font = `bold ${fontSize}px Orbitron, monospace`;
        const textMetrics = ctx.measureText(questionMark);
        const particles = [];
        
        // Générer particules depuis "?"
        for (let i = 0; i < 200; i++) {
            particles.push({
                x: Math.random() * faqCanvas.width,
                y: Math.random() * faqCanvas.height,
                vx: (Math.random() - 0.5) * 2,
                vy: (Math.random() - 0.5) * 2,
                radius: Math.random() * 3 + 1,
                life: 1,
                decay: Math.random() * 0.01 + 0.005
            });
        }
        
        function animateParticles() {
            ctx.clearRect(0, 0, faqCanvas.width, faqCanvas.height);
            
            particles.forEach(p => {
                p.x += p.vx;
                p.y += p.vy;
                p.life -= p.decay;
                
                if (p.life > 0) {
                    ctx.save();
                    ctx.globalAlpha = p.life;
                    ctx.fillStyle = `hsl(189, 100%, ${50 + p.life * 50}%)`;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius * p.life, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.restore();
                }
            });
            
            // Redessiner "?"
            ctx.save();
            ctx.translate(faqCanvas.width / 2, faqCanvas.height / 2);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const gradient = ctx.createLinearGradient(0, -fontSize/2, 0, fontSize/2);
            gradient.addColorStop(0, '#00ffff');
            gradient.addColorStop(0.5, '#7b2fff');
            gradient.addColorStop(1, '#ff2d78');
            ctx.fillStyle = gradient;
            ctx.shadowColor = '#00ffff';
            ctx.shadowBlur = 30;
            ctx.fillText(questionMark, 0, 0);
            ctx.restore();
            
            requestAnimationFrame(animateParticles);
        }
        animateParticles();
    }
});