// THREE-BG.JS - Fond particules 3D global
let scene, camera, renderer, particles, particleCount = 3000;
let mouseX = 0, mouseY = 0;
let time = 0;

function initThreeBG() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    
    // Scene
    scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x020408, 1, 15);
    
    // Camera
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 5;
    
    // Renderer
    renderer = new THREE.WebGLRenderer({ 
        canvas: canvas,
        alpha: true,
        antialias: true 
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x020408, 0);
    
    // Particles
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const sizes = new Float32Array(particleCount);
    
    for (let i = 0; i < particleCount; i++) {
        // Position
        positions[i * 3] = (Math.random() - 0.5) * 20;
        positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 20;
        
        // Color (cyan to purple gradient)
        const color = new THREE.Color();
        color.setHSL(0.55 + Math.random() * 0.2, 0.7 + Math.random() * 0.3, 0.5 + Math.random() * 0.5);
        colors[i * 3] = color.r;
        colors[i * 3 + 1] = color.g;
        colors[i * 3 + 2] = color.b;
        
        // Size
        sizes[i] = Math.random() * 3 + 1;
    }
    
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
    
    const material = new THREE.PointsMaterial({
        size: 0.02,
        vertexColors: true,
        transparent: true,
        opacity: 0.8,
        blending: THREE.AdditiveBlending,
        depthWrite: false
    });
    
    particles = new THREE.Points(geometry, material);
    scene.add(particles);
    
    // Lights
    const ambientLight = new THREE.AmbientLight(0x4040ff, 0.4);
    scene.add(ambientLight);
    
    const pointLight = new THREE.PointLight(0x00ffff, 1, 10);
    pointLight.position.set(0, 0, 2);
    scene.add(pointLight);
    
    // Mouse interaction
    document.addEventListener('mousemove', onMouseMove);
    window.addEventListener('resize', onWindowResize);
    
    animate();
}

function onMouseMove(event) {
    mouseX = (event.clientX / window.innerWidth) * 2 - 1;
    mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    requestAnimationFrame(animate);
    
    time += 0.01;
    
    // Rotation globale lente
    particles.rotation.x += 0.0005;
    particles.rotation.y += 0.001;
    
    // Mouvement sinusoïdal des particules
    const positions = particles.geometry.attributes.position.array;
    for (let i = 0; i < particleCount; i++) {
        const i3 = i * 3;
        positions[i3 + 1] += Math.sin(time + positions[i3]) * 0.001;
        positions[i3 + 2] += Math.cos(time * 1.2 + positions[i3 + 1]) * 0.001;
    }
    particles.geometry.attributes.position.needsUpdate = true;
    
    // Réaction à la souris
    const vector = new THREE.Vector3(mouseX, mouseY, 0.5);
    vector.unproject(camera);
    const dir = vector.sub(camera.position).normalize();
    const distance = -camera.position.z / dir.z;
    const mousePos = camera.position.clone().add(dir.multiplyScalar(distance));
    
    const positionsAttr = particles.geometry.attributes.position;
    for (let i = 0; i < particleCount; i++) {
        const i3 = i * 3;
        const particlePos = new THREE.Vector3(
            positionsAttr.array[i3],
            positionsAttr.array[i3 + 1],
            positionsAttr.array[i3 + 2]
        );
        
        const dist = particlePos.distanceTo(mousePos);
        if (dist < 1) {
            particlePos.add(dir.multiplyScalar(0.02));
            positionsAttr.array[i3] = particlePos.x;
            positionsAttr.array[i3 + 1] = particlePos.y;
            positionsAttr.array[i3 + 2] = particlePos.z;
        }
    }
    positionsAttr.needsUpdate = true;
    
    // Rotation caméra subtile
    camera.position.x += (mouseX * 0.1 - camera.position.x) * 0.02;
    camera.position.y += (mouseY * 0.1 - camera.position.y) * 0.02;
    camera.lookAt(scene.position);
    
    renderer.render(scene, camera);
}

// Initialisation au chargement
if (document.getElementById('bg-canvas')) {
    initThreeBG();
}