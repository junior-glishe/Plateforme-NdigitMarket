(function () {

  const wrapper = document.getElementById('arrow-wrapper');
  const canvas  = document.getElementById('arrow-canvas');
  if (!canvas || !wrapper) return;

  const ctx = canvas.getContext('2d');
  const W   = canvas.width;
  const H   = canvas.height;
  const CY  = H / 2;

  let animFrame = null;
  let menuOpen  = false;

  function easeInOut(t) {
    return t < 0.5
      ? 4 * t * t * t
      : 1 - Math.pow(-2 * t + 2, 3) / 2;
  }

  function easeOut(t) {
    return 1 - Math.pow(1 - t, 3);
  }

  function drawArrow(x, direction, progress) {
    ctx.clearRect(0, 0, W, H);

    const arrowW = 60;
    const arrowH = 50;
    const tailLen = 80 + progress * 120;
    const tailH = 14;

    const speed = Math.min(progress * 2, 1);
    const r = Math.floor(0 + 255 * speed * 0.3);
    const g = Math.floor(255 - 100 * speed);
    const b = Math.floor(255 - 50 * speed);
    const mainColor = `rgb(${r},${g},${b})`;
    const glowColor = direction === -1
      ? `rgba(0, 255, 255, ${0.4 + progress * 0.5})`
      : `rgba(255, 45, 120, ${0.4 + progress * 0.5})`;

    const trailCount = 6;
    for (let i = trailCount; i >= 1; i--) {
      const offset = direction * i * (15 + progress * 20);
      const alpha = (1 - i / trailCount) * 0.35 * progress;
      const trailX = x + offset;
      const trailScale = 1 - i * 0.08;

      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(trailX, CY);
      ctx.scale(trailScale, trailScale);

      ctx.beginPath();
      if (direction === -1) {
        ctx.moveTo(0, 0);
        ctx.lineTo(arrowW, -arrowH / 2);
        ctx.lineTo(arrowW, -tailH / 2);
        ctx.lineTo(arrowW + tailLen, -tailH / 2);
        ctx.lineTo(arrowW + tailLen, tailH / 2);
        ctx.lineTo(arrowW, tailH / 2);
        ctx.lineTo(arrowW, arrowH / 2);
        ctx.closePath();
      } else {
        ctx.moveTo(0, 0);
        ctx.lineTo(-arrowW, -arrowH / 2);
        ctx.lineTo(-arrowW, -tailH / 2);
        ctx.lineTo(-arrowW - tailLen, -tailH / 2);
        ctx.lineTo(-arrowW - tailLen, tailH / 2);
        ctx.lineTo(-arrowW, tailH / 2);
        ctx.lineTo(-arrowW, arrowH / 2);
        ctx.closePath();
      }
      ctx.fillStyle = glowColor;
      ctx.fill();
      ctx.restore();
    }

    ctx.save();
    ctx.translate(x, CY);
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = 30 + progress * 25;

    ctx.beginPath();
    if (direction === -1) {
      ctx.moveTo(0, 0);
      ctx.lineTo(arrowW, -arrowH / 2);
      ctx.lineTo(arrowW, -tailH / 2);
      ctx.lineTo(arrowW + tailLen, -tailH / 2);
      ctx.lineTo(arrowW + tailLen, tailH / 2);
      ctx.lineTo(arrowW, tailH / 2);
      ctx.lineTo(arrowW, arrowH / 2);
    } else {
      ctx.moveTo(0, 0);
      ctx.lineTo(-arrowW, -arrowH / 2);
      ctx.lineTo(-arrowW, -tailH / 2);
      ctx.lineTo(-arrowW - tailLen, -tailH / 2);
      ctx.lineTo(-arrowW - tailLen, tailH / 2);
      ctx.lineTo(-arrowW, tailH / 2);
      ctx.lineTo(-arrowW, arrowH / 2);
    }
    ctx.closePath();

    const grad = ctx.createLinearGradient(
      direction === -1 ? arrowW + tailLen : -arrowW - tailLen,
      0,
      0,
      0
    );
    grad.addColorStop(0, `rgba(${r},${g},${b},0.2)`);
    grad.addColorStop(0.5, mainColor);
    grad.addColorStop(1, '#FFFFFF');

    ctx.fillStyle = grad;
    ctx.fill();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.shadowBlur = 15;
    ctx.stroke();

    ctx.restore();

    const sparkCount = Math.floor(progress * 8);
    for (let i = 0; i < sparkCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = Math.random() * 30 * progress;
      const sx = x + Math.cos(angle) * dist;
      const sy = CY + Math.sin(angle) * dist;
      const size = Math.random() * 4 + 1;

      ctx.beginPath();
      ctx.arc(sx, sy, size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.8})`;
      ctx.shadowColor = mainColor;
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    const lineCount = Math.floor(progress * 5);
    for (let i = 0; i < lineCount; i++) {
      const ly = CY + (Math.random() - 0.5) * 60;
      const lx1 = direction === -1
        ? x + arrowW + 20 + Math.random() * 60
        : x - arrowW - 20 - Math.random() * 60;
      const lLen = 20 + Math.random() * 50 * progress;
      const lx2 = lx1 + direction * lLen;

      ctx.beginPath();
      ctx.moveTo(lx1, ly);
      ctx.lineTo(lx2, ly);
      ctx.strokeStyle = `rgba(0, 255, 255, ${Math.random() * 0.4 * progress})`;
      ctx.lineWidth = 1 + Math.random() * 2;
      ctx.shadowBlur = 5;
      ctx.stroke();
      ctx.shadowBlur = 0;
    }
  }

  function playArrow(direction, onMidpoint) {
    if (animFrame) cancelAnimationFrame(animFrame);

    wrapper.classList.add('visible');

    const DURATION = 900;
    const MIDPOINT = 0.45;
    let midDone = false;
    const startTs = performance.now();

    const startX = direction === -1 ? W + 100 : -100;
    const endX = direction === -1 ? -100 : W + 100;

    function tick(now) {
      const elapsed = now - startTs;
      const rawT = Math.min(elapsed / DURATION, 1);
      const t = easeInOut(rawT);
      const progress = easeOut(rawT);
      const x = startX + (endX - startX) * t;

      drawArrow(x, direction, progress);

      if (rawT >= MIDPOINT && !midDone) {
        midDone = true;
        onMidpoint && onMidpoint();
      }

      if (rawT < 1) {
        animFrame = requestAnimationFrame(tick);
      } else {
        ctx.clearRect(0, 0, W, H);
        wrapper.classList.remove('visible');
      }
    }

    animFrame = requestAnimationFrame(tick);
  }

  const burger = document.querySelector('.burger');
  const mobileMenu = document.getElementById('mobile-menu');
  const overlay = document.getElementById('menu-overlay');

  if (!burger) return;

  burger.addEventListener('click', () => {
    if (!menuOpen) {
      menuOpen = true;
      burger.classList.add('open');
      playArrow(-1, () => {
        mobileMenu && mobileMenu.classList.add('active');
        overlay && overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      });
    } else {
      menuOpen = false;
      burger.classList.remove('open');
      playArrow(+1, () => {
        mobileMenu && mobileMenu.classList.remove('active');
        overlay && overlay.classList.remove('active');
        document.body.style.overflow = '';
      });
    }
  });

  overlay && overlay.addEventListener('click', () => {
    if (menuOpen) burger.click();
  });

  document.querySelectorAll('#mobile-menu a').forEach(l => {
    l.addEventListener('click', () => {
      if (menuOpen) burger.click();
    });
  });

})();
