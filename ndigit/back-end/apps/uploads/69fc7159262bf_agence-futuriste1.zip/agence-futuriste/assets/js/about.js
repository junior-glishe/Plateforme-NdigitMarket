// ABOUT.JS - Animations spécifiques about
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. ADN HELICE DOUBLE CANVAS
    let adnScene, adnCamera, adnRenderer, helix1, helix2;
    
    function initAdnCanvas() {
        const canvas = document.getElementById('adn-canvas');
        if (!canvas) return;
        
        adnScene = new THREE.Scene();
        adnCamera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        adnRenderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
        adnRenderer.setSize(window.innerWidth, window.innerHeight);
        adnRenderer.setClearColor(0x000000, 0);
        
        // Helix 1
        const helixGeometry1 = new THREE.BufferGeometry();
        const helixPoints1 = [];
        for (let i = 0; i < 100; i++) {
            const t = i / 100 * Math.PI * 8;
            helixPoints1.push(
                Math.cos(t) * 0.3,
                Math.sin(t * 2.4) * 0.5,
                t * 0.1
            );
        }
        helixGeometry1.setAttribute('position', new THREE.Float32BufferAttribute(helixPoints1, 3));
        
        const helixMaterial1 = new THREE.LineBasicMaterial({ 
            color: 0x00ffff, 
            transparent: true, 
            opacity: 0.8 
        });
        helix1 = new THREE.Line(helixGeometry1, helixMaterial1);
        adnScene.add(helix1);
        
        // Helix 2
        const helixGeometry2 = new THREE.BufferGeometry();
        const helixPoints2 = [];
        for (let i = 0; i < 100; i++) {
            const t = i / 100 * Math.PI * 8;
            helixPoints2.push(
                -Math.cos(t) * 0.3,
                -Math.sin(t * 2.4) * 0.5,
                t * 0.1
            );
        }
        helixGeometry2.setAttribute('position', new THREE.Float32BufferAttribute(helixPoints2, 3));
        
        const helixMaterial2 = new THREE.LineBasicMaterial({ 
            color: 0x7b2fff, 
            transparent: true, 
            opacity: 0.8 
        });
        helix2 = new THREE.Line(helixGeometry2, helixMaterial2);
        adnScene.add(helix2);
        
        adnCamera.position.z = 3;
        
        window.addEventListener('resize', () => {
            adnCamera.aspect = window.innerWidth / window.innerHeight;
            adnCamera.updateProjectionMatrix();
            adnRenderer.setSize(window.innerWidth, window.innerHeight);
        });
        
        animateAdn();
    }
    
    let adnTime = 0;
    function animateAdn() {
        requestAnimationFrame(animateAdn);
        
        adnTime += 0.02;
        helix1.rotation.y = Math.sin(adnTime) * 0.3;
        helix1.rotation.x = adnTime * 0.1;
        helix2.rotation.y = -Math.sin(adnTime) * 0.3;
        helix2.rotation.x = -(adnTime * 0.1);
        
        adnRenderer.render(adnScene, adnCamera);
    }
    
    // 2. VALEURS 3D GEOMETRIES
    const valuesCanvases = document.querySelectorAll('.values-canvas');
    valuesCanvases.forEach(canvas => {
        const ctx = canvas.getContext('2d');
        const shape = canvas.dataset.shape;
        let rotation = 0;
        
        function animateValue() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.save();
            ctx.translate(canvas.width/2, canvas.height/2);
            ctx.rotate(rotation);
            ctx.strokeStyle = '#00ffff';
            ctx.lineWidth = 2;
            ctx.shadowColor = '#00ffff';
            ctx.shadowBlur = 20;
            
            const radius = 40;
            const points = 8;
            
            ctx.beginPath();
            for (let i = 0; i < points * 2; i++) {
                const angle = (i / (points * 2)) * Math.PI * 2;
                const r = i % 2 === 0 ? radius : radius * 0.6;
                const x = Math.cos(angle) * r;
                const y = Math.sin(angle) * r;
                
                if (i === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
            ctx.closePath();
            ctx.stroke();
            
            ctx.restore();
            rotation += 0.02;
            requestAnimationFrame(animateValue);
        }
        animateValue();
    });
    
    // 3. TERMINAL TYPING EFFECT
    const terminalLines = document.querySelectorAll('[data-terminal]');
    terminalLines.forEach((line, index) => {
        const text = line.textContent;
        line.textContent = '';
        line.style.borderRight = '2px solid #00ffff';
        line.style.overflow = 'hidden';
        line.style.whiteSpace = 'nowrap';
        
        let i = 0;
        const typeInterval = setInterval(() => {
            line.textContent += text[i];
            i++;
            if (i >= text.length) {
                clearInterval(typeInterval);
                line.style.borderRight = 'none';
            }
        }, 80 + index * 200);
    });
    
    // 4. TIMELINE ANIMATION
    const timelineObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateX(0)';
            }
        });
    }, { threshold: 0.3 });
    
    document.querySelectorAll('.timeline-item').forEach(item => {
        item.style.opacity = '0';
        item.style.transform = 'translateX(50px)';
        timelineObserver.observe(item);
    });
    
    // Initialisation
    initAdnCanvas();
});