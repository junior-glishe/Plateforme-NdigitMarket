// TEAM.JS - Animations équipe
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. CONSTELLATION
    let constellationCanvas, ctx, stars = [], connections = [];
    
    function initConstellation() {
        constellationCanvas = document.getElementById('team-constellation');
        if (!constellationCanvas) return;
        
        ctx = constellationCanvas.getContext('2d');
        constellationCanvas.width = window.innerWidth;
        constellationCanvas.height = window.innerHeight;
        
        // Créer étoiles (1 par membre + extras)
        const memberCount = document.querySelectorAll('.team-card').length;
        for (let i = 0; i < Math.max(20, memberCount); i++) {
            stars.push({
                x: Math.random() * constellationCanvas.width,
                y: Math.random() * constellationCanvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                radius: Math.random() * 2 + 1,
                brightness: Math.random() * 0.5 + 0.5
            });
        }
        
        // Connexions
        for (let i = 0; i < stars.length - 1; i++) {
            for (let j = i + 1; j < stars.length; j++) {
                connections.push([i, j]);
            }
        }
        
        window.addEventListener('resize', resizeCanvas);
        animateConstellation();
    }
    
    function resizeCanvas() {
        constellationCanvas.width = window.innerWidth;
        constellationCanvas.height = window.innerHeight;
    }
    
    function animateConstellation() {
        ctx.clearRect(0, 0, constellationCanvas.width, constellationCanvas.height);
        
        // Mouvement étoiles
        stars.forEach(star => {
            star.x += star.vx;
            star.y += star.vy;
            
            if (star.x < 0 || star.x > constellationCanvas.width) star.vx *= -1;
            if (star.y < 0 || star.y > constellationCanvas.height) star.vy *= -1;
        });
        
        // Connexions
        ctx.strokeStyle = 'rgba(0, 255, 255, 0.1)';
        ctx.lineWidth = 1;
        connections.forEach(([i, j]) => {
            const star1 = stars[i];
            const star2 = stars[j];
            const dist = Math.hypot(star1.x - star2.x, star1.y - star2.y);
            
            if (dist < 120) {
                ctx.globalAlpha = 1 - dist / 120;
                ctx.beginPath();
                ctx.moveTo(star1.x, star1.y);
                ctx.lineTo(star2.x, star2.y);
                ctx.stroke();
            }
        });
        ctx.globalAlpha = 1;
        
        // Étoiles
        stars.forEach(star => {
            const gradient = ctx.createRadialGradient(star.x, star.y, 0, star.x, star.y, star.radius * 2);
            gradient.addColorStop(0, `rgba(0, 255, 255, ${star.brightness})`);
            gradient.addColorStop(1, 'rgba(0, 255, 255, 0)');
            
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(star.x, star.y, star.radius * 2, 0, Math.PI * 2);
            ctx.fill();
        });
        
        requestAnimationFrame(animateConstellation);
    }
    
    // 2. FLIP 3D OPTIMISÉ
    const teamCards = document.querySelectorAll('.team-card');
    teamCards.forEach(card => {
        const front = card.querySelector('.card-front');
        const back = card.querySelector('.card-back');
        const socials = card.querySelector('.social-links');
        const accent = card.dataset.accent;
        
        // Social hover
        const socialLinks = card.querySelectorAll('.social-links a');
        socialLinks.forEach(link => {
            link.addEventListener('mouseenter', () => {
                link.style.color = accent;
                link.style.transform = 'scale(1.3)';
            });
            link.addEventListener('mouseleave', () => {
                link.style.color = '';
                link.style.transform = 'scale(1)';
            });
            socials.style.opacity = '1';
        });
        
        // Flip animation améliorée
        card.addEventListener('mouseenter', () => {
            gsap.to(card.querySelector('.card-inner'), {
                rotationY: 180,
                duration: 0.8,
                ease: "back.inOut(1.7)"
            });
        });
        
        card.addEventListener('mouseleave', () => {
            gsap.to(card.querySelector('.card-inner'), {
                rotationY: 0,
                duration: 0.8,
                ease: "back.inOut(1.7)"
            });
        });
    });
    
    // Initialisation
    initConstellation();
});