// ANIMATIONS.JS - GSAP ScrollTrigger global
document.addEventListener('DOMContentLoaded', function() {
    gsap.registerPlugin(ScrollTrigger);
    
    // 1. FADE-UP GLOBAL
    gsap.utils.toArray('[data-animate="fade-up"]').forEach((el) => {
        gsap.fromTo(el, 
            { opacity: 0, y: 40 },
            {
                opacity: 1,
                y: 0,
                duration: 1,
                scrollTrigger: {
                    trigger: el,
                    start: 'top 85%',
                    toggleActions: 'play none none reverse'
                }
            }
        );
    });
    
    // 2. REVEAL EFFECT
    gsap.utils.toArray('[data-animate="reveal"]').forEach((el) => {
        gsap.fromTo(el, 
            { clipPath: 'inset(0 100% 0 0)' },
            {
                clipPath: 'inset(0 0 0 0)',
                duration: 1.2,
                scrollTrigger: {
                    trigger: el,
                    start: 'top 85%',
                    toggleActions: 'play none none reverse'
                }
            }
        );
    });
    
    // 3. STAGGER CHILDREN
    gsap.utils.toArray('[data-animate="stagger"]').forEach((container) => {
        gsap.from(container.children, {
            opacity: 0,
            y: 30,
            duration: 0.6,
            stagger: 0.1,
            scrollTrigger: {
                trigger: container,
                start: 'top 85%',
                toggleActions: 'play none none reverse'
            }
        });
    });
    
    // 4. COMPTEURS
    const counters = document.querySelectorAll('[data-count]');
    counters.forEach(counter => {
        const target = parseInt(counter.dataset.count);
        const increment = target / 100;
        let current = 0;
        
        ScrollTrigger.create({
            trigger: counter,
            start: 'top 80%',
            onEnter: () => {
                const timer = setInterval(() => {
                    current += increment;
                    if (current >= target) {
                        current = target;
                        clearInterval(timer);
                    }
                    counter.textContent = Math.floor(current).toLocaleString();
                }, 20);
            }
        });
    });
    
    // 5. SVG DRAW
    gsap.utils.toArray('[data-draw]').forEach(path => {
        const length = path.getTotalLength();
        path.style.strokeDasharray = length;
        path.style.strokeDashoffset = length;
        
        gsap.to(path, {
            strokeDashoffset: 0,
            duration: 2,
            scrollTrigger: {
                trigger: path,
                start: 'top 85%',
                toggleActions: 'play none none reverse'
            }
        });
    });
    
    // 6. PARALLAX ELEMENTS
    gsap.utils.toArray('[data-parallax]').forEach(layer => {
        gsap.to(layer, {
            yPercent: -50,
            ease: "none",
            scrollTrigger: {
                trigger: layer,
                start: "top bottom",
                end: "bottom top",
                scrub: true
            }
        });
    });
    
    // 7. SPLIT TEXT (titres)
    gsap.utils.toArray('.section-title, h1, h2').forEach(title => {
        const split = title.textContent.split('');
        title.innerHTML = split.map(char => 
            `<span style="display: inline-block; opacity: 0; transform: translateY(30px);">${char === ' ' ? '&nbsp;' : char}</span>`
        ).join('');
        
        gsap.to(title.children, {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.05,
            scrollTrigger: {
                trigger: title,
                start: 'top 90%'
            }
        });
    });
    
    // 8. TILT 3D CARDS
    const tiltCards = document.querySelectorAll('.card-tilt');
    tiltCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 10;
            const rotateY = (centerX - x) / 10;
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
        });
    });
    
    // 9. INTERSECTION OBSERVER POUR CLASSES CSS
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);
    
    document.querySelectorAll('.fade-in, .timeline-item, .stat-item').forEach(el => {
        observer.observe(el);
    });
    
    // 10. SCROLL INDICATOR HERO
    const scrollIndicators = document.querySelectorAll('.scroll-indicator');
    scrollIndicators.forEach(indicator => {
        gsap.to(indicator, {
            y: 20,
            duration: 1.5,
            repeat: -1,
            yoyo: true,
            ease: "power2.inOut"
        });
    });
});