// PRICING.JS - Animations pricing
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. TOGGLE MENSUEL/ANNUEL
    const toggle = document.getElementById('billing-toggle');
    const savingsBadge = document.querySelector('.savings-badge');
    const priceElements = document.querySelectorAll('[data-price]');
    
    toggle.addEventListener('change', () => {
        const isYearly = toggle.checked;
        
        priceElements.forEach(el => {
            const monthly = parseFloat(el.dataset.monthly);
            const yearly = parseFloat(el.dataset.yearly);
            
            if (!isNaN(monthly) && !isNaN(yearly)) {
                const newPrice = isYearly ? yearly : monthly;
                countUp(el, isYearly ? newPrice : monthly);
            } else {
                el.textContent = el.dataset.monthly || 'SUR MESURE';
            }
        });
        
        savingsBadge.style.opacity = isYearly ? '1' : '0';
        savingsBadge.style.transform = isYearly ? 'scale(1)' : 'scale(0.8)';
    });
    
    function countUp(element, target) {
        let current = parseFloat(element.textContent.replace(/[^\d.]/g, '')) || 0;
        const increment = target / 50;
        let timer;
        
        function update() {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            element.textContent = '€' + Math.floor(current).toLocaleString();
        }
        
        timer = setInterval(update, 20);
    }
    
    // 2. FEATURES STAGGER
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const features = entry.target.querySelectorAll('[data-feature]');
                features.forEach((feature, i) => {
                    setTimeout(() => {
                        feature.style.opacity = '1';
                        feature.style.transform = 'translateX(0)';
                    }, i * 100);
                });
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });
    
    document.querySelectorAll('.features-list').forEach(list => {
        list.querySelectorAll('[data-feature]').forEach(feature => {
            feature.style.opacity = '0';
            feature.style.transform = 'translateX(20px)';
        });
        observer.observe(list);
    });
    
    // 3. CONIC BORDER ANIMATION
    const enterpriseCard = document.querySelector('.pricing-card:nth-child(2)');
    if (enterpriseCard) {
        enterpriseCard.style.animation = 'conicRotate 4s linear infinite';
    }
});