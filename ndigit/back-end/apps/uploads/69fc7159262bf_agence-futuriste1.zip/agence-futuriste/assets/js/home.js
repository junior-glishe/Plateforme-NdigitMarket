// HOME.JS - Animations spécifiques homepage

// Force immediate visibility of hero content
const heroStyle = document.createElement('style');
heroStyle.textContent = `.hero-content, .hero-title, .hero-subtitle { opacity: 1 !important; transform: none !important; visibility: visible !important; }`;
document.head.appendChild(heroStyle);

document.addEventListener('DOMContentLoaded', function() {
    
    // 1. HERO CANVAS - Planète holographique
    let heroScene, heroCamera, heroRenderer, planet, rings = [];
    
    function initHeroCanvas() {
        const canvas = document.getElementById('index-hero-canvas');
        if (!canvas) return;
        
        heroScene = new THREE.Scene();
        heroCamera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        heroRenderer = new THREE.WebGLRenderer({ 
            canvas: canvas, 
            alpha: true, 
            antialias: true 
        });
        heroRenderer.setSize(window.innerWidth, window.innerHeight);
        heroRenderer.setClearColor(0x000000, 0);
        
        // Planète
        const planetGeometry = new THREE.SphereGeometry(1.5, 64, 64);
        const planetMaterial = new THREE.MeshPhongMaterial({
            color: 0x00ffff,
            wireframe: true,
            transparent: true,
            opacity: 0.6,
            shininess: 100
        });
        planet = new THREE.Mesh(planetGeometry, planetMaterial);
        heroScene.add(planet);
        
        // Anneaux orbitaux
        const ringGeometry = new THREE.TorusGeometry(2.2, 0.05, 8, 100);
        const ringMaterial = new THREE.MeshBasicMaterial({ 
            color: 0x7b2fff, 
            transparent: true, 
            opacity: 0.4 
        });
        
        for (let i = 0; i < 3; i++) {
            const ring = new THREE.Mesh(ringGeometry, ringMaterial);
            ring.rotation.x = Math.PI / 2;
            ring.position.y = i * 0.1 - 0.1;
            rings.push(ring);
            heroScene.add(ring);
        }
        
        // Lumières
        const ambientLight = new THREE.AmbientLight(0x4040ff, 0.3);
        heroScene.add(ambientLight);
        const pointLight = new THREE.PointLight(0x00ffff, 1, 10);
        pointLight.position.set(5, 5, 5);
        heroScene.add(pointLight);
        
        heroCamera.position.z = 5;
        
        window.addEventListener('mousemove', onHeroMouseMove);
        window.addEventListener('resize', onHeroResize);
        animateHero();
    }
    
    let heroMouseX = 0, heroMouseY = 0;
    function onHeroMouseMove(e) {
        heroMouseX = (e.clientX / window.innerWidth) * 2 - 1;
        heroMouseY = -(e.clientY / window.innerHeight) * 2 + 1;
    }
    
    function onHeroResize() {
        heroCamera.aspect = window.innerWidth / window.innerHeight;
        heroCamera.updateProjectionMatrix();
        heroRenderer.setSize(window.innerWidth, window.innerHeight);
    }
    
    function animateHero() {
        requestAnimationFrame(animateHero);
        
        // Rotation planète
        planet.rotation.y += 0.01;
        planet.rotation.x += 0.005;
        planet.position.x = heroMouseX * 0.3;
        planet.position.y = heroMouseY * 0.3;
        
        // Rotation anneaux
        rings[0].rotation.z += 0.005;
        rings[1].rotation.z += 0.008;
        rings[2].rotation.z += 0.012;
        
        heroRenderer.render(heroScene, heroCamera);
    }
    
    // 2. BOUTONS PARTICULES EXPLOSION
    const buttons = document.querySelectorAll('.hero-content .btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', createParticleExplosion);
    });
    
    function createParticleExplosion(e) {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        for (let i = 0; i < 20; i++) {
            const particle = document.createElement('div');
            particle.style.cssText = `
                position: fixed;
                width: 4px;
                height: 4px;
                background: linear-gradient(45deg, ${getRandomColor()}, ${getRandomColor()});
                border-radius: 50%;
                pointer-events: none;
                z-index: 10000;
                left: ${x}px;
                top: ${y}px;
                animation: float-up 1s ease-out forwards;
            `;
            particle.style.animationDelay = `${Math.random() * 0.2}s`;
            document.body.appendChild(particle);
            
            setTimeout(() => particle.remove(), 1000);
        }
    }
    
    function getRandomColor() {
        const colors = ['#00ffff', '#7b2fff', '#ff2d78', '#00ff88', '#ffaa00'];
        return colors[Math.floor(Math.random() * colors.length)];
    }
    
    // 3. SERVICES MINI-CANVAS
    const serviceCanvases = document.querySelectorAll('.service-canvas');
    serviceCanvases.forEach(canvas => {
        const ctx = canvas.getContext('2d');
        const service = canvas.dataset.service;
        let rotation = 0;
        
        function animateService() {
            const colors = {
                web: '#00ffff',
                mobile: '#7b2fff',
                ia: '#ff2d78'
            };
            
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            ctx.save();
            ctx.translate(canvas.width/2, canvas.height/2);
            ctx.rotate(rotation);
            
            // Dessiner forme géométrique
            ctx.strokeStyle = colors[service] || '#00ffff';
            ctx.lineWidth = 3;
            ctx.shadowColor = colors[service];
            ctx.shadowBlur = 15;
            
            if (service === 'web') {
                // Cube
                ctx.beginPath();
                ctx.moveTo(0, -25);
                ctx.lineTo(25, 25);
                ctx.lineTo(-25, 25);
                ctx.closePath();
                ctx.stroke();
            } else if (service === 'mobile') {
                // Phone
                ctx.strokeRect(-15, -25, 30, 50);
                ctx.beginPath();
                ctx.arc(0, -27, 8, 0, Math.PI*2);
                ctx.stroke();
            } else {
                // Brain
                ctx.beginPath();
                ctx.arc(0, 0, 20, 0, Math.PI*2);
                ctx.stroke();
                ctx.beginPath();
                for (let i = 0; i < 6; i++) {
                    const angle = (i/6) * Math.PI * 2;
                    ctx.lineTo(Math.cos(angle)*25, Math.sin(angle)*25);
                }
                ctx.stroke();
            }
            
            ctx.restore();
            rotation += 0.03;
            requestAnimationFrame(animateService);
        }
        animateService();
    });
    
    // 4. TESTIMONIALS SLIDER
    const sliderContainer = document.querySelector('.slider-container');
    const slides = document.querySelectorAll('.testimonial-slide');
    const prevBtn = document.querySelector('.slider-prev');
    const nextBtn = document.querySelector('.slider-next');
    const dotsContainer = document.querySelector('.slider-dots');
    
    if (slides.length > 1) {
        let currentSlide = 0;
        
        // Dots
        slides.forEach((_, i) => {
            const dot = document.createElement('button');
            dot.className = i === 0 ? 'dot active' : 'dot';
            dot.style.cssText = 'width: 12px; height: 12px; border-radius: 50%; background: rgba(0,255,255,0.3); border: none; cursor: pointer; margin: 0 0.5rem; transition: all 0.3s;';
            dot.addEventListener('click', () => goToSlide(i));
            dotsContainer.appendChild(dot);
        });
        
        const dots = document.querySelectorAll('.dot');
        
        function goToSlide(slide) {
            sliderContainer.style.transform = `translateX(-${slide * 100}%)`;
            currentSlide = slide;
            
            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === slide);
            });
        }
        
        prevBtn.addEventListener('click', () => {
            currentSlide = currentSlide > 0 ? currentSlide - 1 : slides.length - 1;
            goToSlide(currentSlide);
        });
        
        nextBtn.addEventListener('click', () => {
            currentSlide = currentSlide < slides.length - 1 ? currentSlide + 1 : 0;
            goToSlide(currentSlide);
        });
        
        // Autoplay
        setInterval(() => {
            currentSlide = (currentSlide + 1) % slides.length;
            goToSlide(currentSlide);
        }, 4000);
    }
    
    // Initialisation
    initHeroCanvas();
});

// ========== NOUVELLES ANIMATIONS SECTIONS ==========

// 1. BANDEAU MARQUEE - Pause/Play au hover
document.addEventListener('DOMContentLoaded', () => {
    const marqueeTrack = document.querySelector('.marquee-track');
    if (marqueeTrack) {
        marqueeTrack.addEventListener('mouseenter', () => {
            marqueeTrack.style.animationPlayState = 'paused';
        });
        marqueeTrack.addEventListener('mouseleave', () => {
            marqueeTrack.style.animationPlayState = 'running';
        });
    }
});

// 2. INTERSECTION OBSERVER - Animations au scroll
const observerOptions = {
    threshold: 0.2,
    rootMargin: '0px 0px -50px 0px'
};

const scrollObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            // Features
            if (entry.target.classList.contains('feature-item')) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateX(0)';
            }

            // Process steps
            if (entry.target.classList.contains('process-step')) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'scale(1)';
                
                // Dessiner la ligne du process
                const processLine = document.querySelector('.process-line');
                if (processLine) {
                    processLine.classList.add('drawn');
                }
            }

            // Tech items
            if (entry.target.classList.contains('tech-item')) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        }
    });
}, observerOptions);

document.addEventListener('DOMContentLoaded', () => {
    // Initialiser opacité/transform avant le scroll
    document.querySelectorAll('.feature-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateX(-20px)';
    });
    
    document.querySelectorAll('.process-step').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'scale(0.8)';
    });
    
    document.querySelectorAll('.tech-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
    });

    // Observer
    document.querySelectorAll('.feature-item, .process-step, .tech-item').forEach(el => {
        scrollObserver.observe(el);
    });
});

// 3. FORMULAIRE DE CONTACT RAPIDE
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('quick-contact-form');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(form);
            
            try {
                const response = await fetch('contact.php', {
                    method: 'POST',
                    body: formData
                });

                if (response.ok) {
                    const successDiv = document.getElementById('form-success');
                    if (successDiv) {
                        successDiv.style.display = 'block';
                        form.style.display = 'none';
                        
                        // Réinitialiser après 3s
                        setTimeout(() => {
                            form.reset();
                            form.style.display = 'flex';
                            successDiv.style.display = 'none';
                        }, 3000);
                    }
                }
            } catch (error) {
                console.error('Erreur contact:', error);
            }
        });
    }
});

// 4. CLIENTS LOGOS - Effet glow au hover
document.addEventListener('DOMContentLoaded', () => {
    const clientLogos = document.querySelectorAll('.client-logo');
    clientLogos.forEach(logo => {
        logo.addEventListener('mouseenter', () => {
            logo.style.textShadow = '0 0 20px currentColor';
            logo.style.transition = 'all 0.3s ease';
        });
        logo.addEventListener('mouseleave', () => {
            logo.style.textShadow = 'none';
        });
    });
});

// 5. CARTES - Glow au hover
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        const originalTransition = card.style.transition;
        
        card.addEventListener('mouseenter', () => {
            card.style.boxShadow = '0 0 30px rgba(0, 255, 255, 0.3)';
            card.style.transform = 'translateY(-5px)';
            card.style.transition = 'all 0.3s ease';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.boxShadow = 'none';
            card.style.transform = 'translateY(0)';
        });
    });
});

// 6. COMPTEURS DE STATS
document.addEventListener('DOMContentLoaded', () => {
    const countElements = document.querySelectorAll('[data-count]');
    if (countElements.length > 0) {
        const statsObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !entry.target.dataset.counted) {
                    const target = parseInt(entry.target.dataset.count);
                    let current = 0;
                    const increment = Math.ceil(target / 30);
                    
                    const counter = setInterval(() => {
                        current += increment;
                        if (current >= target) {
                            entry.target.textContent = target;
                            clearInterval(counter);
                        } else {
                            entry.target.textContent = current;
                        }
                    }, 30);
                    
                    entry.target.dataset.counted = 'true';
                }
            });
        }, { threshold: 0.5 });

        countElements.forEach(el => statsObserver.observe(el));
    }
});

// 7. TECH ITEMS - Rotation et scale au hover
document.addEventListener('DOMContentLoaded', () => {
    const techItems = document.querySelectorAll('.tech-item');
    techItems.forEach(item => {
        const svg = item.querySelector('svg');
        if (svg) {
            item.addEventListener('mouseenter', () => {
                svg.style.transform = 'scale(1.3) rotate(5deg)';
                svg.style.transition = 'transform 0.3s ease';
                svg.style.filter = 'drop-shadow(0 0 15px currentColor)';
            });
            
            item.addEventListener('mouseleave', () => {
                svg.style.transform = 'scale(1) rotate(0deg)';
                svg.style.filter = 'drop-shadow(0 0 0px currentColor)';
            });
        }
    });
});

console.log('HOME.JS - Toutes les animations chargées ✓');