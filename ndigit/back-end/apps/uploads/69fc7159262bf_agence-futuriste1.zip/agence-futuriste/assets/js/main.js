// MAIN.JS - Scripts globaux
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. CURSOR PERSONNALISÉ
    const cursor = document.getElementById('cursor');
    const cursorFollower = document.getElementById('cursor-follower');
    const cursorText = document.createElement('div');
    cursorText.className = 'cursor-text';
    document.body.appendChild(cursorText);
    
    let mouseX = 0, mouseY = 0;
    let cursorX = 0, cursorY = 0;
    
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        // Effet sur liens et boutons
        const target = e.target.closest('a, button, .card, .btn');
        if (target) {
            cursor.style.transform = 'scale(1.5)';
            cursorFollower.style.transform = 'scale(2)';
            cursorText.textContent = target.textContent?.trim().substring(0, 3).toUpperCase() || '';
            cursorText.style.opacity = '1';
            cursorText.style.left = `${mouseX}px`;
            cursorText.style.top = `${mouseY - 20}px`;
        } else {
            cursor.style.transform = 'scale(1)';
            cursorFollower.style.transform = 'scale(1)';
            cursorText.style.opacity = '0';
        }
    });
    
    function animateCursor() {
        cursorX += (mouseX - cursorX) * 0.1;
        cursorY += (mouseY - cursorY) * 0.1;
        
        cursor.style.left = cursorX + 'px';
        cursor.style.top = cursorY + 'px';
        cursorFollower.style.left = cursorX + 'px';
        cursorFollower.style.top = cursorY + 'px';
        
        requestAnimationFrame(animateCursor);
    }
    animateCursor();
    
    // 2. HEADER SCROLL EFFECT
    const header = document.getElementById('main-header');
    let lastScroll = 0;
    
    window.addEventListener('scroll', () => {
        const scroll = window.scrollY;
        
        if (scroll > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
        
        lastScroll = scroll;
    });
    
    // 3. LOGO ANIMATION GSAP
    gsap.registerPlugin(ScrollTrigger);
    
    const logoSpans = document.querySelectorAll('.logo span');
    gsap.fromTo(logoSpans, 
        {
            opacity: 0,
            y: 30,
            rotationX: 90
        },
        {
            opacity: 1,
            y: 0,
            rotationX: 0,
            duration: 1,
            stagger: 0.1,
            ease: "back.out(1.7)"
        }
    );
    
    // 4. MOBILE MENU
    
    // 5. LIENS GLITCH EFFECT
    const glitchLinks = document.querySelectorAll('.nav-links a');
    glitchLinks.forEach(link => {
        link.addEventListener('mouseenter', () => {
            link.classList.add('glitch');
        });
        link.addEventListener('mouseleave', () => {
            link.classList.remove('glitch');
        });
    });
    
    // 6. BACK TO TOP
    const backToTop = document.getElementById('back-to-top');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 500) {
            backToTop.classList.add('show');
        } else {
            backToTop.classList.remove('show');
        }
    });
    
    backToTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    
    // 7. PAGE TRANSITION
    const links = document.querySelectorAll('a[href^="./"]:not([href="#"]):not([data-no-transition])');
    
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const href = link.getAttribute('href');
            
            // Créer overlay transition
            const transition = document.createElement('div');
            transition.id = 'page-transition';
            transition.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background: var(--bg-deep);
                z-index: 10000;
                transform: translateX(-100%);
                transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
            `;
            document.body.appendChild(transition);
            
            // Animation sweep
            requestAnimationFrame(() => {
                transition.style.transform = 'translateX(0)';
            });
            
            // Navigation après animation
            setTimeout(() => {
                window.location.href = href;
            }, 600);
        });
    });
    
    // 8. FORM VALIDATION
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.classList.add('loading');
            }
        });
    });
    
    // 9. AUTO-RESIZE TEXTAREA
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(textarea => {
        textarea.addEventListener('input', () => {
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';
        });
    });
    
    // 10. DETECT PAGE ACTIVE
    const currentPage = window.location.pathname.split('/').pop() || 'index.php';
    const navLink = document.querySelector(`.nav-links a[data-page="${currentPage}"]`);
    if (navLink) {
        navLink.classList.add('active');
    }
});
