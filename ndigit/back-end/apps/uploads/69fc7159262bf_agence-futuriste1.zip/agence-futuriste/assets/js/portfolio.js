// PORTFOLIO.JS - Animations portfolio
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. FILTRES
    const filterBtns = document.querySelectorAll('.filter-btn');
    const portfolioCards = document.querySelectorAll('.portfolio-card');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update active
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const filter = btn.dataset.filter;
            portfolioCards.forEach(card => {
                if (filter === 'all' || card.dataset.categorie === filter) {
                    card.style.opacity = '1';
                    card.style.transform = 'scale(1)';
                    card.style.pointerEvents = 'auto';
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'scale(0.8)';
                    card.style.pointerEvents = 'none';
                }
            });
        });
    });
    
    // 2. PARALLAX HOVER
    portfolioCards.forEach(card => {
        const layers = card.querySelector('.image-layers');
        
        card.addEventListener('mousemove', (e) => {
            if (!layers) return;
            
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const moveX = (x - centerX) * 0.05;
            const moveY = (y - centerY) * 0.05;
            
            layers.style.transform = `translate(${moveX}px, ${moveY}px) scale(1.1)`;
        });
        
        card.addEventListener('mouseleave', () => {
            if (layers) layers.style.transform = 'translate(0, 0) scale(1)';
        });
    });
    
    // 3. MODAL
    const modal = document.getElementById('modal');
    const modalGallery = modal.querySelector('.modal-gallery');
    const modalTitle = modal.querySelector('.modal-title');
    const modalDescription = modal.querySelector('.modal-description');
    const modalClient = modal.querySelector('.modal-client');
    const modalTechs = modal.querySelector('.modal-techs');
    const modalLive = modal.querySelector('.modal-live');
    const closeBtn = modal.querySelector('.modal-close');
    
    const viewBtns = document.querySelectorAll('.view-project');
    viewBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const card = btn.closest('.portfolio-card');
            openModal(card);
        });
    });
    
    function openModal(card) {
        modalTitle.textContent = card.dataset.title;
        modalDescription.textContent = card.dataset.description;
        modalClient.innerHTML = card.dataset.client ? `<strong>Client:</strong> ${card.dataset.client}` : '';
        
        // Techs
        const techs = JSON.parse(card.dataset.technos || '[]');
        modalTechs.innerHTML = techs.length ? techs.map(t => `<span class="tech-tag">${t}</span>`).join('') : '';
        
        // Images
        const images = JSON.parse(card.dataset.images || '[]');
        modalGallery.innerHTML = images.map(img => `<img src="${img}" alt="${card.dataset.title}" style="width: 100%; height: 400px; object-fit: cover; border-radius: 16px; margin-bottom: 1rem;">`).join('') || 
                                '<div style="height: 400px; background: linear-gradient(135deg, var(--primary), var(--secondary)); border-radius: 16px; display: flex; align-items: center; justify-content: center; color: #000; font-weight: bold;">PROJET EN COURS</div>';
        
        // Live URL
        if (card.dataset.url) {
            modalLive.href = card.dataset.url;
            modalLive.style.display = 'inline-flex';
        } else {
            modalLive.style.display = 'none';
        }
        
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    
    closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    });
    
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
    
    // 4. GALERIE SLIDER DANS MODAL
    modalGallery.addEventListener('click', (e) => {
        const images = modalGallery.querySelectorAll('img');
        let currentIndex = 0;
        
        images.forEach((img, i) => {
            if (img === e.target) currentIndex = i;
        });
        
        // Simple slider (prochain/précédent)
        // Implémentation slider ici...
    });
});