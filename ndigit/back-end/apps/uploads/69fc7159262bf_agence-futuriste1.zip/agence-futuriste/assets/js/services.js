// SERVICES.JS - Animations specifiques services
document.addEventListener('DOMContentLoaded', function() {
    const toggleButtons = document.querySelectorAll('.toggle-features');
    toggleButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const card = btn.closest('.service-card');
            const features = card?.querySelector('.features');
            const arrow = btn.querySelector('span:last-child');

            if (!features) {
                return;
            }

            if (features.style.maxHeight === '0px' || !features.style.maxHeight) {
                const scrollHeight = features.scrollHeight;
                features.style.maxHeight = scrollHeight + 'px';
                if (arrow) {
                    arrow.style.transform = 'rotate(180deg)';
                }

                const featureItems = features.querySelectorAll('div');
                featureItems.forEach((item, i) => {
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'translateX(0)';
                    }, i * 100);
                });
            } else {
                features.style.maxHeight = '0px';
                if (arrow) {
                    arrow.style.transform = 'rotate(0deg)';
                }
            }
        });
    });

    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = (y - centerY) / 15;
            const rotateY = (centerX - x) / 15;

            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
        });
    });
});
