<?php 
require_once 'includes/header.php';
require_once 'config/db.php';
require_once 'includes/functions.php';

$page_script = 'assets/js/pricing.js';
?>

<main>
    <!-- HERO -->
    <section class="hero" style="padding-top: 120px; padding-bottom: 3rem;">
        <canvas id="pricing-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container" style="position: relative; z-index: 2;">
            <h1 class="hero-title" style="color: #FFFFFF;">TARIFICATION TRANSPARENTE</h1>
            <p class="hero-subtitle" style="font-size: 1.3rem; max-width: 900px;">3 plans pour démarrer. 1 équipe pour vous accompagner jusqu'au succès.</p>
        </div>
    </section>

    <!-- PLANS 3 COLONNES -->
    <section class="section">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem; margin-bottom: 4rem;">
                
                <!-- GROWTH PLAN -->
                <div class="glass" style="padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(0,255,255,0.2); position: relative; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0s;">
                    <h3 style="font-family: 'Orbitron'; color: #00FFFF; margin-bottom: 0.5rem; font-size: 1.3rem;">GROWTH</h3>
                    <div style="margin-bottom: 1rem;">
                        <p style="font-family: 'Orbitron'; font-size: 2.5rem; font-weight: 900; color: #FFFFFF;">€4,900</p>
                        <p style="color: var(--text-muted); font-size: 0.95rem;">point de départ pour tout projet</p>
                    </div>
                    
                    <div style="border-top: 1px solid rgba(0,255,255,0.1); border-bottom: 1px solid rgba(0,255,255,0.1); padding: 1.5rem 0; margin-bottom: 1.5rem;">
                        <p style="color: #00FFFF; font-weight: 600; margin-bottom: 1rem;">INCLUS:</p>
                        <ul style="list-style: none; padding: 0; margin: 0;">
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #00FFFF;">✓</span> Site web moderne (Next.js / React)</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #00FFFF;">✓</span> Design UI/UX professionnel</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #00FFFF;">✓</span> Animations 3D (Three.js)</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #00FFFF;">✓</span> CMS headless intégré</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #00FFFF;">✓</span> SEO/Performance optimisées</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #00FFFF;">✓</span> 3 mois de support inclus</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem;"><span style="color: #00FFFF;">✓</span> Hébergement 3 mois</li>
                        </ul>
                    </div>
                    
                    <a href="contact.php" style="display: block; text-align: center; padding: 1rem 1.5rem; background: linear-gradient(135deg, #00FFFF, #7B2FFF); color: #000; text-decoration: none; border-radius: 8px; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'">COMMENCER</a>
                </div>

                <!-- ENTERPRISE PLAN (Recommandé) -->
                <div style="padding: 2.5rem; border-radius: 12px; border: 2px solid #FF2D78; position: relative; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.1s; background: linear-gradient(135deg, rgba(255,45,120,0.1), rgba(123,47,255,0.05));">
                    <div style="position: absolute; top: -15px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg, #FF2D78, #7B2FFF); color: #fff; padding: 0.4rem 1rem; border-radius: 20px; font-weight: 600; font-size: 0.85rem; white-space: nowrap;">✨ RECOMMANDÉ</div>
                    
                    <h3 style="font-family: 'Orbitron'; color: #FF2D78; margin-bottom: 0.5rem; font-size: 1.3rem; margin-top: 0.5rem;">ENTERPRISE</h3>
                    <div style="margin-bottom: 1rem;">
                        <p style="font-family: 'Orbitron'; font-size: 2.5rem; font-weight: 900; color: #FFFFFF;">€12,900</p>
                        <p style="color: var(--text-muted); font-size: 0.95rem;">pour projets complexes et e-commerce</p>
                    </div>
                    
                    <div style="border-top: 1px solid rgba(255,45,120,0.2); border-bottom: 1px solid rgba(255,45,120,0.2); padding: 1.5rem 0; margin-bottom: 1.5rem;">
                        <p style="color: #FF2D78; font-weight: 600; margin-bottom: 1rem;">INCLUS:</p>
                        <ul style="list-style: none; padding: 0; margin: 0;">
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #FF2D78;">✓</span> Tout du plan GROWTH+</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #FF2D78;">✓</span> E-commerce complet (Stripe/Paypal)</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #FF2D78;">✓</span> Intégrations IA (ChatGPT, LLMs)</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #FF2D78;">✓</span> Mobile app (iOS + Android)</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #FF2D78;">✓</span> Infrastructure scalable (AWS/GCP)</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #FF2D78;">✓</span> Support premium 12 mois</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem;">✓ Formation équipe interne</li>
                        </ul>
                    </div>
                    
                    <a href="contact.php" style="display: block; text-align: center; padding: 1rem 1.5rem; background: linear-gradient(135deg, #FF2D78, #FF6B35); color: #fff; text-decoration: none; border-radius: 8px; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'">DÉCOUVRIR</a>
                </div>

                <!-- CUSTOM PLAN -->
                <div class="glass" style="padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(238,130,196,0.2); opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.2s;">
                    <h3 style="font-family: 'Orbitron'; color: #6495ED; margin-bottom: 0.5rem; font-size: 1.3rem;">CUSTOM</h3>
                    <div style="margin-bottom: 1rem;">
                        <p style="font-family: 'Orbitron'; font-size: 2.5rem; font-weight: 900; color: #FFFFFF;">Sur mesure</p>
                        <p style="color: var(--text-muted); font-size: 0.95rem;">pour besoins spécifiques Web3/IA</p>
                    </div>
                    
                    <div style="border-top: 1px solid rgba(238,130,196,0.1); border-bottom: 1px solid rgba(238,130,196,0.1); padding: 1.5rem 0; margin-bottom: 1.5rem;">
                        <p style="color: #6495ED; font-weight: 600; margin-bottom: 1rem;">POUR:</p>
                        <ul style="list-style: none; padding: 0; margin: 0;">
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #6495ED;">✓</span> Smart contracts (Web3/DeFi)</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #6495ED;">✓</span> Expériences VR/AR immersives</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #6495ED;">✓</span> Modèles IA sur-mesure</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #6495ED;">✓</span> Infrastructure hyperscale</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;"><span style="color: #6495ED;">✓</span> Dedicate team (6+ devs)</li>
                            <li style="color: var(--text-muted); display: flex; align-items: center; gap: 0.75rem;">✓ Roadmap co-défini</li>
                        </ul>
                    </div>
                    
                    <a href="contact.php" style="display: block; text-align: center; padding: 1rem 1.5rem; background: linear-gradient(135deg, #6495ED, #00FFFF); color: #000; text-decoration: none; border-radius: 8px; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'">DISCUTER</a>
                </div>
            </div>

            <!-- Disclaimer -->
            <div style="background: rgba(0,255,255,0.05); padding: 2rem; border-radius: 12px; border-left: 3px solid #00FFFF; margin-top: 2rem;">
                <p style="color: var(--text-muted); font-size: 0.95rem; margin: 0;"><strong>Note:</strong> Tous nos tarifs hors TVA (20% applicable). Devis personnalisés selon scope exact. Les prix affichés incluent le développement de base. Frais d'intégration externes (API partenaires, licenses third-party) facturées en sus.</p>
            </div>
        </div>
    </section>

    <!-- FAQ PRICING →
    <section class="section" style="background: rgba(123,47,255,0.05);">
        <div class="container">
            <h2 class="section-title text-gradient" style="text-align: center; margin-bottom: 3rem;">QUESTIONS SUR LES TARIFS</h2>
            
            <div style="max-width: 800px; margin: 0 auto;">
                <details style="background: rgba(0,255,255,0.05); padding: 1.5rem; border-radius: 8px; margin-bottom: 1rem; cursor: pointer; border: 1px solid rgba(0,255,255,0.1);">
                    <summary style="color: #00FFFF; font-weight: 600; user-select: none;">TVA et conditions de paiement?</summary>
                    <p style="color: var(--text-muted); margin-top: 1rem; line-height: 1.6;">Les tarifs affichés sont hors TVA (20% applicable pour clients FR).
                    Paiement 50% acompte, 50% à livraison. Plans de paiement disponibles pour Enterprise.</p>
                </details>

                <details style="background: rgba(0,255,255,0.05); padding: 1.5rem; border-radius: 8px; margin-bottom: 1rem; cursor: pointer; border: 1px solid rgba(0,255,255,0.1);">
                    <summary style="color: #00FFFF; font-weight: 600; user-select: none;">Coûts additionnels possibles?</summary>
                    <p style="color: var(--text-muted); margin-top: 1rem; line-height: 1.6;">Oui, les intégrations partenaires (Stripe, API externes), licenses third-party et hébergement annuel sont facturés en sus.</p>
                </details>

                <details style="background: rgba(0,255,255,0.05); padding: 1.5rem; border-radius: 8px; margin-bottom: 1rem; cursor: pointer; border: 1px solid rgba(0,255,255,0.1);">
                    <summary style="color: #00FFFF; font-weight: 600; user-select: none;">Qu'est-ce qui est inclus dans le support?</summary>
                    <p style="color: var(--text-muted); margin-top: 1rem; line-height: 1.6;">Fixage des bugs critiques, mises à jour de sécurité, optimisations de performance. Pas inclus: nouvelles features (facturation horaire €85/h).</p>
                </details>

                <details style="background: rgba(0,255,255,0.05); padding: 1.5rem; border-radius: 8px; cursor: pointer; border: 1px solid rgba(0,255,255,0.1);">
                    <summary style="color: #00FFFF; font-weight: 600; user-select: none;">Flexibilité si le scope change?</summary>
                    <p style="color: var(--text-muted); margin-top: 1rem; line-height: 1.6;">Oui. Amendements au contrat possibles. On recalcule le prix si changements majeurs. Processus de change order formalisé.</p>
                </details>
            </div>
        </div>
    </section>
    -->

    <!-- CTA FINAL -->
    <section class="section" style="background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));">
        <div class="container" style="text-align: center;">
            <h2 style="font-size: 2rem; margin-bottom: 1.5rem;">Pas sûr du plan qui convient?</h2>
            <p style="color: var(--text-muted); margin-bottom: 2rem; font-size: 1.1rem;">Réservons 30 minutes pour discuter de votre projet et trouver la solution parfaite.</p>
            <a href="contact.php" class="btn btn-primary" style="display: inline-block; padding: 1rem 3rem; font-size: 1.1rem;">APPEL GRATUIT</a>
        </div>
    </section>
</main>

<style>
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>
                        <li data-feature="3"><svg width="20" height="20" viewBox="0 0 24 24" fill="var(--primary)"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg> SEO Technique Premium</li>
                        <li data-feature="4"><svg width="20" height="20" viewBox="0 0 24 24" fill="var(--primary)"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg> Support 3 mois</li>
                    </ul>
                    <a href="contact.php" class="btn btn-primary" style="margin-top: 2rem;">COMMENCER</a>
                </div>
                
                <!-- ENTERPRISE -->
                <div class="pricing-card card glass" data-monthly="12900" data-yearly="10320" style="border-image: conic-gradient(from 0deg, var(--primary), var(--secondary), var(--accent), var(--primary)) 1;">
                    <div class="price-header">
                        <h3 style="color: var(--accent);">ENTERPRISE</h3>
                        <div class="price-amount" data-price="12900">€12,900</div>
                        <span class="price-period">/ projet</span>
                    </div>
                    <ul class="features-list">
                        <li data-feature="1"><svg width="20" height="20" viewBox="0 0 24 24" fill="var(--accent)"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg> Plateforme complète IA</li>
                        <li data-feature="2"><svg width="20" height="20" viewBox="0 0 24 24" fill="var(--accent)"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg> Metaverse / Web3</li>
                        <li data-feature="3"><svg width="20" height="20" viewBox="0 0 24 24" fill="var(--accent)"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg> Équipe dédiée</li>
                        <li data-feature="4"><svg width="20" height="20" viewBox="0 0 24 24" fill="var(--accent)"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg> Support 24/7</li>
                    </ul>
                    <a href="contact.php" class="btn btn-primary" style="margin-top: 2rem; background: linear-gradient(135deg, var(--accent), #ff6b9d);">DEMANDEZ UN DEVIS</a>
                </div>
                
                <!-- CUSTOM -->
                <div class="pricing-card card glass" data-monthly="sur mesure" data-yearly="sur mesure">
                    <div class="price-header">
                        <h3 style="color: #00ff88;">CUSTOM</h3>
                        <div class="price-amount custom-price">SUR MESURE</div>
                        <span class="price-period">/ projet complexe</span>
                    </div>
                    <ul class="features-list">
                        <li data-feature="1"><svg width="20" height="20" viewBox="0 0 24 24" fill="#00ff88"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg> Architecture sur mesure</li>
                        <li data-feature="2"><svg width="20" height="20" viewBox="0 0 24 24" fill="#00ff88"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg> IA propriétaire</li>
                        <li data-feature="3"><svg width="20" height="20" viewBox="0 0 24 24" fill="#00ff88"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg>Équipe complète</li>
                        <li data-feature="4"><svg width="20" height="20" viewBox="0 0 24 24" fill="#00ff88"><circle cx="12" cy="12" r="10"/><path d="M8 12l3 3 5-5"/></svg>Contrat long terme</li>
                    </ul>
                    <a href="contact.php" class="btn btn-outline" style="margin-top: 2rem; border-color: #00ff88; color: #00ff88;">DISCUSSION STRATÉGIQUE</a>
                </div>
            </div>
        </div>
    </section>

    <!-- GARANTIES -->
    <section class="section" style="background: rgba(8,15,26,0.7);">
        <div class="container">
            <h2 class="section-title text-gradient" data-animate="reveal" style="margin-bottom: 4rem;">NOS GARANTIES</h2>
            <div class="grid grid-3" data-animate="stagger">
                <div class="card fade-in" style="text-align: center; padding: 3rem 2rem;">
                    <div class="guarantee-icon" style="width: 80px; height: 80px; margin: 0 auto 1.5rem; background: linear-gradient(135deg, var(--primary), var(--secondary)); border-radius: 20px; display: flex; align-items: center; justify-content: center; font-size: 2rem; box-shadow: var(--neon-glow); animation: pulse 2s infinite;">
                        ✅
                    </div>
                    <h3>Satisfaction 100%</h3>
                    <p>Garantie résultat ou remboursement intégral</p>
                </div>
                <div class="card fade-in" style="text-align: center; padding: 3rem 2rem;">
                    <div class="guarantee-icon" style="width: 80px; height: 80px; margin: 0 auto 1.5rem; background: linear-gradient(135deg, var(--secondary), var(--accent)); border-radius: 20px; display: flex; align-items: center; justify-content: center; font-size: 2rem; box-shadow: var(--neon-glow); animation: pulse 2s infinite 0.2s;">
                        ⚡
                    </div>
                    <h3>Délais Respectés</h3>
                    <p>Planning garanti sous peine de pénalités</p>
                </div>
                <div class="card fade-in" style="text-align: center; padding: 3rem 2rem;">
                    <div class="guarantee-icon" style="width: 80px; height: 80px; margin: 0 auto 1.5rem; background: linear-gradient(135deg, #00ff88, #00ffaa); border-radius: 20px; display: flex; align-items: center; justify-content: center; font-size: 2rem; box-shadow: var(--neon-glow); animation: pulse 2s infinite 0.4s;">
                        🛡️
                    </div>
                    <h3>Source Sécurisée</h3>
                    <p>Code source + documentation complète transférés</p>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
