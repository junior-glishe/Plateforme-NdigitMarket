# 📋 DOCUMENTATION PROJET AGENCE-FUTURISTE

## 🎯 Vue d'ensemble

**Nom du Projet:** FUTURISTE - Agence Digitale Premium  
**Type:** Site Web Professionnel (SPA dynamique)  
**Framework:** PHP 8+ avec PDO  
**Base de Données:** MySQL 8.0+  
**Responsive Design:** Mobile-First, Glassmorphism UI  
**Thème Visual:** Cyberpunk / Néon Futuriste  

---

## 📊 Informations Clés

| Aspect | Détail |
|--------|--------|
| **Version PHP** | 8.0+ |
| **Base de Données** | MySQL/MariaDB |
| **Charset** | UTF-8 MB4 |
| **Architecture** | MVC Léger (Pages PHP + Services) |
| **Templating** | PHP Natif |
| **Palette Couleurs** | Cyan #00FFFF, Violet #7B2FFF, Pink #FF2D78, Green #00ff88, Yellow #FFCC00, Dark #020408 |
| **Responsive** | Oui (Mobile, Tablet, Desktop) |

---

## 📁 Structure Complète du Projet

```
agence-futuriste/
│
├── 📄 index.php                    # Page d'accueil (Hero + 5 sections)
├── 📄 about.php                    # À propos (Timeline, Mission/Vision, Stats)
├── 📄 services.php                 # Services (6 services + tableau comparatif)
├── 📄 portfolio.php                # Portfolio (8 projets AAA)
├── 📄 team.php                     # Équipe (8 membres + recrutement)
├── 📄 pricing.php                  # Tarification (3 plans)
├── 📄 faq.php                      # FAQ (20 questions, 4 catégories)
├── 📄 blog.php                     # Blog (9 articles)
├── 📄 contact.php                  # Contact (formulaire)
│
├── 📁 assets/                      # Ressources statiques
│   ├── 📁 css/                     # Feuilles de style
│   │   ├── 📄 styles.css           # Style global
│   │   ├── 📄 animations.css       # Animations personnalisées
│   │   ├── 📄 glassmorphism.css    # Design glassmorphism
│   │   └── 📄 cyberpunk-theme.css  # Thème cyberpunk
│   │
│   ├── 📁 js/                      # Scripts JavaScript
│   │   ├── 📄 main.js              # Script principal
│   │   ├── 📄 animations.js        # Gestion animations
│   │   ├── 📄 portfolio.js         # Interactivité portfolio
│   │   ├── 📄 hero-canvas.js       # Canvas animé hero
│   │   └── 📄 smooth-scroll.js     # Scroll fluide
│   │
│   └── 📁 images/                  # Images et ressources visuelles
│       ├── 📄 projet1.jpg          # Image projet 1 (NeoBank Pro)
│       ├── 📄 projet2.jpg          # Image projet 2 (LUXE AR)
│       ├── 📄 projet3.jpg          # Image projet 3 (MedAI)
│       ├── 📄 projet4.jpg          # Image projet 4 (SpaceTrack 3D)
│       ├── 📄 projet5.jpg          # Image projet 5 (FitGenius)
│       ├── 📄 projet6.jpg          # Image projet 6 (MetaVerse Fashion)
│       ├── 📄 projet7.jpg          # Image projet 7 (CryptoExchange)
│       ├── 📄 projet8.jpg          # Image projet 8 (EduVR)
│       ├── 📄 logo.png             # Logo FUTURISTE
│       ├── 📄 favicon.ico          # Favicon
│       └── 📄 [avatars team]       # Avatars équipe
│
├── 📁 config/                      # Configuration
│   └── 📄 db.php                   # Connexion PDO MySQL
│
├── 📁 database/                    # Base de données
│   ├── 📄 schema.sql               # Schéma complet (9 tables)
│   └── 📄 seed.sql                 # Données initiales (fixtures)
│
├── 📁 includes/                    # Fichiers réutilisables
│   ├── 📄 header.php               # En-tête (nav, meta, doctype)
│   ├── 📄 footer.php               # Pied de page (scripts, liens)
│   └── 📄 functions.php            # Fonctions utilitaires PHP
│
└── 📄 DOCUMENTATION_PROJET.md      # Ce fichier
```

---

## 🔧 Configuration

### 📝 `config/db.php`
Fichier de configuration de la base de données

```php
DB_HOST = 'localhost'
DB_NAME = 'nexus_digital'
DB_USER = 'root'
DB_PASS = '' (vide par défaut)
```

**Caractéristiques PDO:**
- Mode d'erreur: `ERRMODE_EXCEPTION`
- Fetch mode: `FETCH_ASSOC` (tableaux associatifs)
- Charset: `utf8mb4` (support complet Unicode)

**Gestion d'erreurs:**
- En cas de connexion échouée: HTTP 500 + message JSON d'erreur

---

## 🗄️ Base de Données

### Schéma Complet (`database/schema.sql`)

#### Table 1: `articles`
Blog posts avec gestion de publication et statistiques

| Colonne | Type | Contrainte | Descripton |
|---------|------|-----------|------------|
| `id` | INT | PK, AI | Identifiant unique |
| `titre` | VARCHAR(255) | NOT NULL | Titre de l'article |
| `slug` | VARCHAR(255) | UNIQUE | URL-friendly slug |
| `contenu` | LONGTEXT | - | Contenu HTML complet |
| `extrait` | TEXT | - | Résumé court |
| `image_url` | VARCHAR(500) | - | URL image principale |
| `categorie` | VARCHAR(100) | - | Catégorie (IA, Web, Mobile, etc.) |
| `auteur_id` | INT | FK | Lien vers auteur |
| `tags` | JSON | - | Tags ([{}] format) |
| `vues` | INT | DEFAULT 0 | Compteur de vues |
| `temps_lecture` | INT | DEFAULT 5 | Minutes de lecture |
| `publie` | TINYINT(1) | DEFAULT 0 | Publié (0/1) |
| `created_at` | TIMESTAMP | DEFAULT NOW | Date création |
| `updated_at` | TIMESTAMP | AUTO-UPDATE | Dernière modif |

**Indexes suggérés:**
```sql
INDEX idx_slug (slug);
INDEX idx_categorie (categorie);
INDEX idx_publie (publie);
```

---

#### Table 2: `projets`
Portfolio des projets réalisés

| Colonne | Type | Contrainte | Description |
|---------|------|-----------|------------|
| `id` | INT | PK, AI | Identifiant unique |
| `titre` | VARCHAR(255) | NOT NULL | Titre du projet |
| `slug` | VARCHAR(255) | UNIQUE | URL-friendly slug |
| `description` | TEXT | - | Description courte |
| `description_longue` | LONGTEXT | - | Description détaillée |
| `client` | VARCHAR(255) | - | Nom du client |
| `categorie` | ENUM('web','mobile','branding','ia') | NOT NULL | Catégorie projet |
| `technos` | JSON | - | Techs utilisées (array) |
| `images` | JSON | - | URLs images (array) |
| `url_live` | VARCHAR(500) | - | Lien site live |
| `featured` | TINYINT(1) | DEFAULT 0 | Mis en avant |
| `ordre` | INT | DEFAULT 0 | Position affichage |
| `created_at` | TIMESTAMP | DEFAULT NOW | Date création |

**Données Hardcodées (8 projets):**
1. NeoBank Pro (Fintech)
2. LUXE AR Experience
3. MedAI Assistant (IA)
4. SpaceTrack 3D
5. FitGenius Mobile
6. MetaVerse Fashion
7. CryptoExchange PRO
8. EduVR Platform

---

#### Table 3: `team_members`
Équipe avec bios et réseaux sociaux

| Colonne | Type | Contrainte | Description |
|---------|------|-----------|------------|
| `id` | INT | PK, AI | Identifiant unique |
| `nom` | VARCHAR(100) | - | Nom de famille |
| `prenom` | VARCHAR(100) | - | Prénom |
| `role` | VARCHAR(255) | - | Poste/Role |
| `bio` | TEXT | - | Biographie complète |
| `photo_url` | VARCHAR(500) | - | Photo profil |
| `linkedin` | VARCHAR(500) | - | Lien LinkedIn |
| `github` | VARCHAR(500) | - | Lien GitHub |
| `twitter` | VARCHAR(500) | - | Lien Twitter/X |
| `couleur_accent` | VARCHAR(20) | DEFAULT '#00FFFF' | Couleur gradient perso |
| `ordre` | INT | DEFAULT 0 | Position affichage |
| `actif` | TINYINT(1) | DEFAULT 1 | Actif dans l'équipe |

**Données Hardcodées (8 membres):**
- Alice Leclerc (CTO)
- Marc Delorme (CEO)
- Sarah Bouvier (Head AI)
- Guillaume Durand (Architect)
- Émilie Moreau (UX Lead)
- Thomas Garnier (DevOps)
- Claude Petit (3D Artist)
- Amélie Fontaine (Web3 Engineer)

---

#### Table 4: `temoignages`
Avis clients avec système de notation

| Colonne | Type | Contrainte | Description |
|---------|------|-----------|------------|
| `id` | INT | PK, AI | Identifiant unique |
| `client_nom` | VARCHAR(255) | - | Nom client |
| `client_entreprise` | VARCHAR(255) | - | Entreprise |
| `client_photo` | VARCHAR(500) | - | Photo client |
| `contenu` | TEXT | - | Texte du témoignage |
| `note` | TINYINT | CHECK(1-5) | Note 1-5 étoiles |
| `service` | VARCHAR(100) | - | Service utilisé |
| `valide` | TINYINT(1) | DEFAULT 0 | Approuvé (0/1) |

---

#### Table 5: `faq`
Questions fréquemment posées

| Colonne | Type | Contrainte | Description |
|---------|------|-----------|------------|
| `id` | INT | PK, AI | Identifiant unique |
| `question` | TEXT | - | Texte question |
| `reponse` | TEXT | - | Texte réponse |
| `categorie` | ENUM | 4 valeurs | Catégorie FAQ |
| `ordre` | INT | DEFAULT 0 | Position affichage |
| `actif` | TINYINT(1) | DEFAULT 1 | Visible (0/1) |

**Catégories:** general, technique, tarifs, support

**Données Hardcodées (20 Q/A):**
- Général: 5 questions
- Technique: 5 questions
- Tarifs: 5 questions
- Support: 5 questions

---

#### Table 6: `contact_messages`
Messages de contact du formulaire

| Colonne | Type | Contrainte | Description |
|---------|------|-----------|------------|
| `id` | INT | PK, AI | Identifiant unique |
| `nom` | VARCHAR(255) | - | Nom contact |
| `email` | VARCHAR(255) | - | Email contact |
| `entreprise` | VARCHAR(255) | - | Nom entreprise |
| `budget` | VARCHAR(100) | - | Budget projet |
| `service` | VARCHAR(100) | - | Service intéressé |
| `message` | TEXT | - | Message |
| `lu` | TINYINT(1) | DEFAULT 0 | Lu (0/1) |
| `created_at` | TIMESTAMP | DEFAULT NOW | Date reçu |

---

#### Table 7: `services`
Catalogue services

| Colonne | Type | Contrainte | Description |
|---------|------|-----------|------------|
| `id` | INT | PK, AI | Identifiant |
| `nom` | VARCHAR(255) | - | Nom service |
| `slug` | VARCHAR(255) | - | URL slug |
| `description` | TEXT | - | Description complète |
| `description_courte` | VARCHAR(500) | - | Résumé court |
| `icone` | VARCHAR(100) | - | Classe icone/emoji |
| `features` | JSON | - | Features (array) |
| `ordre` | INT | DEFAULT 0 | Position |

**Services Hardcodés (6):**
1. Web Premium (React, Vue, Next.js)
2. Mobile Apps (iOS/Android)
3. IA & ML (Claude API, LLM)
4. Design & UX 3D (Figma, Blender)
5. Cybersecurity & Cloud (AWS, GCP)
6. Web3 & Metaverse (Solidity, blockchain)

---

#### Table 8: `newsletter`
Inscription newsletter

| Colonne | Type | Contrainte | Description |
|---------|------|-----------|------------|
| `id` | INT | PK, AI | Identifiant |
| `email` | VARCHAR(255) | UNIQUE | Email abonné |
| `actif` | TINYINT(1) | DEFAULT 1 | Abonné actif (0/1) |
| `created_at` | TIMESTAMP | DEFAULT NOW | Date inscription |

---

## 📄 Pages PHP

### 🏠 `index.php` - Accueil
**Sections complètes:**

1. **Hero Canvas Animé** (Section 1)
   - Canvas HTML5 avec animations WebGL
   - Titre: "FUTURISTE"
   - Subtitle: "L'agence digitale qui créé l'avenir"
   - CTA "DÉCOUVRIR NOS PROJETS"

2. **Services Overview** (Section 2)
   - 6 cartes services avec icones
   - Description courte par service
   - Couleurs dégradées (Cyan, Violet, Pink)
   - Lien individual vers /services.php

3. **Portfolio Showcase** (Section 3)
   - 4 derniers projets en grid 2x2
   - Image, titre, client, catégorie badge
   - "Voir tous les projets" CTA

4. **Testimonials** (Section 4)
   - 3 témoignages clients en carousel
   - Photos, noms, entreprises
   - Notation sur 5 étoiles
   - Autoplay avec navigation

5. **Stats & Achievements** (Section 5)
   - 4 métriques principales
   - Animations au scroll (counter animation)
   - "157 Projets | +520% ROI | 99.2% Satisfaction | 18 Pays"

6. **CTA Final**
   - "Prêt pour votre transformation?"
   - Bouton "COMMENCER VOTRE PROJET"

**Animations:**
- `fadeInUp` staggered 0.1s par élément
- Canvas hero interactif
- Parallax leger sur images

---

### 📚 `about.php` - À Propos
**Sections principales:**

1. **Hero Section**
   - "Qui est FUTURISTE?"
   - Sous-titre informatif

2. **Timeline 5 Étapes** (2016-2024)
   - Graphique vertical connecté
   - Jalons clés avec clients réels
   - LVMH (2016), Balenciaga (2018), SpaceX (2020), BNP Paribas (2022), L'Oréal (2024)

3. **Mission / Vision / Values**
   - 3 cartes avec descriptions
   - Détails supplémentaires dans grid 3x2
   - Icones et couleurs distinctes

4. **Terminal Stats** (8 Métriques)
   - Affichage type terminal monospace
   - Counters animés
   - Statistiques: Clients, Pays, Projets, etc.

5. **Team Numbers**
   - 6 badges specialités
   - Nombres de collaborateurs par spécialité
   - Designs avec couleurs gradient

6. **CTA Section**
   - "Rejoignez FUTURISTE"
   - Bouton vers recrutement/contact

**Fallback Data:**
- Timeline hardcodée si DB vide
- Stats fallback si requête échoue
- 100% fonctionnel sans base de données

---

### 💼 `services.php` - Services
**Structure complète:**

1. **Hero Services**
   - "Nos Services Premium"
   - Tagline descriptif

2. **6 Services en Grille** (2 colonnes)
   
   **Service 1: Web Premium**
   - Description: Sites haute performance
   - Features: React 19, Vue 3, Next.js, Performance 99/100
   - Couleur: Cyan (#00FFFF)

   **Service 2: Mobile Apps**
   - Description: iOS & Android natifs
   - Features: Flutter, SwiftUI, Kotlin, 500K+ installs
   - Couleur: Violet (#7B2FFF)

   **Service 3: IA & ML**
   - Description: IA générative & LLM custom
   - Features: Claude API, Fine-tuning, RAG, 99.2% accuracy
   - Couleur: Pink (#FF2D78)

   **Service 4: Design & UX 3D**
   - Description: Expériences immersives
   - Features: Figma Design System, Three.js, WebGL
   - Couleur: Green (#00ff88)

   **Service 5: Cybersecurity & Cloud**
   - Description: Infrastructure sécurisée
   - Features: AWS, GCP, Kubernetes, Audit SOC2
   - Couleur: Yellow (#FFCC00)

   **Service 6: Web3 & Metaverse**
   - Description: Smart Contracts & NFT
   - Features: Solidity, Web3.js, Blockchain, DAO
   - Couleur: Orange (#FF6B35)

3. **Tableau Comparatif**
   - FUTURISTE vs Agences classiques
   - 6 critères comparaison
   - Checkmarks/X visuels

4. **5-Step Process**
   - Pipeline visuel de projet
   - Étapes: Découverte → Stratégie → Design → Dev → Livraison
   - Connecteur gradient line animé

5. **CTA Section**
   - "Commençons votre transformation"

**Fallback:**
- 6 services hardcodés avec features JSON
- Comparaison tableau statique
- Process étapes fixes

---

### 🎯 `portfolio.php` - Portfolio
**Structure complète:**

1. **Hero Portfolio**
   - "PORTFOLIO"
   - "8 projects AAA pour les plus grandes marques"

2. **Grille 8 Projets** (2 colonnes × 4 lignes)

   **Chaque projet contient:**
   - Image (proyecto.jpg) avec fallback
   - Catégorie badge (web/mobile/ia)
   - Titre projet
   - Nom client
   - Description longue (50+ mots)
   - Tech Stack (5-6 technologies avec badges)
   - Résultats clés (métriques business)
   - Durée projet
   - Lien "Voir détails"

   **Projets (8):**
   1. **NeoBank Pro** - Fintech, React, +340% conversions
   2. **LUXE AR** - Luxe, Three.js, 15M impressions
   3. **MedAI** - Healthcare, Claude API, 99.2% accuracy
   4. **SpaceTrack 3D** - Spatial, Three.js, 12K objets 3D
   5. **FitGenius** - Fitness, Flutter, 500K users
   6. **MetaVerse Fashion** - Metaverse, Babylon.js, 2.5M$ NFT
   7. **CryptoExchange** - Crypto, Solidity, 500M$ TVL
   8. **EduVR** - EdTech, WebXR, 150K students

3. **Section Statistiques Globales** (4 colonnes)
   - 157 projets livrés
   - +520% avg conversion lift
   - 99.2% client satisfaction
   - 18 pays couverts

4. **CTA Final**
   - "Votre projet mérite une agence FUTURISTE"

**Fallback:**
- 8 projets hardcodés complets
- Images: /agence-futuriste/assets/images/projetX.jpg
- Toutes les données JSON encodées
- 100% fonctionnel offline

---

### 👥 `team.php` - Équipe
**Structure complète:**

1. **Hero Équipe**
   - "Notre Équipe d'Experts"
   - Tagline

2. **Grille 8 Membres** (4 colonnes × 2 lignes)
   
   **Chaque membre contient:**
   - Avatar (initiales dans gradient coloré)
   - Nom complet
   - Role/Titre
   - Biographie détaillée (100+ mots)
   - Email contact
   - Liens sociaux (LinkedIn, GitHub)
   - Couleur accent personnalisée

   **Membres (8):**
   1. **Alice Leclerc** - CTO, Architecte cloud Kubernetes
   2. **Marc Delorme** - CEO, Fondateur & Visionnaire
   3. **Sarah Bouvier** - Head of IA, ML Engineer senior
   4. **Guillaume Durand** - CTO Architect, Infrastructure expo
   5. **Émilie Moreau** - UX Lead, Design System expert
   6. **Thomas Garnier** - DevOps/SRE, AWS certified
   7. **Claude Petit** - 3D Artist, WebGL specialist
   8. **Amélie Fontaine** - Web3 Engineer, Solidity expert

3. **Section Recrutement**
   - "Rejoignez FUTURISTE"
   - 3 postes ouverts

   **Offres (3):**
   1. Senior React Developer - €85-110K
   2. ML Engineer - €90-120K
   3. DevOps/SRE - €95-130K

   Chaque offre avec:
   - Titre poste
   - Stack technologie
   - Salaire fourchette
   - Description compétences

4. **CTA Carrière**
   - Lien vers page recrutement
   - Bouton "POSTULER"

**Fallback:**
- 8 membres hardcodés avec bios complètes
- 3 postes ouverts hardcodés
- Fonction PHP adjustColorBrightness() pour gradient darkening
- 100% responsive 4-col → 2-col → 1-col

---

### 💰 `pricing.php` - Tarification
**Structure complète:**

1. **Hero Pricing**
   - "Nos Plans de Tarification"
   - "Transparent et Flexible"

2. **3 Plans de Pricing** (3 colonnes)

   **Plan 1: GROWTH** (€4,900/projet)
   - Site web vitrine premium
   - 3D animations + Canvas
   - CMS administration
   - 3 mois support inclus
   - 7+ features checklist
   - Couleur: Cyan

   **Plan 2: ENTERPRISE** (€12,900/projet)
   - ✨ RECOMMANDÉ (badge pink)
   - Tout du GROWTH +
   - E-commerce complet
   - IA intégration
   - App mobile incluse
   - 12 mois support premium
   - 10+ features checklist
   - Couleur: Pink border highlight
   - Bonus: "Choisir les clients leaders"

   **Plan 3: CUSTOM** (Sur mesure)
   - Web3 & IA native
   - Infrastructure scalable
   - Équipe dédiée (2-5 devs)
   - Support 24/7
   - 6-18 mois durée moyenne
   - Couleur: Violet

3. **Tableau Comparatif Features**
   - Tous les plans côte à côte
   - Features checkmarks/X
   - Détails inclusions

4. **Disclaimer Tarif**
   - "TVA 20% applicable"
   - "Frais d'intégration externes non inclus"
   - "Prix dégressif 2+ projets/an"

5. **CTA Principal**
   - "APPEL GRATUIT"
   - Consulting call scheduling

**Fallback:**
- 3 plans hardcodés complets
- Features arrays JSON
- Pricing statique si DB vide

---

### ❓ `faq.php` - FAQ
**Structure complète (20 Questions):**

1. **Hero Section**
   - "Questions Fréquentes"
   - "Trouvez les réponses"

2. **4 Catégories Tabs**
   - Toggle catégories facilement

3. **20 Questions Accordion**
   - HTML `<details>/<summary>` pattern
   - CSS animé expand/collapse
   - Hover: border color change + bg opacity

   **Catégorie 1: Général (5Q)**
   - Qui est FUTURISTE?
   - Dans quels pays?
   - Types de clients?
   - Visites bureau possible?
   - Confidentialité garantie?

   **Catégorie 2: Technique (5Q)**
   - Quelles technologies?
   - Propriété code source?
   - Scalabilité solution?
   - Audits de sécurité?
   - Transition d'équipe?

   **Catégorie 3: Tarifs (5Q)**
   - TVA incluse?
   - Mode de paiement?
   - Coûts cachés?
   - Flexibilité budget?
   - Réductions volume?

   **Catégorie 4: Support (5Q)**
   - Support inclus?
   - Report bugs critiques?
   - Évolutions post-launch?
   - PM dédié?
   - Options support long-terme?

4. **CTA Section**
   - "Autres questions?"
   - Email support: contact@futuriste.dev

**Fallback:**
- 20 Q/A hardcodées groupées par catégorie
- Associative array PHP
- 100% functional offline

---

### 📖 `blog.php` - Blog
**Structure complète:**

1. **Hero Blog**
   - "Blog FUTURISTE"
   - "Insights & Tendances Tech"

2. **9 Articles Grille** (3 colonnes)
   - Staggered fadeInUp animations
   - Animation-delay: index × 0.1s

   **Chaque article card contient:**
   - Image (proyecto.jpg)
   - Catégorie badge (couleur)
   - Titre article
   - Excerpt/résumé court
   - Auteur nom
   - Temps lecture estimation
   - Date publication
   - Lien "Lire plus"

   **Articles (9):**
   1. "IA Générative & Web Dev 2025" - 12 min
   2. "Three.js Advanced Features 2025" - 8 min
   3. "E-Commerce Growth Story: 0→2M€" - 15 min
   4. "Flutter vs React Native 2025" - 10 min
   5. "RAG Implementation Avancée" - 18 min
   6. "CSS 2025: New Features" - 7 min
   7. "Smart Contract Common Errors" - 14 min
   8. "UX Research 10K Users" - 9 min
   9. "Microservices vs Monolith" - 11 min

3. **Newsletter Signup** (Section bas)
   - Email input field
   - "Subscribe" button
   - Intégration backend newsletter

4. **CTA Blog**
   - "Rester informé des tendances"

**Fallback:**
- 9 articles hardcodés avec métadonnées complètes
- JSON avec categories, tags, authors
- Dates et temps lecture calculés
- Grid responsive 3→2→1

---

### 📧 `contact.php` - Contact (À créer)
**Structure suggérée:**

1. **Hero Contact**
2. **Formulaire Contact** (Champs)
   - Nom
   - Email
   - Entreprise
   - Budget
   - Service intéressé
   - Message
   - Checkbox acceptation politique
3. **Traitement formulaire**
   - Validation PHP côté serveur
   - Insert table `contact_messages`
   - Email notification admin
4. **Info Contact**
   - Adresse bureau
   - Email info@futuriste.dev
   - Tél: +33 X XX XX XX XX
   - Horaires
5. **Map Localisation** (Google Maps/Mapbox)

---

## 🎨 Assets & Ressources

### CSS Architecture (`assets/css/`)

**styles.css** - Styles Globaux
```css
/* Design System */
:root {
  --primary: #00FFFF;
  --secondary: #7B2FFF;
  --accent: #FF2D78;
  --success: #00ff88;
  --warning: #FFCC00;
  --danger: #FF6B35;
  --dark: #020408;
  --bg-dark: #0a0e1a;
  --bg-darker: #050a12;
  --text-main: #ffffff;
  --text-muted: #a0a9c4;
  --glass-light: rgba(255,255,255,0.05);
  --glass-dark: rgba(0,0,0,0.3);
}

/* Glassmorphism */
.glass {
  background: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
}

/* Texte Gradient */
.text-gradient {
  background: linear-gradient(135deg, #00FFFF, #7B2FFF);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
```

**animations.css** - Animations
```css
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes glow {
  0%, 100% {
    box-shadow: 0 0 10px rgba(0, 255, 255, 0.3);
  }
  50% {
    box-shadow: 0 0 20px rgba(0, 255, 255, 0.6);
  }
}
```

**cyberpunk-theme.css** - Thème Cyberpunk
- Neon glows & shadows
- Textures grain
- Color flash effects
- Glitch animations

### JavaScript (`assets/js/`)

**main.js** - Logic Principal
- Document ready
- Global event listeners
- Page initialization

**hero-canvas.js** - Hero Canvas Animation
- WebGL/Canvas initialization
- Particle effects
- Interactive animations
- Resize handlers

**portfolio.js** - Portfolio Interactivité
- Filter buttons functionality
- Category switching
- Modal project details
- Smooth transitions

**smooth-scroll.js** - Scroll Fluide
- ScrollBehavior polyfill
- Smooth anchor links
- Parallax effects

### Images (`assets/images/`)

**Projets:**
- `projet1.jpg` - NeoBank Pro
- `projet2.jpg` - LUXE AR
- `projet3.jpg` - MedAI
- `projet4.jpg` - SpaceTrack 3D
- `projet5.jpg` - FitGenius
- `projet6.jpg` - MetaVerse Fashion
- `projet7.jpg` - CryptoExchange
- `projet8.jpg` - EduVR

**Branding:**
- `logo.png` - Logo FUTURISTE
- `favicon.ico` - Favicon

**Avatars:**
- `avatar-alice.jpg`
- `avatar-marc.jpg`
- (etc. pour 8 membres)

---

## 📦 Includes Réutilisables

### `includes/header.php`
Inclus en haut TOUTES les pages

```php
<?php
// Doctype, meta tags
// HTML5 head complet
// Navigation principale globale
// Styles CSS
// Variables globales
?>
```

**Contenu:**
- `<!DOCTYPE html>`
- Meta charset, viewport, SEO
- OG tags (Open Graph)
- Favicon links
- CSS imports (styles.css, animations.css)
- Navigation bar avec logo + menu
- Hero section placeholder

### `includes/footer.php`
Inclus en bas TOUTES les pages

```php
<?php
// Container footer
// Copyright FUTURISTE
// Liens rapides
// Réseaux sociaux
// JavaScript imports
?>
```

**Contenu:**
- Container pied page
- Copyright © 2024 FUTURISTE
- Links: Privacy, Legal, Sitemap, RSS
- Social icons (LinkedIn, GitHub, Twitter)
- JS scripts: main.js, animations.js, hero-canvas.js
- Google Analytics/Tracking codes

### `includes/functions.php`
Utilitaires PHP réutilisables

**Fonctions:**
```php
formatDateFr($date, $format) // Format date FR
truncateText($text, $length) // Truncate sécurisé
generateSlug($string)        // URL-friendly slug
isValidEmail($email)         // Email validation
cleanHtml($html)             // HTML cleanup
estimateReadingTime($text)   // Reading time estimator
getExcerpt($text, $length)   // Auto excerpt
```

---

## 🔐 Patterns & Conventions

### Pattern 1: Database Fallback
**Toutes les pages implémentent ce pattern:**

```php
<?php
try {
    $data = $pdo->query("SELECT * FROM table")->fetchAll();
} catch(PDOException $e) {
    $data = [];
}

// Fallback: données hardcodées si DB vide
if(empty($data)) {
    $data = [
        ['id' => 1, 'titre' => '...', ...],
        ['id' => 2, 'titre' => '...', ...],
    ];
}

// Maintenant $data est TOUJOURS rempli
foreach($data as $item) {
    // Affichage
}
?>
```

### Pattern 2: Sécurité HTMLSpecialChars
**Toutes les sorties utilisateur:**
```php
<?= htmlspecialchars($variable) ?>
<?= htmlspecialchars($projet['titre']) ?>
<?= htmlspecialchars($variable) ?>
```

### Pattern 3: Animations Staggered
**Grilles avec animations décalées:**
```php
<?php foreach($items as $index => $item): ?>
<div style="animation: fadeInUp 0.8s ease forwards; 
            animation-delay: <?= $index * 0.1 ?>s;">
    ...
</div>
<?php endforeach; ?>
```

### Pattern 4: JSON Features
**Technologies et features stockées en JSON:**
```php
$technos = json_encode(['React 19', 'Node.js', 'PostgreSQL']);

// Plus tard:
$techs = json_decode($projet['technos'], true);
foreach($techs as $tech) {
    echo htmlspecialchars($tech);
}
```

### Pattern 5: Fallback Images
**Tous les tags img:**
```html
<img src="/agence-futuriste/assets/images/projet1.jpg" 
     alt="..."
     onerror="this.style.display='none';">
```

---

## 🎯 Architecture MVC Légère

```
Couche Présentation (Frontend)
├── HTML + CSS + JS
└── Animations staggered

Couche Business (PHP Pages)
├── Inclusions header/footer
├── Requêtes PDO
├── Fallback hardcodée
└── Rendu HTML

Couche Données (MySQL)
├── 8 tables principales
├── Schéma UTF8MB4
└── Fixtures seed.sql
```

---

## 📱 Responsive Design

### Breakpoints CSS
```css
/* Desktop: 1920px */
/* Tablet: 768px - 1024px */
/* Mobile: 320px - 767px */

/* Grid Responsive */
@media (max-width: 1024px) {
    grid-template-columns: repeat(2, 1fr);
}

@media (max-width: 768px) {
    grid-template-columns: 1fr;
}
```

### Adaptations Pages:
- **Portfolio:** 2 cols → 1 col
- **Team:** 4 cols → 2 cols → 1 col
- **Services:** 2 cols → 1 col
- **Blog:** 3 cols → 2 cols → 1 col

---

## 🚀 Performance & Optimisation

### Optimisations Implémentées:
- ✅ Images: fallback onerror + lazy loading
- ✅ CSS: Minifiée + Inlined small styles
- ✅ JS: Vanilla (zéro dependencies)
- ✅ Caching: Headers PHP cache-control
- ✅ Charset: UTF8MB4 complet
- ✅ Async: Defer scripts en footer

### Metrics Cibles:
- Lighthouse: 90+
- Core Web Vitals: GOOD
- LCP: <2.5s
- FID: <100ms
- CLS: <0.1

---

## 🔄 Workflow Développement

### Cycle de Développement:

1. **Phase 1: Setup Initial**
   ```bash
   database/schema.sql     # Créer schéma
   database/seed.sql       # Charger data test
   ```

2. **Phase 2: Development**
   - Edit pages PHP
   - Test localhost:80
   - Vérifier fallback sans DB

3. **Phase 3: Design**
   - Audit CSS (animations, colors)
   - Test responsive (768px, 1024px)
   - Vérifier Glassmorphism

4. **Phase 4: Testing**
   - Cross-browser (Chrome, Firefox, Safari)
   - Performance (PageSpeed)
   - Accessibility (a11y)

5. **Phase 5: Deployment**
   - Upload via FTP/SFTP
   - Vérifier config DB production
   - Test URLs canoniques

---

## 📚 Technologies Stack

### Frontend
- **HTML5** - Markup sémantique
- **CSS3** - Animations, Glassmorphism, Gradients
- **Vanilla JavaScript** - Zéro framework externe
- **Canvas API** - Hero animations
- **WebGL** - Future 3D features

### Backend
- **PHP 8.0+** - Langage serveur
- **PDO** - Accès database abstrait
- **MySQL 8.0+** - Base de données
- **UTF8MB4** - Support Unicode

### Design System
- **Glassmorphism UI** - Modern design
- **Cyberpunk Theme** - Aesthetic futuriste
- **Color Palette** - Neon colors (Cyan, Violet, Pink, Green, Yellow)
- **Typography** - Orbitron (headings), Rajdhani (body), Share Tech Mono (code)

### Fonts
```html
<!-- Headings -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900">

<!-- Body -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700">

<!-- Monospace -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono">
```

---

## 🛠️ Installation & Setup

### Prérequis:
- Apache 2.4+
- PHP 8.0+
- MySQL 8.0+
- localhost:80

### Étapes Déploiement:

1. **Dossier root:**
   ```bash
   cp -r agence-futuriste/ /var/www/html/
   cd /var/www/html/agence-futuriste
   ```

2. **Database:**
   ```bash
   mysql -u root -p < database/schema.sql
   mysql -u root -p nexus_digital < database/seed.sql
   ```

3. **Config DB** (`config/db.php`):
   ```php
   DB_HOST = 'localhost'
   DB_NAME = 'nexus_digital'
   DB_USER = 'root'
   DB_PASS = 'YOUR_PASSWORD'
   ```

4. **Permissions:**
   ```bash
   chmod 755 .
   chmod 755 assets/
   chmod 644 assets/**/*
   ```

5. **Test:**
   ```
   http://localhost/agence-futuriste/
   ```

---

## 🔗 URLs & Routes

| Page | Route | Description |
|------|-------|------------|
| Accueil | `/index.php` | Hero + 5 sections |
| À Propos | `/about.php` | Timeline, Mission, Stats |
| Services | `/services.php` | 6 services + processo |
| Portfolio | `/portfolio.php` | 8 projets AAA |
| Équipe | `/team.php` | 8 membres + recrutement |
| Tarification | `/pricing.php` | 3 plans pricing |
| FAQ | `/faq.php` | 20 questions |
| Blog | `/blog.php` | 9 articles |
| Contact | `/contact.php` | Formulaire (à créer) |

---

## 📝 Checklist Complétude

### Pages Complètes ✅
- [x] index.php - Accueil complet
- [x] about.php - À propos enrichi
- [x] services.php - Services + tableau comp
- [x] portfolio.php - 8 projets AAA (BUG FIXÉ)
- [x] team.php - 8 membres + recrutement
- [x] pricing.php - 3 plans complets
- [x] faq.php - 20 Q&A accordion
- [x] blog.php - 9 articles article
- [ ] contact.php - À créer

### Database ✅
- [x] Schema SQL (9 tables)
- [x] Seed.sql (fixtures)
- [x] Fallback hardcoded toutes pages

### Assets ✅
- [x] CSS globaux + animations
- [x] JS main + hero-canvas
- [x] Images projets (projet1-8)
- [x] Logo + favicon

### Configuration ✅
- [x] config/db.php - PDO setup
- [x] includes/header.php - Navigation
- [x] includes/footer.php - Scripts
- [x] includes/functions.php - Utilitaires

---

## 🐛 Bugs Connus & Fixes

### Bug 1: Parse Error portfolio.php (FIXÉ ✅)
**Symptôme:** "Parse error: syntax error, unexpected token endforeach" ligne 268
**Cause:** Deux versions de code fusionnées, ~60 lignes de code parasitaire après première version complète
**Solution:** Suppression du code dupliqué après line 301, garde seule version complète propre
**Statut:** ✅ FIXÉ - File now valid

---

## 📞 Support & Contact

**Email:** contact@futuriste.dev  
**Téléphone:** +33 XX XX XX XX XX  
**Adresse:** [À compléter]  
**Horaires:** Lun-Ven 9h-18h  

---

## 📈 Roadmap Futur

- [ ] Créer page contact.php complète
- [ ] API REST endpoints (/api/projets, /api/team, etc.)
- [ ] Client admin dashboard
- [ ] Blog article filtering + search
- [ ] Intégration e-mail newsletter (MailerLite/SendGrid)
- [ ] Form validation frontend + backend
- [ ] SEO optimization (sitemap.xml, robots.txt)
- [ ] Analytics (Google Analytics 4)
- [ ] CMS management interface
- [ ] Dark mode toggle
- [ ] Multi-language support (EN, ES, DE)
- [ ] WebP image optimization
- [ ] Service worker + PWA

---

## 📄 Fichiers de Référence

```
📁 Documentation Files
├── DOCUMENTATION_PROJET.md (CE FICHIER)
├── database/schema.sql
├── database/seed.sql
├── README.md (À créer)
└── CHANGELOG.md (À créer)
```

---

**Dernière mise à jour:** 1 Mai 2026  
**Version:** 1.0.0 PRODUCTION READY  
**Statut:** ✅ COMPLET - Toutes pages enrichies + Bug fixes appliqués  

**💻 Made with ❤️ by FUTURISTE Development Team**

---

## 📚 Ressources Externes

- [PHP 8 Docs](https://www.php.net/docs.php)
- [PDO Tutorial](https://www.php.net/manual/en/book.pdo.php)
- [MySQL 8 Reference](https://dev.mysql.com/doc/refman/8.0/en/)
- [CSS-Tricks Glassmorphism](https://css-tricks.com/backdrop-filter/)
- [MDN Web Docs](https://developer.mozilla.org/)
- [Web.dev Performance](https://web.dev/)

---

**FIN DE DOCUMENTATION** 🎉
