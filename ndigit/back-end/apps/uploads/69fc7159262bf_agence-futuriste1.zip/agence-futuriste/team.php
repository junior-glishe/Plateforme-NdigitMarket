<?php 
require_once 'includes/header.php'; 
require_once 'config/db.php'; 
require_once 'includes/functions.php';

try {
    $membres = $pdo->query("SELECT * FROM team_members WHERE actif=1 ORDER BY ordre")->fetchAll();
} catch(PDOException $e) {
    $membres = [];
}

// Fallback: 8 membres si DB vide
if(empty($membres)) {
    $membres = [
        [
            'nom' => 'Leclerc',
            'prenom' => 'Alice',
            'role' => 'Founder & CTO',
            'bio' => 'Ancienne lead frontend chez Facebook Paris pendant 5 ans. Passionnée par Three.js et expériences immersives. 15+ ans d\'expertise web.',
            'couleur_accent' => '#00FFFF',
            'linkedin' => 'https://linkedin.com/in/alice-leclerc',
            'github' => 'https://github.com/aliceFX'
        ],
        [
            'nom' => 'Delorme',
            'prenom' => 'Marc',
            'role' => 'Co-Founder & CEO',
            'bio' => 'Entrepreneur tech depuis 2010. Ancien VP Sales chez N26. A levé 3M€ pour FUTURISTE. Visionnaire du Web3 et IA.',
            'couleur_accent' => '#7B2FFF',
            'linkedin' => 'https://linkedin.com/in/marc-delorme',
            'github' => 'https://github.com/mdelorme'
        ],
        [
            'nom' => 'Bouvier',
            'prenom' => 'Sarah',
            'role' => 'Head of AI Studio',
            'bio' => 'PhD Machine Learning (Stanford 2018). Publiée dans NeurIPS et ICCV. Spécialiste RAG et fine-tuning LLMs. 12+ modèles en production.',
            'couleur_accent' => '#FF2D78',
            'linkedin' => 'https://linkedin.com/in/sarah-bouvier',
            'github' => 'https://github.com/sbouvier-ai'
        ],
        [
            'nom' => 'Durand',
            'prenom' => 'Guillaume',
            'role' => 'Senior Architect Backend',
            'bio' => 'Rust et Kubernetes expert. Ex-engineer chez Cloudflare. Architecte des systèmes hyper-scalables servant 10M+ req/jour.',
            'couleur_accent' => '#00FF88',
            'linkedin' => 'https://linkedin.com/in/guillaume-durand',
            'github' => 'https://github.com/gdurand-rust'
        ],
        [
            'nom' => 'Moreau',
            'prenom' => 'Émilie',
            'role' => 'Lead UX Designer',
            'bio' => 'Design Lead ex-Airbnb. Obsession pour l\'accessibilité et user research. 10K+ utilisateurs testés sur 50+ projets.',
            'couleur_accent' => '#FFCC00',
            'linkedin' => 'https://linkedin.com/in/emilie-moreau',
            'github' => 'https://github.com/emilie-ux'
        ],
        [
            'nom' => 'Garnier',
            'prenom' => 'Thomas',
            'role' => 'DevOps & Security',
            'bio' => 'Certified OSCP et ISO 27001 lead auditor. Infrastructure zen sous Kubernetes. Zéro breach en 8 ans.',
            'couleur_accent' => '#FF6B35',
            'linkedin' => 'https://linkedin.com/in/thomas-garnier',
            'github' => 'https://github.com/tgarnier-sec'
        ],
        [
            'nom' => 'Petit',
            'prenom' => 'Claude',
            'role' => '3D Lead Artist',
            'bio' => 'Senior 3D artist (Blender, Three.js, WebGL). Ancien CG Lead chez Ubisoft. Creator des 50+ WebGL experiences FUTURISTE.',
            'couleur_accent' => '#4495FF',
            'linkedin' => 'https://linkedin.com/in/claude-petit',
            'github' => 'https://github.com/claude-3d'
        ],
        [
            'nom' => 'Fontaine',
            'prenom' => 'Amélie',
            'role' => 'Smart Contracts Engineer',
            'bio' => 'Web3 dev depuis 2017. Smart contracts audités pour 5+ projets DeFi. Solidity, Cairo, Move. 50M$ TVL géré.',
            'couleur_accent' => '#6495ED',
            'linkedin' => 'https://linkedin.com/in/amelie-fontaine',
            'github' => 'https://github.com/amelie-web3'
        ]
    ];
}

$page_script = 'assets/js/team.js';
?>


<main>
    <!-- HERO CONSTELLATION -->
    <section class="hero" style="padding-top: 120px;">
        <canvas id="team-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container" style="position: relative; z-index: 2;">
            <h1 class="hero-title" style="color: #FFFFFF;">NOTRE ÉQUIPE</h1>
            <p class="hero-subtitle" style="font-size: 1.3rem; max-width: 900px;">45 experts passionnés qui défient les limites du possible. Chacun apporte une expertise unique au service de vos ambitions digitales.</p>
        </div>
    </section>

    <!-- GRILLE MEMBRES -->
    <section class="section">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 2rem; margin-bottom: 4rem;">
                <?php foreach($membres as $index => $membre): ?>
                <div class="glass" style="padding: 2rem; border-radius: 12px; text-align: center; border: 1px solid rgba(0,255,255,0.1); transition: all 0.3s; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: <?= $index * 0.1 ?>s; cursor: pointer;" onmouseover="this.style.borderColor='<?= htmlspecialchars($membre['couleur_accent']) ?>'; this.style.boxShadow='0 0 30px rgba(0,255,255,0.2)'" onmouseout="this.style.borderColor='rgba(0,255,255,0.1)'; this.style.boxShadow=''">
                    
                    <!-- Avatar -->
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, <?= htmlspecialchars($membre['couleur_accent']) ?>, <?= htmlspecialchars(adjustColorBrightness($membre['couleur_accent'], -30)) ?>); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem; font-size: 1.8rem; font-weight: 900; color: #fff; box-shadow: 0 0 40px <?= htmlspecialchars($membre['couleur_accent']) ?>40;">
                        <?= strtoupper(substr($membre['prenom'] ?? '', 0, 1) . substr($membre['nom'] ?? '', 0, 1)) ?>
                    </div>
                    
                    <!-- Info -->
                    <h3 style="color: #FFFFFF; margin-bottom: 0.5rem; font-family: 'Orbitron';"><?= htmlspecialchars($membre['prenom'] . ' ' . $membre['nom']) ?></h3>
                    <p style="color: <?= htmlspecialchars($membre['couleur_accent']) ?>; font-weight: 600; margin-bottom: 1rem; font-size: 0.95rem;"><?= htmlspecialchars($membre['role']) ?></p>
                    
                    <!-- Bio -->
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem; font-size: 0.9rem;"><?= htmlspecialchars($membre['bio']) ?></p>
                    
                    <!-- Socials -->
                    <div style="display: flex; gap: 1rem; justify-content: center; opacity: 0.7; transition: opacity 0.3s;">
                        <?php if(!empty($membre['linkedin'])): ?>
                        <a href="<?= htmlspecialchars($membre['linkedin']) ?>" target="_blank" style="color: var(--text-muted); text-decoration: none; font-size: 1.2rem; transition: color 0.3s;" onmouseover="this.style.color='#0A66C2'" onmouseout="this.style.color='var(--text-muted)'">in</a>
                        <?php endif; ?>
                        <?php if(!empty($membre['github'])): ?>
                        <a href="<?= htmlspecialchars($membre['github']) ?>" target="_blank" style="color: var(--text-muted); text-decoration: none; font-size: 1.2rem; transition: color 0.3s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='var(--text-muted)'">gh</a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- SECTION RECRUTEMENT -->
    <section class="section" style="background: rgba(123,47,255,0.05);">
        <div class="container">
            <h2 class="section-title text-gradient" style="text-align: center; margin-bottom: 3rem;">NOUS RECRUTONS!</h2>
            <p style="text-align: center; color: var(--text-muted); max-width: 700px; margin: 0 auto 3rem; font-size: 1.1rem;">FUTURISTE grandit. Rejoignez une équipe de passionnés qui repoussent les limites du digital chaque jour.</p>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem;">
                
                <!-- Senior React Developer -->
                <div class="glass" style="padding: 2rem; border-radius: 12px; border-left: 4px solid #00FFFF;">
                    <h3 style="color: #00FFFF; margin-bottom: 1rem; font-family: 'Orbitron';">Senior React/Next.js Developer</h3>
                    <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
                        <span style="background: rgba(0,255,255,0.2); color: #00FFFF; padding: 0.4rem 0.8rem; border-radius: 4px; font-size: 0.85rem;">Paris</span>
                        <span style="background: rgba(0,255,255,0.2); color: #00FFFF; padding: 0.4rem 0.8rem; border-radius: 4px; font-size: 0.85rem;">CDI</span>
                    </div>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem; font-size: 0.95rem;">5+ ans d'expérience React. Expertise Three.js/WebGL un plus. Salaire: <strong style="color: #00FFFF;">85-110K€</strong> selon profil.</p>
                    <a href="contact.php?poste=senior-react" style="color: #00FFFF; text-decoration: none; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.opacity='0.7'" onmouseout="this.style.opacity='1'">Postuler →</a>
                </div>

                <!-- ML Engineer -->
                <div class="glass" style="padding: 2rem; border-radius: 12px; border-left: 4px solid #FF2D78;">
                    <h3 style="color: #FF2D78; margin-bottom: 1rem; font-family: 'Orbitron';">ML Engineer / Research</h3>
                    <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
                        <span style="background: rgba(255,45,120,0.2); color: #FF2D78; padding: 0.4rem 0.8rem; border-radius: 4px; font-size: 0.85rem;">Paris/Remote</span>
                        <span style="background: rgba(255,45,120,0.2); color: #FF2D78; padding: 0.4rem 0.8rem; border-radius: 4px; font-size: 0.85rem;">CDI</span>
                    </div>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem; font-size: 0.95rem;">ML/DL expertise (PyTorch/TensorFlow). Production deployment experience. Salaire: <strong style="color: #FF2D78;">90-120K€</strong> selon profil.</p>
                    <a href="contact.php?poste=ml-engineer" style="color: #FF2D78; text-decoration: none; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.opacity='0.7'" onmouseout="this.style.opacity='1'">Postuler →</a>
                </div>

                <!-- Fullstack DevOps -->
                <div class="glass" style="padding: 2rem; border-radius: 12px; border-left: 4px solid #7B2FFF;">
                    <h3 style="color: #7B2FFF; margin-bottom: 1rem; font-family: 'Orbitron';">DevOps/SRE Senior</h3>
                    <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
                        <span style="background: rgba(123,47,255,0.2); color: #7B2FFF; padding: 0.4rem 0.8rem; border-radius: 4px; font-size: 0.85rem;">Paris</span>
                        <span style="background: rgba(123,47,255,0.2); color: #7B2FFF; padding: 0.4rem 0.8rem; border-radius: 4px; font-size: 0.85rem;">CDI</span>
                    </div>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem; font-size: 0.95rem;">Kubernetes/Terraform expert. Security-first mindset. Salaire: <strong style="color: #7B2FFF;">95-130K€</strong> selon profil.</p>
                    <a href="contact.php?poste=devops-sre" style="color: #7B2FFF; text-decoration: none; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.opacity='0.7'" onmouseout="this.style.opacity='1'">Postuler →</a>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="section">
        <div class="container" style="text-align: center;">
            <h2 style="font-size: 2rem; margin-bottom: 1.5rem;">Pas le poste qu'il vous faut?</h2>
            <p style="color: var(--text-muted); margin-bottom: 2rem; font-size: 1.1rem;">Envoyez-nous votre CV et parlons de votre projet 🚀</p>
            <a href="contact.php" class="btn btn-primary" style="display: inline-block; padding: 1rem 3rem; font-size: 1.1rem;">REJOINDRE L'ÉQUIPE</a>
        </div>
    </section>
</main>

<style>
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<?php 
function adjustColorBrightness($hex, $percent) {
    $hex = ltrim($hex, '#');
    $rgb = array_map('hexdec', str_split($hex, 2));
    foreach($rgb as &$color) {
        $color = max(0, min(255, $color + ($percent * 2.55)));
    }
    return '#' . sprintf('%02x%02x%02x', $rgb[0], $rgb[1], $rgb[2]);
}
require_once 'includes/footer.php'; 
?>
