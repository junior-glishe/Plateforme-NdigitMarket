<?php 
require_once 'includes/header.php'; 
require_once 'config/db.php'; 
require_once 'includes/functions.php';

try {
    $faqs = $pdo->query("SELECT * FROM faq WHERE actif=1 ORDER BY categorie, ordre")->fetchAll();
    $categories = $pdo->query("SELECT DISTINCT categorie FROM faq WHERE actif=1 ORDER BY categorie")->fetchAll();
    $faqs_grouped = [];
    foreach($faqs as $faq) {
        $faqs_grouped[$faq['categorie']][] = $faq;
    }
} catch(PDOException $e) {
    $faqs_grouped = [
        'Général' => [
            ['question' => 'Qui est FUTURISTE?', 'reponse' => 'FUTURISTE est une agence digitale de 45 experts fondée en 2016. Spécialistes en web premium, IA, Web3, et expériences immersives 3D. Basée à Paris mais opérant dans 18 pays.'],
            ['question' => 'Dans quels pays opérez-vous?', 'reponse' => 'Nous opérons dans 18 pays en Europe, Asie, et Amérique du Nord. Clients incluent SpaceX, LVMH, BNP Paribas, L\'Oréal. Équipe distribuée avec bureaux à Paris, Berlin, Singapore.'],
            ['question' => 'Quel type de clients travaillez-vous?', 'reponse' => 'Startups (Series A-C), PME high-growth, grands groupes (Fortune 500), brands de luxe. Nous acceptons projets 5K€ à 1M€+. Secteurs: fintech, e-commerce, SaaS, healthcare, Web3.'],
            ['question' => 'Puis-je visiter vos bureaux?', 'reponse' => 'Bien sûr! Bureau principal: 123 Rue de Rivoli, Paris 1er. Visite virtuelle possible pour clients distants. Préférez vous rencontrer en personne sur un appel?'],
            ['question' => 'Confidentialité des données?', 'reponse' => 'Confidentialité absolue. NDA signé avant chaque engagement. ISO 27001 certified. Données clients encrypted end-to-end. Jamais partagées avec tiers.']
        ],
        'Technique' => [
            ['question' => 'Quelles technologies utilisez-vous?', 'reponse' => 'Frontend: React 19, Next.js, Three.js, WebGL. Backend: Node.js, Python, Rust. IA: Claude, GPT-4, TensorFlow, PyTorch. Web3: Solidity, Ethereum. Infrastructure: Kubernetes, AWS, GCP.'],
            ['question' => 'Qui est propriétaire du code?', 'reponse' => 'Vous. Code ownership complet transféré. Source code livré en fin de projet. Documentation technique incluse. Vous restez libre de changer de fournisseur après.'],
            ['question' => 'Vos solutions sont-elles scalables?', 'reponse' => 'Absolument. Architecture micro-services prête pour 1M+ utilisateurs. Tested sur 100K concurrent users. Load-balancing automatique, CDN global included. 99.9% uptime guarantee.'],
            ['question' => 'Auditez-vous votre code?', 'reponse' => 'Oui. Code review formalisé. Audits de sécurité externes (Web3: smart contract audits tiers). Tests automatisés 90%+ coverage. Performance profiling inclus.'],
            ['question' => 'Transition de code facile avec vous?', 'reponse' => 'Oui. Nous documentons tout. Formation équipe interne proposée (3 jours standard). Vous pourrez maintenir le code après notre départ seul.']
        ],
        'Tarifs' => [
            ['question' => 'Les tarifs incluent-ils la TVA?', 'reponse' => 'Non. Tarifs affichés hors TVA (20% applicable France). Devis final incluera TVA applicable selon votre localisation.'],
            ['question' => 'Conditions de paiement?', 'reponse' => '50% acompte avant démarrage. 50% à livraison/acceptance. Plans de paiement disponibles (financement partenaire pour Enterprise). Pas de frais additionnels.'],
            ['question' => 'Y a-t-il des frais cachés?', 'reponse' => 'Non. Transparence totale. Frais que vous pouvez rencontrer: intégrations API partenaires, licenses third-party (facultatif), hébergement annuel post-projet.'],
            ['question' => 'Dépassement budget possible?', 'reponse' => 'Rare. Scope bien défini en amont. Si changements majeurs pendant projet = amendement de contrat + ajustement prix. Accord avant tout travail additionnel.'],
            ['question' => 'Offrez-vous des réductions?', 'reponse' => 'Oui pour contrats long-terme (6+ mois = -10% à -20%). Non-profit, startups: -15% possible. Referral program: 10% commission sur nouveaux clients amenés.']
        ],
        'Support' => [
            ['question' => 'Support inclus après livraison?', 'reponse' => 'Oui. 3 mois gratuit (Growth), 12 mois premium (Enterprise). Support: bug fixes critiques, sécurité patches, optimisations. Nouvelles features: facturation horaire €85/h.'],
            ['question' => 'Comment reporter un bug critique?', 'reponse' => 'Slack/email direct à votre tech lead. SLA: réponse en 4h (bugs critiques), 24h (bugs majeurs). Production emergencies: support 24/7.'],
            ['question' => 'Pouvez-vous évolutionner le projet?', 'reponse' => 'Oui. Changements scopes facturés à l\'heure (€85/h). Roadmap product updates quarterly. Vous avez le contrôle priorités.'],
            ['question' => 'Un project manager dédié?', 'reponse' => 'Enterprise+: PM dédié. Growth: PM partagé. Réunions bi-hebdomadaires standard. Slack workspace privé pour communication.'],
            ['question' => 'Et après les 3-12 mois?', 'reponse' => 'Options: (1) Support ongoing payant €2K/mois. (2) Transition équipe interne (nous formons votre team). (3) Maintenance minimale €500/mois.']
        ]
    ];
    $categories = [
        ['categorie' => 'Général'],
        ['categorie' => 'Technique'],
        ['categorie' => 'Tarifs'],
        ['categorie' => 'Support']
    ];
}

$page_script = 'assets/js/faq.js';
?>

<main>
    <!-- HERO -->
    <section class="hero" style="padding-top: 120px;">
        <canvas id="faq-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container" style="position: relative; z-index: 2;">
            <h1 class="hero-title" style="color: #FFFFFF;">QUESTIONS FRÉQUENTES</h1>
            <p class="hero-subtitle" style="font-size: 1.2rem; max-width: 700px;">Tout ce que vous devez savoir sur nos services, tarifs et process</p>
        </div>
    </section>

    <!-- FAQ ACCORDÉON PAR CATÉGORIE -->
    <section class="section">
        <div class="container" style="max-width: 900px;">
            
            <?php foreach($faqs_grouped as $cat => $items): ?>
            <!-- CATÉGORIE -->
            <div style="margin-bottom: 4rem; opacity: 0; animation: fadeInUp 0.8s ease forwards;">
                <h2 class="section-title text-gradient" style="margin-bottom: 2rem; font-size: 1.8rem;"><?= htmlspecialchars($cat) ?></h2>
                
                <div style="display: grid; gap: 1rem;">
                    <?php foreach($items as $idx => $item): ?>
                    <details style="background: rgba(0,255,255,0.05); border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; padding: 1.5rem; cursor: pointer; transition: all 0.3s; group" open="<?= $idx === 0 ? 'open' : '' ?>">
                        <summary style="color: #00FFFF; font-weight: 700; user-select: none; display: flex; justify-content: space-between; align-items: center; transition: color 0.3s;">
                            <span><?= htmlspecialchars($item['question']) ?></span>
                            <span style="color: var(--text-muted); transition: transform 0.3s;">▼</span>
                        </summary>
                        <p style="color: var(--text-muted); margin-top: 1.5rem; line-height: 1.7; margin-bottom: 0;"><?= htmlspecialchars($item['reponse']) ?></p>
                    </details>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- CTA - CONTACT POUR PLUS -->
    <section class="section" style="background: rgba(123,47,255,0.05);">
        <div class="container" style="text-align: center;">
            <h2 style="font-size: 2rem; margin-bottom: 1rem;">Vous ne trouvez pas votre réponse?</h2>
            <p style="color: var(--text-muted); margin-bottom: 2rem; font-size: 1.1rem;">Envoyez-nous vos questions directement. Réponse sous 24h!</p>
            <a href="contact.php" class="btn btn-primary" style="display: inline-block; padding: 1rem 3rem; font-size: 1.1rem;">NOUS CONTACTER</a>
        </div>
    </section>
</main>

<style>
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

details[open] > summary span:last-child {
    transform: rotate(180deg);
}

details:hover {
    background: rgba(0,255,255,0.08) !important;
    border-color: rgba(0,255,255,0.2) !important;
}
</style>

<?php require_once 'includes/footer.php'; ?>

    <!-- ONGLETS -->
    <section class="section">
        <div class="container">
            <div class="tabs-header" style="display: flex; justify-content: center; gap: 1rem; margin-bottom: 3rem; flex-wrap: wrap;">
                <?php foreach($categories as $index => $cat): ?>
                <button class="tab-btn btn btn-outline <?= $index === 0 ? 'active' : '' ?>" 
                        data-tab="<?= htmlspecialchars($cat['categorie']) ?>"
                        style="border-color: <?= htmlspecialchars(getCategoryColor($cat['categorie'])) ?>; color: <?= htmlspecialchars(getCategoryColor($cat['categorie'])) ?>">
                    <?= ucfirst(htmlspecialchars($cat['categorie'])) ?>
                </button>
                <?php endforeach; ?>
            </div>
            
            <?php foreach($categories as $cat): $catName = $cat['categorie']; ?>
            <div class="tab-content" id="tab-<?= htmlspecialchars($catName) ?>" style="<?= $catName === 'general' ? '' : 'display: none;' ?>">
                <div class="faq-grid" data-animate="stagger">
                    <?php foreach($faqs_grouped[$catName] ?? [] as $faq): ?>
                    <div class="faq-item card fade-in">
                        <div class="faq-question" style="display: flex; justify-content: space-between; align-items: center; cursor: pointer; padding: 1.5rem; border-bottom: 1px solid var(--glass-border);">
                            <h3 style="margin: 0; flex: 1;"><?= htmlspecialchars($faq['question']) ?></h3>
                            <svg class="faq-arrow" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" style="transition: transform 0.3s; color: <?= htmlspecialchars(getCategoryColor($catName)) ?>;">
                                <polyline points="6,9 12,15 18,9"></polyline>
                            </svg>
                        </div>
                        <div class="faq-answer" style="max-height: 0; overflow: hidden; transition: max-height 0.4s ease; padding: 0 1.5rem 1.5rem;">
                            <div style="border-left: 3px solid <?= htmlspecialchars(getCategoryColor($catName)) ?>; padding-left: 1.5rem; opacity: 0; transform: translateX(20px); transition: all 0.3s 0.1s;">
                                <?= nl2br(htmlspecialchars($faq['reponse'])) ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
</main>

<?php 
function getCategoryColor($cat) {
    return match($cat) {
        'general' => '#00FFFF',
        'technique' => '#7B2FFF',
        'tarifs' => '#FF2D78',
        'support' => '#00FF88',
        default => '#00FFFF'
    };
}
include 'includes/footer.php'; 
?>
