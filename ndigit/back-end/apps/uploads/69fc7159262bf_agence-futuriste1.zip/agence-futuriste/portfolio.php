<?php 
require_once 'includes/header.php'; 
require_once 'config/db.php'; 
require_once 'includes/functions.php';
$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/agence-futuriste/';

try {
    $projets = $pdo->query("SELECT * FROM projets WHERE 1 ORDER BY ordre, created_at DESC")->fetchAll();
    $categories = $pdo->query("SELECT DISTINCT categorie FROM projets ORDER BY categorie")->fetchAll();
} catch(PDOException $e) {
    $projets = [];
    $categories = [];
}

// Fallback: 8 projets si DB vide
if(empty($projets)) {
    $projets = [
        [
            'titre' => 'NeoBank Pro',
            'slug' => 'neobank-pro',
            'client' => 'Fintech Series B',
            'categorie' => 'web',
            'description_courte' => 'Plateforme bancaire digitale next-gen',
            'description_longue' => 'Refonte complÃ¨te d\'une fintech. Interface React ultra-fluide, backend Rust 60K req/s, intÃ©grations bancaires complexes. RÃ©sultats: +340% conversions, +2.1M ARR.',
            'image' => 'projet1.jpg',
            'technos' => json_encode(['React 19', 'Node.js', 'PostgreSQL', 'Stripe API', 'Three.js']),
            'results' => '+340% conversions | +2.1Mâ‚¬ ARR | 150K users',
            'duree' => '5 mois'
        ],
        [
            'titre' => 'LUXE AR Experience',
            'slug' => 'luxe-ar',
            'client' => 'Groupe de Luxe International',
            'categorie' => 'web',
            'description_courte' => 'ExpÃ©rience AR pour essayer bijoux virtuels',
            'description_longue' => 'Campagne marketing immersive. AR try-on, WebGL shaders custom, rÃ©alitÃ© augmentÃ©e temps rÃ©el. Viral sur TikTok: 15M impressions. Conversion boutique +280%.',
            'image' => 'projet2.jpg',
            'technos' => json_encode(['Three.js', 'Babylon.js', 'AR.js', 'WebGL', 'Three Fiber']),
            'results' => '15M impressions | +280% ventes | 2M$ ROI',
            'duree' => '4 mois'
        ],
        [
            'titre' => 'MedAI Assistant',
            'slug' => 'medai-assistant',
            'client' => 'Startup Healthcare Series A',
            'categorie' => 'ia',
            'description_courte' => 'Diagnose assistant alimentÃ© par IA gÃ©nÃ©rative',
            'description_longue' => 'Claude API + RAG sur millions de cas mÃ©dicaux. Chatbot medical sÃ©curisÃ© HIPAA. Fine-tuning LLM custom. FDA pending. Confiance: 99.2% accuracy.',
            'image' => 'projet3.jpg',
            'technos' => json_encode(['Claude API', 'Python', 'LangChain', 'Pinecone VectorDB', 'FastAPI']),
            'results' => '99.2% accuracy | 50K consultations | 8/10 patients NPS',
            'duree' => '6 mois'
        ],
        [
            'titre' => 'SpaceTrack 3D',
            'slug' => 'spacetrack-3d',
            'client' => 'Startup Spatial Tech',
            'categorie' => 'web',
            'description_courte' => 'Visualisation 3D temps rÃ©el de satellites',
            'description_longue' => 'Dashboard immersif suivi 12K satellites. Three.js + WebGL avancÃ©. Mises Ã  jour temps rÃ©el WebSocket. Utilisable en VR (Meta Quest). Export rÃ©aliste NASA donnÃ©es.',
            'image' => 'projet4.jpg',
            'technos' => json_encode(['Three.js', 'Cesium.js', 'WebGL 2', 'WebSocket', 'Node.js']),
            'results' => '12K objets 3D | 60fps VR | 100K users',
            'duree' => '3 mois'
        ],
        [
            'titre' => 'FitGenius Mobile',
            'slug' => 'fitgenius',
            'client' => 'Fitness Unicorn',
            'categorie' => 'mobile',
            'description_courte' => 'App fitness IA qui prÃ©dit vos performances',
            'description_longue' => 'Flutter cross-platform (iOS + Android). ML model prÃ©dit progression workouts. IntÃ©gration Apple Watch + Garmin. Push notifications intelligentes. 500K users en 3 mois.',
            'image' => 'projet5.jpg',
            'technos' => json_encode(['Flutter', 'Firebase', 'TensorFlow Lite', 'Provider state', 'Native modules']),
            'results' => '500K users | 4.9/5 stars | 95% retention',
            'duree' => '4 mois'
        ],
        [
            'titre' => 'MetaVerse Fashion',
            'slug' => 'metaverse-fashion',
            'client' => 'Maison Mode Parisienne',
            'categorie' => 'web',
            'description_courte' => 'Monde virtuel 3D pour essayer vÃªtements',
            'description_longue' => 'Metaverse Decentraland custom. Avatar 3D haute-qualitÃ©, vÃªtements NFT. Showroom virtuel immersif. Commerce social intÃ©grÃ©. 50K avatars uniques.',
            'image' => 'projet6.jpg',
            'technos' => json_encode(['Babylon.js', 'Decentraland SDK', 'Solidity NFTs', 'Three.js', 'WebGL']),
            'results' => '50K users | 2.5M$ NFT ventes | 10K DAU',
            'duree' => '5 mois'
        ],
        [
            'titre' => 'CryptoExchange PRO',
            'slug' => 'crypto-exchange',
            'client' => 'Crypto Native Company',
            'categorie' => 'web',
            'description_courte' => 'Exchange dÃ©centralisÃ© temps rÃ©el',
            'description_longue' => 'Trading platform ultra-performante. 100K transactions/sec. Smart contracts auditÃ©s. Charts WebGL avec millions de points. LiquiditÃ© 500M$ TVL.',
            'image' => 'projet7.jpg',
            'technos' => json_encode(['Solidity', 'Web3.js', 'React', 'Node.js', 'Kubernetes']),
            'results' => '500M$ TVL | 100K tx/sec | 99.9% uptime',
            'duree' => '6 mois'
        ],
        [
            'titre' => 'EduVR Platform',
            'slug' => 'eduvr',
            'client' => 'EdTech International',
            'categorie' => 'web',
            'description_courte' => 'Classe virtuelle immersive en VR/AR',
            'description_longue' => 'Plateforme d\'apprentissage VR gÃ©nÃ©rale. Salles de classe virtuelles 3D. Collaboration temps rÃ©el 50+ students. RÃ©sultats pÃ©dagogiques +35% comprehension.',
            'image' => 'projet8.jpg',
            'technos' => json_encode(['Babylon.js', 'Meta Quest SDK', 'WebXR API', 'Node.js', 'Three.js']),
            'results' => '2K Ã©coles | 150K students | +35% comprehension',
            'duree' => '7 mois'
        ]
    ];
    $categories = [
        ['categorie' => 'web'],
        ['categorie' => 'mobile'],
        ['categorie' => 'ia']
    ];
}

$page_script = 'assets/js/portfolio.js';
?>

<main>
    <!-- HERO -->
    <section class="hero" style="padding-top: 120px; padding-bottom: 4rem;">
        <canvas id="portfolio-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container" style="position: relative; z-index: 2;">
            <h1 class="hero-title" style="color: #FFFFFF;">PORTFOLIO</h1>
            <p class="hero-subtitle" style="font-size: 1.3rem; max-width: 900px;">8 projects AAA pour les plus grandes marques. De la fintech Ã  la rÃ©alitÃ© augmentÃ©e.</p>
        </div>
    </section>

    <!-- GRILLE PROJETS -->
    <section class="section">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 3rem;">
                
                <?php foreach($projets as $index => $projet): ?>
                <!-- PROJET <?= $index + 1 ?> -->
                <div class="glass" style="border-radius: 12px; border: 1px solid rgba(0,255,255,0.1); overflow: hidden; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: <?= $index * 0.1 ?>s;">
                    
                    <!-- Image -->
                    <div style="position: relative; width: 100%; height: 280px; background: linear-gradient(135deg, #020408, #080f1a); border-bottom: 1px solid rgba(0,255,255,0.1); overflow: hidden;">
                        <img src="<?= htmlspecialchars($base_url . 'assets/images/' . ($projet['image'] ?? 'projet1.jpg')) ?>" 
                             alt="<?= htmlspecialchars($projet['titre']) ?>"
                             style="width: 100%; height: 100%; object-fit: cover; opacity: 0.8; transition: transform 0.6s ease;" 
                             onerror="this.style.display='none';">
                        <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1)); z-index: 1;"></div>
                        
                        <!-- Badge catÃ©gorie -->
                        <span style="position: absolute; top: 1rem; right: 1rem; z-index: 2; background: <?= $projet['categorie'] === 'web' ? '#00FFFF' : ($projet['categorie'] === 'mobile' ? '#7B2FFF' : '#FF2D78') ?>; color: <?= $projet['categorie'] === 'web' || $projet['categorie'] === 'mobile' ? '#000' : '#fff' ?>; padding: 0.5rem 1rem; border-radius: 20px; font-weight: 600; font-size: 0.85rem;"><?= ucfirst(htmlspecialchars($projet['categorie'])) ?></span>
                    </div>

                    <!-- Contenu -->
                    <div style="padding: 2rem;">
                        <h3 style="color: #FFFFFF; font-family: 'Orbitron'; margin-bottom: 0.5rem;"><?= htmlspecialchars($projet['titre']) ?></h3>
                        <p style="color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1.5rem;">Client: <strong><?= htmlspecialchars($projet['client']) ?></strong></p>
                        
                        <!-- Description -->
                        <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem; font-size: 0.95rem;"><?= htmlspecialchars($projet['description_longue']) ?></p>

                        <!-- Technos -->
                        <div style="margin-bottom: 1.5rem;">
                            <p style="color: #00FFFF; font-weight: 600; font-size: 0.9rem; margin-bottom: 0.75rem;">TECH STACK</p>
                            <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                                <?php 
                                $technos = json_decode($projet['technos'], true) ?? [];
                                foreach($technos as $tech): ?>
                                <span style="background: rgba(0,255,255,0.1); color: #00FFFF; padding: 0.35rem 0.75rem; border-radius: 4px; font-size: 0.8rem; border: 1px solid rgba(0,255,255,0.2);"><?= htmlspecialchars($tech) ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Results -->
                        <div style="background: rgba(0,255,255,0.1); padding: 1rem; border-left: 3px solid #00FFFF; border-radius: 6px; margin-bottom: 1.5rem;">
                            <p style="color: #00FFFF; font-weight: 600; font-size: 0.9rem; margin-bottom: 0.5rem;">RÃ‰SULTATS</p>
                            <p style="color: var(--text-muted); font-size: 0.9rem;"><?= htmlspecialchars($projet['results'] ?? '') ?></p>
                        </div>

                        <!-- Timeline -->
                        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 1rem; border-top: 1px solid rgba(0,255,255,0.1);">
                            <div style="text-align: left;">
                                <p style="color: var(--text-muted); font-size: 0.85rem;">DurÃ©e du projet</p>
                                <p style="color: #FFFFFF; font-weight: 600;"><?= htmlspecialchars($projet['duree'] ?? 'N/A') ?></p>
                            </div>
                            <a href="portfolio-detail.php?slug=<?= htmlspecialchars($projet['slug']) ?>" style="color: #00FFFF; text-decoration: none; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.opacity='0.7'" onmouseout="this.style.opacity='1'">Voir dÃ©tails â†’</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- SECTION STATS -->
    <section class="section" style="background: rgba(123,47,255,0.05);">
        <div class="container">
            <h2 class="section-title text-gradient" style="text-align: center; margin-bottom: 3rem;">RÃ‰SULTATS GLOBAUX</h2>
            
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 2rem;">
                <div style="text-align: center; padding: 2rem; border-radius: 12px; background: rgba(0,255,255,0.05); border: 1px solid rgba(0,255,255,0.1);">
                    <p style="color: #00FFFF; font-family: 'Orbitron'; font-size: 2.5rem; font-weight: 900; margin-bottom: 0.5rem;">157</p>
                    <p style="color: var(--text-muted);">Projets LivrÃ©</p>
                </div>

                <div style="text-align: center; padding: 2rem; border-radius: 12px; background: rgba(0,255,255,0.05); border: 1px solid rgba(0,255,255,0.1);">
                    <p style="color: #00FFFF; font-family: 'Orbitron'; font-size: 2.5rem; font-weight: 900; margin-bottom: 0.5rem;">+520%</p>
                    <p style="color: var(--text-muted);">Avg Conversion Lift</p>
                </div>

                <div style="text-align: center; padding: 2rem; border-radius: 12px; background: rgba(0,255,255,0.05); border: 1px solid rgba(0,255,255,0.1);">
                    <p style="color: #00FFFF; font-family: 'Orbitron'; font-size: 2.5rem; font-weight: 900; margin-bottom: 0.5rem;">99.2%</p>
                    <p style="color: var(--text-muted);">Client Satisfaction</p>
                </div>

                <div style="text-align: center; padding: 2rem; border-radius: 12px; background: rgba(0,255,255,0.05); border: 1px solid rgba(0,255,255,0.1);">
                    <p style="color: #00FFFF; font-family: 'Orbitron'; font-size: 2.5rem; font-weight: 900; margin-bottom: 0.5rem;">18</p>
                    <p style="color: var(--text-muted);">Pays Couverts</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="section" style="background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));">
        <div class="container" style="text-align: center;">
            <h2 style="font-size: 2rem; margin-bottom: 1.5rem;">Votre projet mÃ©rite une agence FUTURISTE</h2>
            <p style="color: var(--text-muted); margin-bottom: 2rem; font-size: 1.1rem;">Parlons ensemble de comment nous pouvons transformer votre vision</p>
            <a href="contact.php" class="btn btn-primary" style="display: inline-block; padding: 1rem 3rem; font-size: 1.1rem;">DÃ‰MARRER UN PROJET</a>
        </div>
    </section>
</main>

<style>
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>
