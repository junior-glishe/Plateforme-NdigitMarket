    <!-- Back to Top -->
    <div id="back-to-top">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="18 15 12 9 6 15"></polyline>
        </svg>
    </div>

<?php require_once 'includes/functions.php'; ?>

    <!-- Scripts CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    
    <!-- Scripts locaux -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/arrow-anim.js"></script>
    <script src="assets/js/three-bg.js"></script>
    <script src="assets/js/animations.js"></script>
    <script src="assets/js/hero-polyhedra.js"></script>
    
    <!-- Page specific script -->
    <?php if (isset($page_script)): ?>
        <script src="<?= $page_script ?>"></script>
    <?php endif; ?>
    
</body>
</html>
