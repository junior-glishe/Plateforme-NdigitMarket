<?php
$current_page = basename($_SERVER['PHP_SELF']);
$page_titles = [
    'index.php' => 'FUTURISTE - Agence Digitale',
    'about.php' => 'FUTURISTE - À Propos',
    'services.php' => 'FUTURISTE - Services',
    'portfolio.php' => 'FUTURISTE - Portfolio',
    'portfolio-detail.php' => 'FUTURISTE - Projet',
    'team.php' => 'FUTURISTE - Équipe',
    'pricing.php' => 'FUTURISTE - Tarifs',
    'faq.php' => 'FUTURISTE - FAQ',
    'blog.php' => 'FUTURISTE - Blog',
    'blog-details.php' => 'FUTURISTE - Article',
    'contact.php' => 'FUTURISTE - Contact'
];
$title = $page_titles[$current_page] ?? 'FUTURISTE';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?></title>
    <meta name="description" content="FUTURISTE - Agence digitale futuriste. Web3, IA, 3D, applications mobiles de pointe.">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;500;600;700&family=Share+Tech+Mono:wght@400;500&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/global.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link rel="stylesheet" href="assets/css/components.css">
    <link rel="stylesheet" href="assets/css/home-animations.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
</head>
<body>
    <!-- Cursor -->
    <div id="cursor"></div>
    <div id="cursor-follower"></div>
    
    <!-- Background Canvas -->
    <canvas id="bg-canvas"></canvas>
    
    <!-- Header -->
    <header id="main-header">
        <div class="header-container container">
            <a href="index.php" class="logo">
                <img src="/agence-futuriste/assets/images/logo.png" alt="FUTURISTE - Agence Digitale" 
                     style="height: 100px; width: 200px; object-fit: contain; 
                            filter: drop-shadow(0 0 12px rgba(100,120,255,0.6));
                            transition: filter 0.3s, transform 0.3s;"
                     onerror="console.error('Logo non trouvé: ' + this.src);">
            </a>
            
            <nav class="nav-links">
                <a href="index.php" data-page="index.php" data-text="HOME">HOME</a>
                <a href="about.php" data-page="about.php" data-text="ABOUT">À PROPOS</a>
                <a href="services.php" data-page="services.php" data-text="SERVICES">SERVICES</a>
                <a href="portfolio.php" data-page="portfolio.php" data-text="PORTFOLIO">PORTFOLIO</a>
                <a href="team.php" data-page="team.php" data-text="TEAM">ÉQUIPE</a>
                <a href="pricing.php" data-page="pricing.php" data-text="PRICING">TARIFS</a>
                <a href="blog.php" data-page="blog.php" data-text="BLOG">BLOG</a>
                <a href="contact.php" data-page="contact.php" data-text="CONTACT" class="btn btn-primary">CONTACT</a>
            </nav>
            
            <div class="burger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </header>
    
    <!-- Mobile Menu Overlay -->
    <div id="mobile-menu">
        <nav class="nav-links">
            <a href="index.php" data-page="index.php">HOME</a>
            <a href="about.php" data-page="about.php">À PROPOS</a>
            <a href="services.php" data-page="services.php">SERVICES</a>
            <a href="portfolio.php" data-page="portfolio.php">PORTFOLIO</a>
            <a href="team.php" data-page="team.php">ÉQUIPE</a>
            <a href="pricing.php" data-page="pricing.php">TARIFS</a>
            <a href="blog.php" data-page="blog.php">BLOG</a>
            <a href="contact.php" data-page="contact.php" class="btn btn-primary">CONTACT</a>
        </nav>
    </div>
    <div id="menu-overlay"></div>
    <div id="arrow-wrapper">
      <canvas id="arrow-canvas" width="400" height="120"></canvas>
    </div>

    <!-- Contenu principal commence ici -->
