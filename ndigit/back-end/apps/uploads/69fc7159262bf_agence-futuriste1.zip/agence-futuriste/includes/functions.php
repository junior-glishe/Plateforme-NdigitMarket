<?php
/**
 * Fonctions utilitaires PHP
 */

// Formatage date française
if (!function_exists('formatDateFr')) {
    function formatDateFr($date, $format = 'd/m/Y') {
        return date($format, strtotime($date));
    }
}

// Truncation texte sécurisée
if (!function_exists('truncateText')) {
    function truncateText($text, $length = 150, $suffix = '...') {
        $text = strip_tags($text);
        if (strlen($text) <= $length) {
            return $text;
        }
        return substr($text, 0, $length - strlen($suffix)) . $suffix;
    }
}

// Génération slug
if (!function_exists('generateSlug')) {
    function generateSlug($string) {
        $slug = strtolower(trim($string));
        $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        return trim($slug, '-');
    }
}

// Validation email
if (!function_exists('isValidEmail')) {
    function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }
}

// Nettoyage HTML sécurisé
if (!function_exists('cleanHtml')) {
    function cleanHtml($html) {
        return htmlspecialchars_decode(strip_tags($html, '<p><br><strong><em><ul><ol><li><h1><h2><h3><h4><a><img><blockquote><code><pre>'));
    }
}

// Temps de lecture approximatif
if (!function_exists('estimateReadingTime')) {
    function estimateReadingTime($text) {
        $words = str_word_count(strip_tags($text));
        return ceil($words / 250); // 250 mots par minute
    }
}

// Debug (à supprimer en prod)
if (isset($_GET['debug'])) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
}

// Redirection sécurisée
if (!function_exists('safeRedirect')) {
    function safeRedirect($url, $status = 302) {
        header("Location: " . filter_var($url, FILTER_SANITIZE_URL), true, $status);
        exit;
    }
}
?>