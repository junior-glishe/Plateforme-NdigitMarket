<?php
require_once 'includes/header.php';
require_once 'config/db.php';
require_once 'includes/functions.php';

$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/agence-futuriste/';
$slug = isset($_GET['slug']) ? trim((string) $_GET['slug']) : '';

if (!function_exists('portfolio_detail_category_style')) {
    function portfolio_detail_category_style($category) {
        switch ($category) {
            case 'mobile':
                return ['bg' => '#7B2FFF', 'text' => '#FFFFFF'];
            case 'ia':
                return ['bg' => '#FF2D78', 'text' => '#FFFFFF'];
            case 'branding':
                return ['bg' => '#7B2FFF', 'text' => '#FFFFFF'];
            case 'web':
            default:
                return ['bg' => '#00FFFF', 'text' => '#020408'];
        }
    }
}

if (!function_exists('portfolio_detail_normalize_images')) {
    function portfolio_detail_normalize_images($project, $baseUrl) {
        $images = [];

        if (!empty($project['image']) && is_string($project['image'])) {
            $images[] = $baseUrl . 'assets/images/' . ltrim((string) $project['image'], '/');
        }

        if (!empty($project['images'])) {
            $decoded = json_decode((string) $project['images'], true);
            if (is_array($decoded)) {
                foreach ($decoded as $image) {
                    if (!is_string($image) || trim($image) === '') {
                        continue;
                    }

                    if (preg_match('#^https?://#i', $image)) {
                        $images[] = $image;
                    } elseif (strpos($image, 'assets/') === 0) {
                        $images[] = $baseUrl . ltrim($image, '/');
                    } else {
                        $images[] = $baseUrl . 'assets/images/' . ltrim($image, '/');
                    }
                }
            }
        }

        if (!empty($project['gallery']) && is_array($project['gallery'])) {
            foreach ($project['gallery'] as $image) {
                $images[] = $baseUrl . 'assets/images/' . ltrim((string) $image, '/');
            }
        }

        if (empty($images)) {
            $images[] = $baseUrl . 'assets/images/projet1.jpg';
        }

        return array_values(array_unique($images));
    }
}

if (!function_exists('portfolio_detail_results')) {
    function portfolio_detail_results($project) {
        if (!empty($project['resultats']) && is_array($project['resultats'])) {
            return $project['resultats'];
        }

        if (!empty($project['results']) && is_string($project['results'])) {
            $parts = array_values(array_filter(array_map('trim', explode('|', $project['results']))));
            $labels = ['Performance', 'Impact', 'Adoption'];
            $resultats = [];

            foreach ($parts as $index => $part) {
                $resultats[] = [
                    'value' => $part,
                    'label' => $labels[$index] ?? 'Resultat cle'
                ];
            }

            if (!empty($resultats)) {
                return $resultats;
            }
        }

        return [
            ['value' => '+180%', 'label' => 'croissance de conversion'],
            ['value' => 'x2.4', 'label' => 'acceleration de performance'],
            ['value' => '98%', 'label' => 'satisfaction stakeholder']
        ];
    }
}

if (!function_exists('portfolio_detail_normalize')) {
    function portfolio_detail_normalize($project, $baseUrl, $fallbackMap) {
        $slug = (string) ($project['slug'] ?? '');
        $fallback = $fallbackMap[$slug] ?? [];
        $mergedProject = $project + $fallback;
        $images = portfolio_detail_normalize_images($mergedProject, $baseUrl);
        $mainImage = !empty($mergedProject['image'])
            ? $baseUrl . 'assets/images/' . ltrim((string) $mergedProject['image'], '/')
            : ($images[0] ?? ($baseUrl . 'assets/images/projet1.jpg'));

        $techStack = [];
        if (!empty($mergedProject['technos'])) {
            $decoded = json_decode((string) $mergedProject['technos'], true);
            if (is_array($decoded)) {
                $techStack = $decoded;
            }
        }
        if (empty($techStack) && !empty($fallback['tech_stack'])) {
            $techStack = $fallback['tech_stack'];
        }

        $year = !empty($mergedProject['created_at']) ? date('Y', strtotime((string) $mergedProject['created_at'])) : ($fallback['annee'] ?? date('Y'));
        $descriptionLong = trim((string) ($mergedProject['description_longue'] ?? $mergedProject['description'] ?? $fallback['description_longue'] ?? ''));

        return [
            'titre' => (string) ($mergedProject['titre'] ?? $fallback['titre'] ?? 'Projet FUTURISTE'),
            'slug' => $slug,
            'client' => (string) ($mergedProject['client'] ?? $fallback['client'] ?? 'Client confidentiel'),
            'categorie' => (string) ($mergedProject['categorie'] ?? $fallback['categorie'] ?? 'web'),
            'description_longue' => $descriptionLong !== '' ? $descriptionLong : 'Experience digitale premium concue pour des objectifs business ambitieux.',
            'challenge' => (string) ($mergedProject['challenge'] ?? $fallback['challenge'] ?? 'Le client avait besoin d une plateforme plus rapide, plus lisible et plus differenciante pour soutenir sa croissance.'),
            'solution' => (string) ($mergedProject['solution'] ?? $fallback['solution'] ?? 'Nous avons repense l experience, modernise la stack et optimise la performance pour une execution premium.'),
            'resultats' => portfolio_detail_results($mergedProject),
            'images' => $images,
            'image_principale' => $mainImage,
            'tech_stack' => $techStack,
            'url_live' => (string) ($mergedProject['url_live'] ?? $fallback['url_live'] ?? ''),
            'duree' => (string) ($mergedProject['duree'] ?? $fallback['duree'] ?? '4 a 6 mois'),
            'annee' => (string) $year,
        ];
    }
}

$fallbackProjects = [
    [
        'titre' => 'NeoBank Pro',
        'slug' => 'neobank-pro',
        'client' => 'Fintech Series B',
        'categorie' => 'web',
        'description_longue' => 'NeoBank Pro a ete imagine comme une plateforme bancaire premium capable d inspirer confiance tout en offrant une experience ultra-rapide. Nous avons refondu l ensemble du parcours, depuis l onboarding jusqu aux espaces d analyse financiere, avec une attention particuliere portee a la clarte des flux sensibles, a la securite percue et a la fluidite mobile. Le resultat est une interface plus desirable, plus performante et mieux adaptee aux objectifs de croissance de la fintech.',
        'challenge' => 'L equipe faisait face a une plateforme vieillissante, un onboarding trop complexe et un taux d abandon eleve sur les parcours de conversion strategiques.',
        'solution' => 'Nous avons concu une interface React immersive, rationalise les parcours, renforce les points de reassurance et optimise les performances frontend et backend pour soutenir des pics de trafic critiques.',
        'image' => 'projet1.jpg',
        'gallery' => ['projet1.jpg', 'projet2.jpg', 'projet3.jpg'],
        'tech_stack' => ['React 19', 'Node.js', 'PostgreSQL', 'Stripe API', 'Three.js'],
        'resultats' => [
            ['value' => '+340%', 'label' => 'conversions sur l onboarding'],
            ['value' => '+2.1M EUR', 'label' => 'ARR generee'],
            ['value' => '150K', 'label' => 'utilisateurs actifs']
        ],
        'duree' => '5 mois',
        'annee' => '2025'
    ],
    [
        'titre' => 'LUXE AR Experience',
        'slug' => 'luxe-ar',
        'client' => 'Groupe de Luxe International',
        'categorie' => 'web',
        'description_longue' => 'LUXE AR Experience fusionne storytelling visuel, technologie WebGL et essayage augmente pour transformer une campagne de marque en activation interactive premium. Nous avons orchestre une experience hautement partageable, pensee pour les usages mobile-first et les plateformes sociales, avec un souci constant du raffinement visuel et de la performance temps reel.',
        'challenge' => 'La marque voulait creer un dispositif differenciant capable d augmenter l engagement et les ventes sans compromettre son positionnement haut de gamme.',
        'solution' => 'Nous avons developpe une experience AR web accessible, enrichie d effets 3D custom, d un parcours de partage social optimise et d une mesure fine des comportements utilisateurs.',
        'image' => 'projet2.jpg',
        'gallery' => ['projet2.jpg', 'projet6.jpg', 'projet8.jpg'],
        'tech_stack' => ['Three.js', 'Babylon.js', 'AR.js', 'WebGL', 'Three Fiber'],
        'resultats' => [
            ['value' => '15M', 'label' => 'impressions organiques'],
            ['value' => '+280%', 'label' => 'hausse des ventes'],
            ['value' => '2M USD', 'label' => 'ROI attribue']
        ],
        'duree' => '4 mois',
        'annee' => '2025'
    ],
    [
        'titre' => 'MedAI Assistant',
        'slug' => 'medai-assistant',
        'client' => 'Startup Healthcare Series A',
        'categorie' => 'ia',
        'description_longue' => 'MedAI Assistant est une plateforme conversationnelle concue pour aider les professionnels de sante a retrouver plus rapidement l information clinique pertinente. Le projet combinait enjeux de precision, de confiance, de latence et de securite. Nous avons construit une experience claire et rassurante autour d une architecture RAG performante, en veillant a garder l IA lisible et utile dans un contexte exigeant.',
        'challenge' => 'Le client devait reduire le temps d acces a l information medicale fiable tout en limitant les risques d hallucination et en respectant des standards de conformite eleves.',
        'solution' => 'Nous avons deploye un pipeline RAG base sur Claude API, mis en place une couche de validation contextuelle et cree une interface conversationnelle orientee confiance et tracabilite.',
        'image' => 'projet3.jpg',
        'gallery' => ['projet3.jpg', 'projet4.jpg', 'projet5.jpg'],
        'tech_stack' => ['Claude API', 'Python', 'LangChain', 'Pinecone VectorDB', 'FastAPI'],
        'resultats' => [
            ['value' => '99.2%', 'label' => 'precision des reponses'],
            ['value' => '50K', 'label' => 'consultations assistees'],
            ['value' => '8/10', 'label' => 'NPS patient']
        ],
        'duree' => '6 mois',
        'annee' => '2025'
    ],
    [
        'titre' => 'SpaceTrack 3D',
        'slug' => 'spacetrack-3d',
        'client' => 'Startup Spatial Tech',
        'categorie' => 'web',
        'description_longue' => 'SpaceTrack 3D reinvente la lecture de donnees spatiales complexes dans une interface temps reel immersive. Nous avons cree un environnement 3D fluide, intelligible et pret pour la consultation multi-support, avec une attention particuliere portee a la lisibilite des signaux, aux performances de rendu et a l impact visuel de l experience.',
        'challenge' => 'Le client manipulait des volumes importants de donnees spatiales sans outil visuel capable de rendre leur lecture simple et convaincante pour des partenaires et investisseurs.',
        'solution' => 'Nous avons developpe un dashboard Three.js temps reel, synchronise avec des flux live, concu pour la demonstration haute valeur et la navigation immersive.',
        'image' => 'projet4.jpg',
        'gallery' => ['projet4.jpg', 'projet2.jpg', 'projet8.jpg'],
        'tech_stack' => ['Three.js', 'Cesium.js', 'WebGL 2', 'WebSocket', 'Node.js'],
        'resultats' => [
            ['value' => '12K', 'label' => 'objets 3D affiches'],
            ['value' => '60fps', 'label' => 'fluidite en VR'],
            ['value' => '100K', 'label' => 'utilisateurs engages']
        ],
        'duree' => '3 mois',
        'annee' => '2024'
    ],
    [
        'titre' => 'FitGenius Mobile',
        'slug' => 'fitgenius',
        'client' => 'Fitness Unicorn',
        'categorie' => 'mobile',
        'description_longue' => 'FitGenius Mobile combine coaching personnalise, signaux de progression et routines intelligentes dans une experience mobile taillee pour la retention. Nous avons concu une application cross-platform premium centree sur les donnees d usage, la motivation et l engagement long terme, avec une interface optimisee pour des sessions courtes et recurrentes.',
        'challenge' => 'Le client cherchait a se differencier sur un marche sature en transformant des donnees de performance dispersees en recommandations utiles et engageantes.',
        'solution' => 'Nous avons construit une app Flutter couplee a des modeles predictifs embarques, une synchronisation wearables et des boucles de feedback intelligentes pour stimuler la retention.',
        'image' => 'projet5.jpg',
        'gallery' => ['projet5.jpg', 'projet1.jpg', 'projet7.jpg'],
        'tech_stack' => ['Flutter', 'Firebase', 'TensorFlow Lite', 'Provider state', 'Native modules'],
        'resultats' => [
            ['value' => '500K', 'label' => 'utilisateurs acquis'],
            ['value' => '4.9/5', 'label' => 'note moyenne stores'],
            ['value' => '95%', 'label' => 'retention observee']
        ],
        'duree' => '4 mois',
        'annee' => '2025'
    ],
    [
        'titre' => 'MetaVerse Fashion',
        'slug' => 'metaverse-fashion',
        'client' => 'Maison Mode Parisienne',
        'categorie' => 'web',
        'description_longue' => 'MetaVerse Fashion transpose l univers d une maison de mode dans un espace digital immersif ou branding, communaute et commerce convergent. Le projet a ete pense comme une vitrine d innovation et un canal de monetisation, avec un fort accent sur la direction artistique, les performances 3D et la desirabilite de l experience.',
        'challenge' => 'La marque voulait experimenter un format immersif capable de prolonger son image dans un territoire digital premium sans tomber dans l effet gadget.',
        'solution' => 'Nous avons concu un showroom interactif, des avatars 3D stylises et une couche NFT coherente avec l identite de marque pour creer une experience social commerce distinctive.',
        'image' => 'projet6.jpg',
        'gallery' => ['projet6.jpg', 'projet2.jpg', 'projet8.jpg'],
        'tech_stack' => ['Babylon.js', 'Decentraland SDK', 'Solidity NFTs', 'Three.js', 'WebGL'],
        'resultats' => [
            ['value' => '50K', 'label' => 'avatars uniques'],
            ['value' => '2.5M USD', 'label' => 'ventes NFT'],
            ['value' => '10K', 'label' => 'utilisateurs actifs par jour']
        ],
        'duree' => '5 mois',
        'annee' => '2024'
    ],
    [
        'titre' => 'CryptoExchange PRO',
        'slug' => 'crypto-exchange',
        'client' => 'Crypto Native Company',
        'categorie' => 'web',
        'description_longue' => 'CryptoExchange PRO a ete developpe comme une plateforme de trading visuellement intense, lisible et extremement performante. Nous avons travaille sur la fiabilite percue, la rapidite d interaction et la mise en avant d indicateurs critiques pour offrir une experience alignee avec les attentes d utilisateurs avances.',
        'challenge' => 'Le produit devait concilier densite informationnelle, confiance utilisateur et performances extremes dans un environnement de marche en temps reel.',
        'solution' => 'Nous avons combine interface React optimisee, infrastructure scalable, composants live et visualisations performantes pour rendre le trading plus fluide et plus comprehensible.',
        'image' => 'projet7.jpg',
        'gallery' => ['projet7.jpg', 'projet1.jpg', 'projet4.jpg'],
        'tech_stack' => ['Solidity', 'Web3.js', 'React', 'Node.js', 'Kubernetes'],
        'resultats' => [
            ['value' => '500M USD', 'label' => 'TVL atteinte'],
            ['value' => '100K', 'label' => 'transactions par seconde'],
            ['value' => '99.9%', 'label' => 'disponibilite plateforme']
        ],
        'duree' => '6 mois',
        'annee' => '2025'
    ],
    [
        'titre' => 'EduVR Platform',
        'slug' => 'eduvr',
        'client' => 'EdTech International',
        'categorie' => 'web',
        'description_longue' => 'EduVR Platform transforme l apprentissage a distance en experience immersive et collaborative. Nous avons concu un environnement VR et AR pense pour la concentration, la pedagogie active et les interactions en temps reel, tout en gardant un haut niveau d accessibilite technique pour les institutions partenaires.',
        'challenge' => 'Le client souhaitait rendre la formation a distance plus engageante, plus memorable et plus efficace a grande echelle.',
        'solution' => 'Nous avons deploye une plateforme WebXR collaborative, optimise les interactions de groupe et structure l experience pour soutenir l adoption cote enseignants et apprenants.',
        'image' => 'projet8.jpg',
        'gallery' => ['projet8.jpg', 'projet4.jpg', 'projet3.jpg'],
        'tech_stack' => ['Babylon.js', 'Meta Quest SDK', 'WebXR API', 'Node.js', 'Three.js'],
        'resultats' => [
            ['value' => '2K', 'label' => 'ecoles deployees'],
            ['value' => '150K', 'label' => 'etudiants touches'],
            ['value' => '+35%', 'label' => 'progression de comprehension']
        ],
        'duree' => '7 mois',
        'annee' => '2024'
    ]
];

$fallbackMap = [];
foreach ($fallbackProjects as $item) {
    $fallbackMap[$item['slug']] = $item;
}

$project = null;
$similarProjects = [];

try {
    if ($slug !== '') {
        $stmt = $pdo->prepare('SELECT * FROM projets WHERE slug = :slug LIMIT 1');
        $stmt->execute(['slug' => $slug]);
        $row = $stmt->fetch();

        if ($row) {
            $project = portfolio_detail_normalize($row, $base_url, $fallbackMap);

            $similarStmt = $pdo->prepare('SELECT * FROM projets WHERE categorie = :categorie AND slug <> :slug ORDER BY featured DESC, ordre ASC, created_at DESC LIMIT 3');
            $similarStmt->execute([
                'categorie' => $row['categorie'],
                'slug' => $slug
            ]);

            foreach ($similarStmt->fetchAll() as $similarRow) {
                $similarProjects[] = portfolio_detail_normalize($similarRow, $base_url, $fallbackMap);
            }
        }
    }
} catch (PDOException $e) {
    $project = null;
    $similarProjects = [];
}

if (!$project && $slug !== '' && isset($fallbackMap[$slug])) {
    $project = portfolio_detail_normalize($fallbackMap[$slug], $base_url, $fallbackMap);
}

if ($project && empty($similarProjects)) {
    foreach ($fallbackProjects as $fallbackProject) {
        if ($fallbackProject['slug'] === $project['slug']) {
            continue;
        }
        if ($fallbackProject['categorie'] !== $project['categorie']) {
            continue;
        }

        $similarProjects[] = portfolio_detail_normalize($fallbackProject, $base_url, $fallbackMap);
        if (count($similarProjects) >= 3) {
            break;
        }
    }
}

if (!$project) {
    http_response_code(404);
    ?>
    <main>
        <section class="section" style="padding-top: 10rem; min-height: 70vh; display: flex; align-items: center;">
            <div class="container" style="text-align: center;">
                <div class="glass" style="max-width: 760px; margin: 0 auto; padding: 3rem; border-radius: 24px;">
                    <p style="color: #FF2D78; text-transform: uppercase; letter-spacing: 0.18em; margin-bottom: 1rem;">404</p>
                    <h1 style="color: #FFFFFF; margin-bottom: 1rem;">Projet introuvable</h1>
                    <p style="color: var(--text-muted); font-size: 1.1rem; max-width: 560px; margin: 0 auto 2rem;">
                        Le projet demande n existe pas ou n est plus disponible dans le portfolio.
                    </p>
                    <a href="portfolio.php" class="btn btn-primary">Retour au portfolio</a>
                </div>
            </div>
        </section>
    </main>
    <?php require_once 'includes/footer.php'; ?>
    <?php exit; ?>
    <?php
}

$page_script = 'assets/js/portfolio.js';
$categoryStyle = portfolio_detail_category_style($project['categorie']);
?>

<main>
    <section class="project-hero">
        <img src="<?= htmlspecialchars($project['image_principale']) ?>" alt="<?= htmlspecialchars($project['titre']) ?>" class="project-hero-image" onerror="this.style.display='none';">
        <div class="project-hero-overlay"></div>
        <div class="container project-hero-inner">
            <a href="portfolio.php" class="project-back-link">← Portfolio</a>
            <div class="project-hero-content">
                <span class="project-category-badge" style="background: <?= htmlspecialchars($categoryStyle['bg']) ?>; color: <?= htmlspecialchars($categoryStyle['text']) ?>;"><?= htmlspecialchars(strtoupper($project['categorie'])) ?></span>
                <h1><?= htmlspecialchars($project['titre']) ?></h1>
                <p><?= htmlspecialchars($project['client']) ?></p>
            </div>
        </div>
    </section>

    <section class="project-breadcrumb-section">
        <div class="container">
            <nav class="project-breadcrumb" aria-label="Fil d Ariane">
                <a href="index.php">Accueil</a>
                <span>&gt;</span>
                <a href="portfolio.php">Portfolio</a>
                <span>&gt;</span>
                <span><?= htmlspecialchars($project['titre']) ?></span>
            </nav>
        </div>
    </section>

    <section class="section project-layout-section">
        <div class="container project-layout">
            <div class="project-main-column">
                <article class="glass project-rich-text" style="animation: fadeInUp 0.8s ease forwards; opacity: 0;">
                    <h2>Description</h2>
                    <p><?= nl2br(htmlspecialchars($project['description_longue'])) ?></p>
                </article>

                <section class="glass content-block" style="animation: fadeInUp 0.8s ease forwards; animation-delay: 0.1s; opacity: 0;">
                    <span class="eyebrow">Challenge</span>
                    <h2>Le probleme client</h2>
                    <p><?= nl2br(htmlspecialchars($project['challenge'])) ?></p>
                </section>

                <section class="glass content-block" style="animation: fadeInUp 0.8s ease forwards; animation-delay: 0.2s; opacity: 0;">
                    <span class="eyebrow">Solution</span>
                    <h2>Notre approche technique</h2>
                    <p><?= nl2br(htmlspecialchars($project['solution'])) ?></p>
                </section>

                <section class="content-block results-block" style="animation: fadeInUp 0.8s ease forwards; animation-delay: 0.3s; opacity: 0;">
                    <span class="eyebrow">Resultats</span>
                    <h2>Impact business</h2>
                    <div class="results-grid">
                        <?php $resultClasses = ['cyan', 'violet', 'pink']; ?>
                        <?php foreach ($project['resultats'] as $index => $result): ?>
                            <div class="result-card result-card-<?= htmlspecialchars($resultClasses[$index % count($resultClasses)]) ?>">
                                <p class="result-value"><?= htmlspecialchars($result['value']) ?></p>
                                <p class="result-label"><?= htmlspecialchars($result['label']) ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>
            </div>

            <aside class="project-sidebar">
                <div class="glass sidebar-card" style="animation: fadeInUp 0.8s ease forwards; animation-delay: 0.15s; opacity: 0;">
                    <h3>Infos projet</h3>
                    <div class="info-list">
                        <div>
                            <span>Client</span>
                            <strong><?= htmlspecialchars($project['client']) ?></strong>
                        </div>
                        <div>
                            <span>Categorie</span>
                            <strong><?= htmlspecialchars(ucfirst($project['categorie'])) ?></strong>
                        </div>
                        <div>
                            <span>Duree</span>
                            <strong><?= htmlspecialchars($project['duree']) ?></strong>
                        </div>
                        <div>
                            <span>Annee</span>
                            <strong><?= htmlspecialchars($project['annee']) ?></strong>
                        </div>
                    </div>
                </div>

                <div class="glass sidebar-card" style="animation: fadeInUp 0.8s ease forwards; animation-delay: 0.25s; opacity: 0;">
                    <h3>Tech Stack</h3>
                    <div class="tech-badges">
                        <?php foreach ($project['tech_stack'] as $tech): ?>
                            <span><?= htmlspecialchars($tech) ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="glass sidebar-card" style="animation: fadeInUp 0.8s ease forwards; animation-delay: 0.35s; opacity: 0;">
                    <h3>Passer a l action</h3>
                    <a href="contact.php" class="btn btn-primary sidebar-cta">DEMARRER UN PROJET SIMILAIRE</a>
                    <?php if ($project['url_live'] !== ''): ?>
                        <a href="<?= htmlspecialchars($project['url_live']) ?>" target="_blank" rel="noopener noreferrer" class="sidebar-live-link">Voir le site live</a>
                    <?php endif; ?>
                </div>
            </aside>
        </div>
    </section>

    <?php if (count($project['images']) > 1): ?>
        <section class="section gallery-section">
            <div class="container">
                <div class="section-heading">
                    <span class="eyebrow">Galerie</span>
                    <h2>Visuels du projet</h2>
                </div>
                <div class="gallery-grid">
                    <?php foreach ($project['images'] as $index => $image): ?>
                        <div class="glass gallery-card" style="animation: fadeInUp 0.8s ease forwards; animation-delay: <?= htmlspecialchars((string) ($index * 0.1)) ?>s; opacity: 0;">
                            <img src="<?= htmlspecialchars($image) ?>" alt="<?= htmlspecialchars($project['titre']) ?> visuel <?= htmlspecialchars((string) ($index + 1)) ?>" onerror="this.style.display='none';">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!empty($similarProjects)): ?>
        <section class="section similar-section">
            <div class="container">
                <div class="section-heading">
                    <span class="eyebrow">Portfolio lie</span>
                    <h2>Projets similaires</h2>
                </div>
                <div class="similar-grid">
                    <?php foreach ($similarProjects as $index => $similar): ?>
                        <article class="glass similar-card" style="animation: fadeInUp 0.8s ease forwards; animation-delay: <?= htmlspecialchars((string) ($index * 0.1)) ?>s; opacity: 0;">
                            <a href="portfolio-detail.php?slug=<?= htmlspecialchars($similar['slug']) ?>" class="similar-card-link">
                                <div class="similar-image-wrap">
                                    <img src="<?= htmlspecialchars($similar['image_principale']) ?>" alt="<?= htmlspecialchars($similar['titre']) ?>" onerror="this.style.display='none';">
                                </div>
                                <div class="similar-card-body">
                                    <h3><?= htmlspecialchars($similar['titre']) ?></h3>
                                    <p><?= htmlspecialchars($similar['client']) ?></p>
                                    <span>Voir le projet</span>
                                </div>
                            </a>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section class="section final-cta-section">
        <div class="container">
            <div class="glass final-cta-card">
                <h2>Votre projet merite une agence FUTURISTE</h2>
                <p>Construisons une experience digitale ambitieuse, premium et pensee pour vos resultats.</p>
                <a href="contact.php" class="btn btn-primary">DEMARRER UN PROJET</a>
            </div>
        </div>
    </section>
</main>

<style>
.project-hero {
    position: relative;
    min-height: 500px;
    background: #020408;
    overflow: hidden;
}

.project-hero-image {
    width: 100%;
    height: 500px;
    object-fit: cover;
    display: block;
}

.project-hero-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(180deg, rgba(2,4,8,0.1) 0%, rgba(2,4,8,0.32) 35%, rgba(2,4,8,0.96) 100%);
}

.project-hero-inner {
    position: absolute;
    inset: 0;
    z-index: 2;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding-top: 8.5rem;
    padding-bottom: 2.25rem;
}

.project-back-link {
    align-self: flex-start;
    text-decoration: none;
    color: #FFFFFF;
    font-family: 'Orbitron', sans-serif;
    font-size: 0.9rem;
    padding: 0.8rem 1.1rem;
    border-radius: 999px;
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(14px);
    border: 1px solid rgba(255,255,255,0.12);
    transition: transform 0.3s ease, border-color 0.3s ease, color 0.3s ease;
}

.project-back-link:hover {
    color: #00FFFF;
    transform: translateY(-2px);
    border-color: rgba(0,255,255,0.32);
}

.project-hero-content {
    max-width: 840px;
}

.project-category-badge {
    display: inline-flex;
    align-items: center;
    padding: 0.45rem 0.9rem;
    border-radius: 999px;
    font-size: 0.8rem;
    font-weight: 800;
    letter-spacing: 0.08em;
    margin-bottom: 1rem;
}

.project-hero-content h1 {
    color: #FFFFFF;
    font-size: clamp(2.4rem, 5vw, 4.5rem);
    line-height: 1.05;
    margin-bottom: 0.85rem;
}

.project-hero-content p {
    margin: 0;
    color: rgba(255,255,255,0.78);
    font-size: 1.2rem;
}

.project-breadcrumb-section {
    padding: 1.25rem 0 0;
    background: #020408;
}

.project-breadcrumb {
    display: flex;
    gap: 0.7rem;
    flex-wrap: wrap;
    align-items: center;
    color: var(--text-muted);
    font-size: 0.95rem;
}

.project-breadcrumb a {
    color: var(--text-muted);
    text-decoration: none;
}

.project-breadcrumb a:hover {
    color: #00FFFF;
}

.project-layout-section,
.gallery-section,
.similar-section,
.final-cta-section {
    background:
        radial-gradient(circle at top left, rgba(0,255,255,0.05), transparent 32%),
        radial-gradient(circle at top right, rgba(123,47,255,0.08), transparent 30%),
        #020408;
}

.project-layout {
    display: grid;
    grid-template-columns: minmax(0, 13fr) minmax(300px, 7fr);
    gap: 2rem;
    align-items: start;
}

.project-main-column {
    display: grid;
    gap: 1.5rem;
    min-width: 0;
}

.project-sidebar {
    position: sticky;
    top: 120px;
    display: grid;
    gap: 1.25rem;
    min-width: 0;
}

.project-rich-text,
.content-block,
.sidebar-card,
.gallery-card,
.similar-card,
.final-cta-card {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(18px);
    border: 1px solid rgba(0,255,255,0.14);
    box-shadow: 0 25px 50px -12px rgba(0,0,0,0.75);
}

.project-rich-text,
.content-block {
    border-radius: 24px;
    padding: 2rem;
}

.project-rich-text h2,
.content-block h2,
.section-heading h2,
.sidebar-card h3,
.final-cta-card h2 {
    color: #FFFFFF;
    font-family: 'Orbitron', sans-serif;
}

.project-rich-text p,
.content-block p,
.sidebar-card p,
.sidebar-card span,
.sidebar-card strong,
.similar-card-body p,
.final-cta-card p {
    color: var(--text-muted);
}

.project-rich-text p,
.content-block p {
    font-size: 1.04rem;
    line-height: 1.95;
    margin-bottom: 0;
}

.eyebrow {
    display: inline-block;
    color: #FF2D78;
    text-transform: uppercase;
    letter-spacing: 0.18em;
    font-size: 0.78rem;
    margin-bottom: 0.85rem;
}

.results-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 1rem;
    margin-top: 1.5rem;
}

.result-card {
    padding: 1.5rem;
    border-radius: 22px;
}

.result-card-cyan {
    background: linear-gradient(135deg, rgba(0,255,255,0.16), rgba(0,255,255,0.04));
    border: 1px solid rgba(0,255,255,0.32);
}

.result-card-violet {
    background: linear-gradient(135deg, rgba(123,47,255,0.18), rgba(123,47,255,0.04));
    border: 1px solid rgba(123,47,255,0.3);
}

.result-card-pink {
    background: linear-gradient(135deg, rgba(255,45,120,0.18), rgba(255,45,120,0.04));
    border: 1px solid rgba(255,45,120,0.3);
}

.result-value {
    color: #FFFFFF;
    font-family: 'Orbitron', sans-serif;
    font-size: clamp(1.5rem, 3vw, 2.35rem);
    line-height: 1.1;
    margin-bottom: 0.6rem;
}

.result-label {
    margin: 0;
    font-size: 0.95rem;
    line-height: 1.6;
}

.sidebar-card {
    border-radius: 22px;
    padding: 1.6rem;
}

.sidebar-card h3 {
    margin-bottom: 1rem;
    font-size: 1rem;
}

.info-list {
    display: grid;
    gap: 1rem;
}

.info-list div {
    display: grid;
    gap: 0.25rem;
    padding-bottom: 0.9rem;
    border-bottom: 1px solid rgba(255,255,255,0.08);
}

.info-list div:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.info-list span {
    font-size: 0.82rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
}

.info-list strong {
    color: #FFFFFF;
    font-size: 1rem;
}

.tech-badges {
    display: flex;
    flex-wrap: wrap;
    gap: 0.65rem;
}

.tech-badges span {
    display: inline-flex;
    align-items: center;
    padding: 0.55rem 0.9rem;
    border-radius: 999px;
    color: #00FFFF;
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(0,255,255,0.18);
    backdrop-filter: blur(12px);
}

.sidebar-cta {
    width: 100%;
    justify-content: center;
    text-align: center;
    margin-bottom: 1rem;
}

.sidebar-live-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    text-decoration: none;
    color: #FFFFFF;
    padding: 0.95rem 1.1rem;
    border-radius: 999px;
    background: linear-gradient(135deg, rgba(0,255,255,0.09), rgba(123,47,255,0.09));
    border: 1px solid rgba(0,255,255,0.16);
    transition: transform 0.3s ease, border-color 0.3s ease;
}

.sidebar-live-link:hover,
.similar-card:hover {
    transform: translateY(-3px);
    border-color: rgba(0,255,255,0.34);
}

.section-heading {
    margin-bottom: 2rem;
}

.gallery-grid,
.similar-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 1.5rem;
}

.gallery-card,
.similar-card {
    border-radius: 22px;
    overflow: hidden;
}

.gallery-card img,
.similar-image-wrap img {
    width: 100%;
    display: block;
    object-fit: cover;
}

.gallery-card img {
    height: 260px;
}

.similar-card {
    transition: transform 0.3s ease, border-color 0.3s ease;
}

.similar-card-link {
    color: inherit;
    text-decoration: none;
    display: block;
}

.similar-image-wrap {
    height: 220px;
    background: linear-gradient(135deg, rgba(0,255,255,0.08), rgba(123,47,255,0.08));
}

.similar-card-body {
    padding: 1.4rem;
}

.similar-card-body h3 {
    color: #FFFFFF;
    font-size: 1.1rem;
    margin-bottom: 0.45rem;
}

.similar-card-body p {
    margin-bottom: 0.9rem;
}

.similar-card-body span {
    color: #00FFFF;
    font-weight: 700;
}

.final-cta-card {
    border-radius: 28px;
    text-align: center;
    padding: 3rem 2rem;
}

.final-cta-card p {
    max-width: 700px;
    margin: 0 auto 1.75rem;
    font-size: 1.08rem;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 1024px) {
    .project-layout,
    .gallery-grid,
    .similar-grid,
    .results-grid {
        grid-template-columns: 1fr;
    }

    .project-sidebar {
        position: static;
    }
}

@media (max-width: 768px) {
    .project-hero,
    .project-hero-image {
        min-height: 420px;
        height: 420px;
    }

    .project-hero-inner {
        padding-top: 7rem;
        padding-bottom: 1.75rem;
    }

    .project-rich-text,
    .content-block,
    .sidebar-card,
    .final-cta-card {
        padding: 1.4rem;
    }

    .project-hero-content p {
        font-size: 1rem;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>
