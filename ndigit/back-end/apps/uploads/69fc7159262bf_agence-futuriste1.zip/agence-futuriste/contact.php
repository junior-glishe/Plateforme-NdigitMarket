<?php
require_once 'includes/header.php';
require_once 'config/db.php';
require_once 'includes/functions.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? $_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $entreprise = trim($_POST['entreprise'] ?? '');
    $budget = trim($_POST['budget'] ?? '');
    $service = trim($_POST['service'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($nom === '') {
        $errors[] = 'Le nom est requis.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Une adresse email valide est requise.';
    }

    if (array_key_exists('message', $_POST) && $message === '') {
        $errors[] = 'Le message est requis.';
    }

    if (empty($errors)) {
        try {
            if (isset($pdo)) {
                $stmt = $pdo->prepare('INSERT INTO contact_messages (nom, email, entreprise, budget, service, message) VALUES (?, ?, ?, ?, ?, ?)');
                $stmt->execute([
                    $nom,
                    $email,
                    $entreprise,
                    $budget,
                    $service,
                    $message !== '' ? $message : 'Demande envoyee depuis le formulaire rapide.'
                ]);
            }

            $success = true;
        } catch (PDOException $e) {
            $errors[] = 'Impossible d enregistrer votre message pour le moment.';
        }
    }

    $acceptsJson = isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json');

    if ($acceptsJson || isset($_POST['name'])) {
        header('Content-Type: application/json');
        http_response_code($success ? 200 : 422);
        echo json_encode([
            'success' => $success,
            'errors' => $errors
        ]);
        exit;
    }
}
?>

<style>
select option {
    background: #080f1a !important;
    color: #FFFFFF !important;
    padding: 0.5rem;
}

select:focus {
    border-color: #00FFFF;
    box-shadow: 0 0 0 2px rgba(0, 255, 255, 0.15);
}

select option:hover,
select option:checked {
    background: rgba(0, 255, 255, 0.2) !important;
    color: #00FFFF !important;
}
</style>

<main>
    <section class="hero" style="padding-top: 120px;">
        <canvas id="contact-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container" style="position: relative; z-index: 2;">
            <h1 class="hero-title" style="color: #FFFFFF;">PARLONS DE VOTRE PROJET</h1>
            <p class="hero-subtitle" style="font-size: 1.2rem; max-width: 760px;">Une equipe premium pour transformer une idee ambitieuse en produit digital concret, performant et memorisable.</p>
        </div>
    </section>

    <section class="section">
        <div class="container" style="display: grid; grid-template-columns: minmax(0, 1.2fr) minmax(320px, 0.8fr); gap: 2rem; align-items: start;">
            <div class="glass" style="padding: 2rem; border-radius: 16px; border: 1px solid rgba(0,255,255,0.14);">
                <h2 class="section-title text-gradient" style="text-align: left; margin-bottom: 1.5rem;">DEMANDE DE CONTACT</h2>

                <?php if ($success): ?>
                    <div class="alert alert-success">Votre message a bien ete envoye. Nous revenons vers vous rapidement.</div>
                <?php endif; ?>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-error"><?= htmlspecialchars(implode(' ', $errors)) ?></div>
                <?php endif; ?>

                <form method="POST" action="contact.php" style="display: grid; gap: 1rem;">
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                        <input class="form-control" type="text" name="nom" placeholder="Votre nom" value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" required>
                        <input class="form-control" type="email" name="email" placeholder="Votre email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                        <input class="form-control" type="text" name="entreprise" placeholder="Entreprise" value="<?= htmlspecialchars($_POST['entreprise'] ?? '') ?>">
                        <select class="form-control" name="budget" style="background: rgba(8, 15, 26, 0.95); color: #FFFFFF; border: 1px solid rgba(0, 255, 255, 0.3); border-radius: 6px; padding: 0.75rem 1rem; font-family: 'Share Tech Mono', monospace; cursor: pointer; appearance: none; -webkit-appearance: none; outline: none;">
                            <option value="">Budget estime</option>
                            <?php foreach (['< 5k EUR', '5k-15k EUR', '15k-50k EUR', '50k+ EUR'] as $option): ?>
                                <option value="<?= htmlspecialchars($option) ?>" <?= (($_POST['budget'] ?? '') === $option) ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <select class="form-control" name="service" style="background: rgba(8, 15, 26, 0.95); color: #FFFFFF; border: 1px solid rgba(0, 255, 255, 0.3); border-radius: 6px; padding: 0.75rem 1rem; font-family: 'Share Tech Mono', monospace; cursor: pointer; appearance: none; -webkit-appearance: none; outline: none;">
                        <option value="">Service recherche</option>
                        <?php foreach (['Web Premium', 'Mobile Apps', 'IA & ML', 'Design & UX 3D', 'Cybersecurity & Cloud', 'Web3 & Metaverse'] as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= (($_POST['service'] ?? '') === $option) ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <textarea class="form-control" name="message" rows="7" placeholder="Decrivez votre projet, vos objectifs et vos contraintes..." required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>

                    <button type="submit" class="btn btn-primary" style="justify-self: start;">ENVOYER LA DEMANDE</button>
                </form>
            </div>

            <div style="display: grid; gap: 1.5rem;">
                <div class="glass" style="padding: 2rem; border-radius: 16px; border: 1px solid rgba(123,47,255,0.18);">
                    <h3 style="font-family: 'Orbitron'; color: #7B2FFF; margin-bottom: 1rem;">INFOS DIRECTES</h3>
                    <p style="color: var(--text-muted); margin-bottom: 0.75rem;">Email: contact@futuriste.dev</p>
                    <p style="color: var(--text-muted); margin-bottom: 0.75rem;">Telephone: +33 1 80 45 92 10</p>
                    <p style="color: var(--text-muted); margin-bottom: 0;">Disponibilite: lun-ven, 9h-18h</p>
                </div>

                <div class="glass" style="padding: 2rem; border-radius: 16px; border: 1px solid rgba(0,255,255,0.14);">
                    <h3 style="font-family: 'Orbitron'; color: #00FFFF; margin-bottom: 1rem;">CE QU ON PREPARE AVEC VOUS</h3>
                    <p style="color: var(--text-muted); line-height: 1.7; margin-bottom: 0.75rem;">Cadrage du besoin, recommandations techno, premiere estimation budget/delai et feuille de route de lancement.</p>
                    <p style="color: var(--text-muted); line-height: 1.7; margin-bottom: 0;">Le premier echange peut aussi couvrir recrutement, reprise d un projet en cours ou audit d une plateforme existante.</p>
                </div>
            </div>
        </div>
    </section>
</main>

<?php require_once 'includes/footer.php'; ?>
