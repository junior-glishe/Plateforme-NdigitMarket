<?php 
require_once 'includes/header.php'; 
require_once 'config/db.php'; 
require_once 'includes/functions.php';

try {
    $articles = $pdo->query("SELECT * FROM articles WHERE publie=1 ORDER BY created_at DESC LIMIT 9")->fetchAll();
} catch(PDOException $e) {
    $articles = [];
}

if(empty($articles)) {
    $articles = [
        ['titre'=>'IA Générative et Web Dev 2025','slug'=>'ia-webdev-2025','excerpt'=>'Comment GPT-4 et Claude transforment la façon dont nous codons. Nous testons ChatGPT Copilot vs Claude Code Assistant.','categorie'=>'Dev','image'=>'projet1.jpg','temps_lecture'=>12,'created_at'=>date('Y-m-d'),'auteur'=>'Alice Leclerc'],
        ['titre'=>'Three.js 2025 - Nouvelles Features','slug'=>'threejs-2025','excerpt'=>'Mesh instancing, shadows dynamiques avancées, performance 2x plus rapide. WebGPU support expérimental inclus.','categorie'=>'3D/WebGL','image'=>'projet2.jpg','temps_lecture'=>8,'created_at'=>date('Y-m-d',strtotime('-1 day')),'auteur'=>'Claude Petit'],
        ['titre'=>'Migration E-Commerce: 0 → 2M visites/mois','slug'=>'ecommerce-growth-story','excerpt'=>'Case study complet. Avant: Legacy PHP lent. Après: Next.js et AI recommendations. ROI: 340%.','categorie'=>'Case Study','image'=>'projet3.jpg','temps_lecture'=>15,'created_at'=>date('Y-m-d',strtotime('-2 days')),'auteur'=>'Marc Delorme'],
        ['titre'=>'Flutter vs React Native 2025','slug'=>'flutter-vs-react-native','excerpt'=>'Comparaison approfondie. Flutter gagne sur performance. React Native sur écosystème et maturité.','categorie'=>'Mobile','image'=>'projet4.jpg','temps_lecture'=>10,'created_at'=>date('Y-m-d',strtotime('-3 days')),'auteur'=>'Guillaume Durand'],
        ['titre'=>'RAG Implementation Avancée','slug'=>'rag-advanced','excerpt'=>'Retrieval Augmented Generation sans hallucinations. Architecture production avec LangChain et Pinecone.','categorie'=>'IA/ML','image'=>'projet5.jpg','temps_lecture'=>18,'created_at'=>date('Y-m-d',strtotime('-4 days')),'auteur'=>'Sarah Bouvier'],
        ['titre'=>'CSS 2025 Features Vous Manquez','slug'=>'css-2025-features','excerpt'=>'Container queries, sélecteur :has(), CSS nesting natif. Le futur du design web est là.','categorie'=>'Frontend','image'=>'projet6.jpg','temps_lecture'=>7,'created_at'=>date('Y-m-d',strtotime('-5 days')),'auteur'=>'Émilie Moreau'],
        ['titre'=>'Erreurs Smart Contracts Coûtent Cher','slug'=>'smart-contract-errors','excerpt'=>'Top 10 bugs Solidity. Reentrancy, overflow, gas optimization fails. Les audits tiers sont obligatoires.','categorie'=>'Web3','image'=>'projet7.jpg','temps_lecture'=>14,'created_at'=>date('Y-m-d',strtotime('-6 days')),'auteur'=>'Amélie Fontaine'],
        ['titre'=>'UX Research: 10K Utilisateurs Testés','slug'=>'ux-research-10k','excerpt'=>'Méthodologie research complète. Insights qui changent tout. Le testing continu sauve les projets.','categorie'=>'UX/Design','image'=>'projet1.jpg','temps_lecture'=>9,'created_at'=>date('Y-m-d',strtotime('-7 days')),'auteur'=>'Émilie Moreau'],
        ['titre'=>'Microservices vs Monolithe 2025','slug'=>'microservices-vs-monolith','excerpt'=>'Quand utiliser quoi? Monolithe rapide pour MVP. Microservices pour scale. Notre recommandation complète.','categorie'=>'Architecture','image'=>'projet2.jpg','temps_lecture'=>11,'created_at'=>date('Y-m-d',strtotime('-8 days')),'auteur'=>'Guillaume Durand'],
    ];
}
?>

<main>
    <section class="hero" style="padding-top: 120px;">
        <canvas id="blog-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container" style="position: relative; z-index: 2;">
            <h1 class="hero-title" style="color: #FFFFFF;">BLOG TECHNIQUE</h1>
            <p class="hero-subtitle" style="font-size: 1.3rem; max-width: 800px;">Insights, tutos, et case studies sur le web moderne, IA, et Web3</p>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem;">
                <article class="glass" style="border: 1px solid rgba(0,255,255,0.1); border-radius: 12px; overflow: hidden; transition: all 0.3s; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0s; cursor: pointer;" 
                    onclick="window.location.href='/agence-futuriste/blog-detail.php?slug=ia-webdev-2025'"
                    onmouseover="this.style.borderColor='#00FFFF'; this.style.boxShadow='0 0 30px rgba(0,255,255,0.2)'" 
                    onmouseout="this.style.borderColor='rgba(0,255,255,0.1)'; this.style.boxShadow=''">
                    <div style="position: relative; height: 200px; overflow: hidden; background: linear-gradient(135deg, #020408, #080f1a);">
                        <img src="assets/images/projet1.jpg" 
                             alt="IA Générative et Web Dev 2025" 
                             style="width: 100%; height: 100%; object-fit: cover; opacity: 0.85; transition: transform 0.6s ease;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="this.style.display='none';">
                        <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));"></div>
                        <span style="position: absolute; top: 1rem; right: 1rem; z-index: 2; background: #00FFFF; color: #000; padding: 0.35rem 0.75rem; border-radius: 4px; font-weight: 600; font-size: 0.75rem;">Dev</span>
                    </div>
                    <div style="padding: 1.5rem;">
                        <h3 style="color: #FFFFFF; margin-bottom: 0.75rem; font-family: 'Orbitron'; font-size: 1.1rem; line-height: 1.4;">IA Générative et Web Dev 2025</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem; line-height: 1.5;">Comment GPT-4 et Claude transforment la façon dont nous codons....</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 1rem; border-top: 1px solid rgba(0,255,255,0.1); font-size: 0.85rem; color: var(--text-muted);">
                            <div style="display: flex; gap: 1rem;">
                                <span>Lecture : 12 min</span>
                                <span>Par Alice Leclerc</span>
                            </div>
                            <span style="color: #00FFFF; font-size: 1.2rem;">&#8594;</span>
                        </div>
                    </div>
                </article>

                <article class="glass" style="border: 1px solid rgba(0,255,255,0.1); border-radius: 12px; overflow: hidden; transition: all 0.3s; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.1s; cursor: pointer;" 
                    onclick="window.location.href='/agence-futuriste/blog-detail.php?slug=threejs-2025'"
                    onmouseover="this.style.borderColor='#00FFFF'; this.style.boxShadow='0 0 30px rgba(0,255,255,0.2)'" 
                    onmouseout="this.style.borderColor='rgba(0,255,255,0.1)'; this.style.boxShadow=''">
                    <div style="position: relative; height: 200px; overflow: hidden; background: linear-gradient(135deg, #020408, #080f1a);">
                        <img src="assets/images/projet2.jpg" 
                             alt="Three.js 2025 - Nouvelles Features" 
                             style="width: 100%; height: 100%; object-fit: cover; opacity: 0.85; transition: transform 0.6s ease;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="this.style.display='none';">
                        <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));"></div>
                        <span style="position: absolute; top: 1rem; right: 1rem; z-index: 2; background: #00FFFF; color: #000; padding: 0.35rem 0.75rem; border-radius: 4px; font-weight: 600; font-size: 0.75rem;">3D/WebGL</span>
                    </div>
                    <div style="padding: 1.5rem;">
                        <h3 style="color: #FFFFFF; margin-bottom: 0.75rem; font-family: 'Orbitron'; font-size: 1.1rem; line-height: 1.4;">Three.js 2025 - Nouvelles Features</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem; line-height: 1.5;">Mesh instancing, shadows dynamiques avancées, performance 2x plus rapide....</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 1rem; border-top: 1px solid rgba(0,255,255,0.1); font-size: 0.85rem; color: var(--text-muted);">
                            <div style="display: flex; gap: 1rem;">
                                <span>Lecture : 8 min</span>
                                <span>Par Claude Petit</span>
                            </div>
                            <span style="color: #00FFFF; font-size: 1.2rem;">&#8594;</span>
                        </div>
                    </div>
                </article>

                <article class="glass" style="border: 1px solid rgba(0,255,255,0.1); border-radius: 12px; overflow: hidden; transition: all 0.3s; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.2s; cursor: pointer;" 
                    onclick="window.location.href='/agence-futuriste/blog-detail.php?slug=ecommerce-growth-story'"
                    onmouseover="this.style.borderColor='#00FFFF'; this.style.boxShadow='0 0 30px rgba(0,255,255,0.2)'" 
                    onmouseout="this.style.borderColor='rgba(0,255,255,0.1)'; this.style.boxShadow=''">
                    <div style="position: relative; height: 200px; overflow: hidden; background: linear-gradient(135deg, #020408, #080f1a);">
                        <img src="assets/images/projet3.jpg" 
                             alt="Migration E-Commerce: 0 → 2M visites/mois" 
                             style="width: 100%; height: 100%; object-fit: cover; opacity: 0.85; transition: transform 0.6s ease;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="this.style.display='none';">
                        <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));"></div>
                        <span style="position: absolute; top: 1rem; right: 1rem; z-index: 2; background: #00FFFF; color: #000; padding: 0.35rem 0.75rem; border-radius: 4px; font-weight: 600; font-size: 0.75rem;">Case Study</span>
                    </div>
                    <div style="padding: 1.5rem;">
                        <h3 style="color: #FFFFFF; margin-bottom: 0.75rem; font-family: 'Orbitron'; font-size: 1.1rem; line-height: 1.4;">Migration E-Commerce: 0 → 2M visites/mois</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem; line-height: 1.5;">Case study complet. Avant: Legacy PHP lent. Après: Next.js et AI recommendations....</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 1rem; border-top: 1px solid rgba(0,255,255,0.1); font-size: 0.85rem; color: var(--text-muted);">
                            <div style="display: flex; gap: 1rem;">
                                <span>Lecture : 15 min</span>
                                <span>Par Marc Delorme</span>
                            </div>
                            <span style="color: #00FFFF; font-size: 1.2rem;">&#8594;</span>
                        </div>
                    </div>
                </article>

                <article class="glass" style="border: 1px solid rgba(0,255,255,0.1); border-radius: 12px; overflow: hidden; transition: all 0.3s; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.3s; cursor: pointer;" 
                    onclick="window.location.href='/agence-futuriste/blog-detail.php?slug=flutter-vs-react-native'"
                    onmouseover="this.style.borderColor='#00FFFF'; this.style.boxShadow='0 0 30px rgba(0,255,255,0.2)'" 
                    onmouseout="this.style.borderColor='rgba(0,255,255,0.1)'; this.style.boxShadow=''">
                    <div style="position: relative; height: 200px; overflow: hidden; background: linear-gradient(135deg, #020408, #080f1a);">
                        <img src="assets/images/projet4.jpg" 
                             alt="Flutter vs React Native 2025" 
                             style="width: 100%; height: 100%; object-fit: cover; opacity: 0.85; transition: transform 0.6s ease;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="this.style.display='none';">
                        <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));"></div>
                        <span style="position: absolute; top: 1rem; right: 1rem; z-index: 2; background: #00FFFF; color: #000; padding: 0.35rem 0.75rem; border-radius: 4px; font-weight: 600; font-size: 0.75rem;">Mobile</span>
                    </div>
                    <div style="padding: 1.5rem;">
                        <h3 style="color: #FFFFFF; margin-bottom: 0.75rem; font-family: 'Orbitron'; font-size: 1.1rem; line-height: 1.4;">Flutter vs React Native 2025</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem; line-height: 1.5;">Comparaison approfondie. Flutter gagne sur performance. React Native sur écosystème....</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 1rem; border-top: 1px solid rgba(0,255,255,0.1); font-size: 0.85rem; color: var(--text-muted);">
                            <div style="display: flex; gap: 1rem;">
                                <span>Lecture : 10 min</span>
                                <span>Par Guillaume Durand</span>
                            </div>
                            <span style="color: #00FFFF; font-size: 1.2rem;">&#8594;</span>
                        </div>
                    </div>
                </article>

                <article class="glass" style="border: 1px solid rgba(0,255,255,0.1); border-radius: 12px; overflow: hidden; transition: all 0.3s; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.4s; cursor: pointer;" 
                    onclick="window.location.href='/agence-futuriste/blog-detail.php?slug=rag-advanced'"
                    onmouseover="this.style.borderColor='#00FFFF'; this.style.boxShadow='0 0 30px rgba(0,255,255,0.2)'" 
                    onmouseout="this.style.borderColor='rgba(0,255,255,0.1)'; this.style.boxShadow=''">
                    <div style="position: relative; height: 200px; overflow: hidden; background: linear-gradient(135deg, #020408, #080f1a);">
                        <img src="assets/images/projet5.jpg" 
                             alt="RAG Implementation Avancée" 
                             style="width: 100%; height: 100%; object-fit: cover; opacity: 0.85; transition: transform 0.6s ease;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="this.style.display='none';">
                        <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));"></div>
                        <span style="position: absolute; top: 1rem; right: 1rem; z-index: 2; background: #00FFFF; color: #000; padding: 0.35rem 0.75rem; border-radius: 4px; font-weight: 600; font-size: 0.75rem;">IA/ML</span>
                    </div>
                    <div style="padding: 1.5rem;">
                        <h3 style="color: #FFFFFF; margin-bottom: 0.75rem; font-family: 'Orbitron'; font-size: 1.1rem; line-height: 1.4;">RAG Implementation Avancée</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem; line-height: 1.5;">Retrieval Augmented Generation sans hallucinations. Architecture production avec LangChain....</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 1rem; border-top: 1px solid rgba(0,255,255,0.1); font-size: 0.85rem; color: var(--text-muted);">
                            <div style="display: flex; gap: 1rem;">
                                <span>Lecture : 18 min</span>
                                <span>Par Sarah Bouvier</span>
                            </div>
                            <span style="color: #00FFFF; font-size: 1.2rem;">&#8594;</span>
                        </div>
                    </div>
                </article>

                <article class="glass" style="border: 1px solid rgba(0,255,255,0.1); border-radius: 12px; overflow: hidden; transition: all 0.3s; opacity: 0; animation: fadeInUp 0.8s ease forwards; animation-delay: 0.5s; cursor: pointer;" 
                    onclick="window.location.href='/agence-futuriste/blog-detail.php?slug=css-2025-features'"
                    onmouseover="this.style.borderColor='#00FFFF'; this.style.boxShadow='0 0 30px rgba(0,255,255,0.2)'" 
                    onmouseout="this.style.borderColor='rgba(0,255,255,0.1)'; this.style.boxShadow=''">
                    <div style="position: relative; height: 200px; overflow: hidden; background: linear-gradient(135deg, #020408, #080f1a);">
                        <img src="assets/images/projet6.jpg" 
                             alt="CSS 2025 Features Vous Manquez" 
                             style="width: 100%; height: 100%; object-fit: cover; opacity: 0.85; transition: transform 0.6s ease;"
                             onmouseover="this.style.transform='scale(1.05)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="this.style.display='none';">
                        <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));"></div>
                        <span style="position: absolute; top: 1rem; right: 1rem; z-index: 2; background: #00FFFF; color: #000; padding: 0.35rem 0.75rem; border-radius: 4px; font-weight: 600; font-size: 0.75rem;">Frontend</span>
                    </div>
                    <div style="padding: 1.5rem;">
                        <h3 style="color: #FFFFFF; margin-bottom: 0.75rem; font-family: 'Orbitron'; font-size: 1.1rem; line-height: 1.4;">CSS 2025 Features Vous Manquez</h3>
                        <p style="color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem; line-height: 1.5;">Container queries, sélecteur :has(), CSS nesting natif....</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 1rem; border-top: 1px solid rgba(0,255,255,0.1); font-size: 0.85rem; color: var(--text-muted);">
                            <div style="display: flex; gap: 1rem;">
                                <span>Lecture : 7 min</span>
                                <span>Par Émilie Moreau</span>
                            </div>
                            <span style="color: #00FFFF; font-size: 1.2rem;">&#8594;</span>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="section" style="background: rgba(123,47,255,0.05);">
        <div class="container" style="text-align: center;">
            <h2 style="font-size: 2rem; margin-bottom: 1rem;">Intéressé par nos insights ?</h2>
            <p style="color: var(--text-muted); margin-bottom: 2rem; font-size: 1.1rem;">Inscrivez-vous à notre newsletter tech (1 fois par semaine)</p>
            <div style="display: flex; max-width: 500px; margin: 0 auto; gap: 1rem;">
                <input type="email" placeholder="Votre email..." style="flex: 1; padding: 0.75rem 1rem; background: rgba(0,255,255,0.05); border: 1px solid rgba(0,255,255,0.2); border-radius: 8px; color: #fff;" />
                <button style="padding: 0.75rem 2rem; background: linear-gradient(135deg, #00FFFF, #7B2FFF); color: #000; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">S'INSCRIRE</button>
            </div>
        </div>
    </section>
</main>

<style>
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>

<?php require_once 'includes/footer.php'; ?>
