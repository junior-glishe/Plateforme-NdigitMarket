<?php 
require_once 'includes/header.php'; 
require_once 'config/db.php'; 
require_once 'includes/functions.php';

try {
    $projets = $pdo->query("SELECT * FROM projets WHERE featured=1 ORDER BY ordre LIMIT 3")->fetchAll();
    $temoignages = $pdo->query("SELECT * FROM temoignages WHERE valide=1 ORDER BY RAND() LIMIT 3")->fetchAll();
    $articles = $pdo->query("SELECT id, titre, extrait, categorie, created_at, temps_lecture FROM articles WHERE publie=1 ORDER BY created_at DESC LIMIT 3")->fetchAll();
} catch(PDOException $e) {
    $projets = [];
    $temoignages = [];
    $articles = [];
}
$page_script = 'assets/js/home.js';

// DEBUG - Vérification des images disponibles
$img_debug = [];
$img_path = $_SERVER['DOCUMENT_ROOT'] . '/agence-futuriste/assets/images/';
if (is_dir($img_path)) {
    $files = scandir($img_path);
    $img_debug = array_filter($files, function($f) { return !in_array($f, ['.','..']); });
}
?>

<!-- 📸 DEBUG: Images disponibles: <?= implode(' | ', $img_debug) ?> -->
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 </head>
<style>
select,
select.form-control {
    background: #080f1a !important;
    color: #FFFFFF !important;
    border: 1px solid rgba(0, 255, 255, 0.25) !important;
    border-radius: 6px !important;
    padding: 0.75rem 1rem !important;
    font-family: 'Share Tech Mono', monospace !important;
    cursor: pointer !important;
    appearance: none !important;
    -webkit-appearance: none !important;
    outline: none !important;
    width: 100% !important;
}

select:focus,
select.form-control:focus {
    border-color: #00FFFF !important;
    box-shadow: 0 0 0 2px rgba(0, 255, 255, 0.15) !important;
}

select option {
    background: #080f1a !important;
    color: #FFFFFF !important;
    padding: 0.5rem !important;
}

select option:hover,
select option:checked,
select option:focus {
    background: rgba(0, 255, 255, 0.15) !important;
    color: #00FFFF !important;
}
</style>
 <body>
    
<main>


    <!-- HERO -->
    <section class="hero" data-animate="fade-up">
        <canvas id="index-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container">
            <h1 class="hero-title" data-text="ON CONSTUIT LE FUTURE " style="
    color: #FFFFFF;
    -webkit-text-fill-color: #FFFFFF;
    background: none;
    text-shadow: 0 0 40px rgba(255,255,255,0.3), 
                 0 0 80px rgba(0,255,255,0.15);
">ON CONSTUIT LE FUTURE </h1>
            <p class="hero-subtitle">Agence digitale futuriste spécialisée Web3, IA, 3D et applications mobiles de pointe</p>
            <div style="display: flex; gap: 1.5rem; justify-content: center; flex-wrap: wrap;">
                <a href="services.php" class="btn btn-primary">DÉCOUVRIR NOS SERVICES</a>
                <a href="portfolio.php" class="btn btn-outline">VOIR NOTRE PORTFOLIO</a>
            </div>
        </div>
        <div class="scroll-indicator" style="position: absolute; bottom: 3rem; left: 50%; transform: translateX(-50%); color: var(--primary); font-size: 1.2rem; animation: bounce 2s infinite;">
            ↓ SCROLL ↓
        </div>
    </section>

    <!-- STATS -->
    <section class="section container" data-animate="stagger">
        <div class="stats-grid">
            <div class="stat-item fade-in" data-count="150">
                <span class="stat-number" data-count="150">0</span>
                <span class="stat-label">Projets Réalisés</span>
            </div>
            <div class="stat-item fade-in" data-count="8">
                <span class="stat-number" data-count="8">0</span>
                <span class="stat-label">Années d'Expertise</span>
            </div>
            <div class="stat-item fade-in" data-count="45">
                <span class="stat-number" data-count="45">0</span>
                <span class="stat-label">Experts</span>
            </div>
            <div class="stat-item fade-in" data-count="99">
                <span class="stat-number" data-count="99">0</span>%
                <span class="stat-label">Satisfaction Client</span>
            </div>
        </div>
    </section>

    <!-- CLIENTS MARQUEE -->
    <section class="section" style="background: rgba(8,15,26,0.3);">
        <div class="container">
            <h3 style="text-align: center; color: var(--text-muted); font-size: 0.95rem; margin-bottom: 3rem; text-transform: uppercase; letter-spacing: 2px;">ILS NOUS ONT FAIT CONFIANCE</h3>
            <div style="overflow: hidden; width: 100%;">
                <div class="marquee-track" style="display: flex; gap: 4rem;">
                    <?php $clients = ['TESLA', 'AIRBNB', 'SPOTIFY', 'AMAZON', 'NETFLIX', 'APPLE', 'GOOGLE', 'META']; ?>
                    <?php foreach(array_merge($clients, $clients) as $client): ?>
                    <div style="flex-shrink: 0; font-family: 'Orbitron'; font-weight: 700; font-size: 1.5rem; opacity: 0.4; transition: opacity 0.3s; white-space: nowrap; letter-spacing: 1px;">
                        <span class="client-logo" style="cursor: pointer; background: linear-gradient(135deg, #00ffff, #7b2fff); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; filter: drop-shadow(0 0 10px rgba(0,255,255,0));">
                            <?= $client ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- POURQUOI NEXUS -->
    <section class="section" style="background: rgba(123,47,255,0.05);">
        <div class="container">
            <h2 class="section-title text-gradient" data-animate="reveal">POURQUOI NEXUS ?</h2>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; margin-top: 4rem;">
                <!-- Colonne gauche -->
                <div class="fade-in" data-animate="fade-up">
                    <h3 style="font-family: 'Orbitron'; font-size: 2.2rem; line-height: 1.3; margin-bottom: 2rem; color: var(--primary);">
                        Nous ne faisons pas du web.<br>
                        <span style="color: var(--text); font-weight: 400;">Nous faisons de l'art digital.</span>
                    </h3>
                    <p style="font-size: 1.1rem; line-height: 1.8; color: var(--text-muted); margin-bottom: 2rem;">
                        Depuis 8 ans, nous transformons les rêves numériques en réalités interactives. Notre approche combine vision artistique, expertise technique et stratégie commerciale pour créer des expériences digitales qui marquent les esprits et convertissent les visiteurs en clients.
                    </p>
                    <a href="about.php" class="btn btn-primary">NOTRE HISTOIRE</a>
                </div>

                <!-- Colonne droite - Features -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="feature-item fade-in" style="transition: transform 0.3s, border-left 0.3s; border-left: 2px solid transparent; padding: 1.5rem;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin-bottom: 1rem;">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8m3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-bottom: 0.5rem;">Livraison Express</h4>
                        <p style="font-size: 0.95rem; color: var(--text-muted);">Projets livrés en 4-6 semaines</p>
                    </div>

                    <div class="feature-item fade-in" style="transition: transform 0.3s, border-left 0.3s; border-left: 2px solid transparent; padding: 1.5rem;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin-bottom: 1rem;">
                            <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/>
                            <polyline points="13 2 13 9 20 9"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-bottom: 0.5rem;">Code Premium</h4>
                        <p style="font-size: 0.95rem; color: var(--text-muted);">Architecture clean, scalable, documentée</p>
                    </div>

                    <div class="feature-item fade-in" style="transition: transform 0.3s, border-left 0.3s; border-left: 2px solid transparent; padding: 1.5rem;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin-bottom: 1rem;">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                            <line x1="9" y1="9" x2="15" y2="9"/>
                            <line x1="9" y1="15" x2="15" y2="15"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-bottom: 0.5rem;">Design 4K</h4>
                        <p style="font-size: 0.95rem; color: var(--text-muted);">UI/UX qui convertit et impressionne</p>
                    </div>

                    <div class="feature-item fade-in" style="transition: transform 0.3s, border-left 0.3s; border-left: 2px solid transparent; padding: 1.5rem;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin-bottom: 1rem;">
                            <circle cx="12" cy="12" r="1"/>
                            <path d="M12 1v6m0 6v6"/>
                            <path d="M4.22 4.22l4.24 4.24m2.12 2.12l4.24 4.24"/>
                            <path d="M1 12h6m6 0h6"/>
                            <path d="M4.22 19.78l4.24-4.24m2.12-2.12l4.24-4.24"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-bottom: 0.5rem;">Support 24/7</h4>
                        <p style="font-size: 0.95rem; color: var(--text-muted);">Équipe disponible à toute heure</p>
                    </div>

                    <div class="feature-item fade-in" style="transition: transform 0.3s, border-left 0.3s; border-left: 2px solid transparent; padding: 1.5rem;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin-bottom: 1rem;">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-bottom: 0.5rem;">IA Intégrée</h4>
                        <p style="font-size: 0.95rem; color: var(--text-muted);">Automatisation intelligente by default</p>
                    </div>

                    <div class="feature-item fade-in" style="transition: transform 0.3s, border-left 0.3s; border-left: 2px solid transparent; padding: 1.5rem;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin-bottom: 1rem;">
                            <line x1="12" y1="1" x2="12" y2="23"/>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-bottom: 0.5rem;">ROI Garanti</h4>
                        <p style="font-size: 0.95rem; color: var(--text-muted);">Résultats mesurables ou remboursement</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- STACK TECHNOLOGIQUE -->
    <section class="section" style="background: rgba(8,15,26,0.5);">
        <div class="container">
            <h2 class="section-title text-gradient" data-animate="reveal">NOTRE ARSENAL TECHNOLOGIQUE</h2>
            <p style="text-align: center; color: var(--text-muted); font-size: 1.1rem; margin-bottom: 4rem;">Les meilleures technologies pour les meilleurs résultats</p>
            
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 2rem;">
                <!-- Frontend -->
                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#00ffff" stroke-width="2" style="margin: 0 auto 1rem; animation: spin 3s linear infinite;">
                        <circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/><circle cx="12" cy="19" r="1"/><circle cx="12" cy="5" r="1"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">React</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#7b2fff" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 2L2 7L2 17L12 22L22 17L22 7L12 2Z"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Next.js</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#ff2d78" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Three.js</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#00ff88" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Vue.js</h4>
                </div>

                <!-- Backend -->
                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#8b7bff" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M3 9h18M3 15h18"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">PHP</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#ffcc00" stroke-width="2" style="margin: 0 auto 1rem;">
                        <circle cx="12" cy="12" r="10"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Node.js</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#3776ab" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Python</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#ff4757" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 17V3m0 14h6m-6 0H6"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Laravel</h4>
                </div>

                <!-- Mobile -->
                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#4495ff" stroke-width="2" style="margin: 0 auto 1rem;">
                        <rect x="5" y="2" width="14" height="20" rx="2"/>
                        <path d="M12 21h0M12 18h0"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Flutter</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#61dafb" stroke-width="2" style="margin: 0 auto 1rem;">
                        <circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">React Native</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#fa7343" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Swift</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#3ddc84" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 17V7m0 10h6m-6 0H6"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Kotlin</h4>
                </div>

                <!-- Infra -->
                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#2496ed" stroke-width="2" style="margin: 0 auto 1rem;">
                        <rect x="3" y="3" width="18" height="18" rx="2"/>
                        <line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/>
                        <line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">Docker</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#ff9900" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">AWS</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#13aa52" stroke-width="2" style="margin: 0 auto 1rem;">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M8 14s1.5 2 4 2 4-2 4-2"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">MySQL</h4>
                </div>

                <div class="tech-item fade-in" style="text-align: center; padding: 2rem; border: 1px solid rgba(0,255,255,0.1); border-radius: 8px; transition: transform 0.3s, filter 0.3s;">
                    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#13aa52" stroke-width="2" style="margin: 0 auto 1rem;">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2"/>
                    </svg>
                    <h4 style="font-family: 'Share Tech Mono'; margin: 1rem 0 0.5rem;">MongoDB</h4>
                </div>
            </div>
        </div>
    </section>

    <!-- SERVICES PREVIEW -->
    <section class="section" style="background: rgba(8,15,26,0.5);">
        <div class="container">
            <h2 class="section-title text-gradient" data-animate="reveal">NOS SERVICES</h2>
            <div class="grid grid-3" data-animate="stagger">
                <div class="card card-tilt fade-in">
                    <div class="service-icon">
                        <canvas class="service-canvas" data-service="web"></canvas>
                    </div>
                    <h3>Web Futuriste</h3>
                    <p>Next.js, Three.js, WebGL, PWA ultra-performantes</p>
                    <a href="services.php" class="btn btn-outline mt-auto">DÉCOUVRIR</a>
                </div>
                <div class="card card-tilt fade-in">
                    <div class="service-icon">
                        <canvas class="service-canvas" data-service="mobile"></canvas>
                    </div>
                    <h3>Mobile Natif</h3>
                    <p>React Native, Flutter, Swift, Kotlin</p>
                    <a href="services.php#mobile" class="btn btn-outline mt-auto">DÉCOUVRIR</a>
                </div>
                <div class="card card-tilt fade-in">
                    <div class="service-icon">
                        <canvas class="service-canvas" data-service="ia"></canvas>
                    </div>
                    <h3>Intelligence Artificielle</h3>
                    <p>TensorFlow, GPT, Computer Vision, NLP</p>
                    <a href="services.php#ia" class="btn btn-outline mt-auto">DÉCOUVRIR</a>
                </div>
            </div>
        </div>
    </section>

        </div>
    </section>

    <!-- PROCESS DE TRAVAIL -->
    <section class="section" style="background: rgba(0,255,255,0.03);">
        <div class="container">
            <h2 class="section-title text-gradient" data-animate="reveal">COMMENT ÇA MARCHE ?</h2>
            
            <div style="position: relative; margin-top: 4rem;">
                <!-- Ligne de connexion -->
                <svg style="position: absolute; top: 40px; left: 5%; width: 90%; height: 2px; z-index: 0;" viewBox="0 0 1000 2" preserveAspectRatio="none">
                    <line x1="0" y1="1" x2="1000" y2="1" stroke="url(#lineGradient)" stroke-width="2" class="process-line" style="stroke-dasharray: 1000; stroke-dashoffset: 1000; transition: stroke-dashoffset 2s ease;"/>
                    <defs>
                        <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" style="stop-color:#00ffff;stop-opacity:0.5"/>
                            <stop offset="50%" style="stop-color:#7b2fff;stop-opacity:0.5"/>
                            <stop offset="100%" style="stop-color:#00ff88;stop-opacity:0.5"/>
                        </linearGradient>
                    </defs>
                </svg>

                <!-- Étapes -->
                <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 2rem; position: relative; z-index: 1;">
                    <div class="process-step fade-in" style="text-align: center; opacity: 0.3; transition: opacity 0.5s;">
                        <div style="background: radial-gradient(135deg, #00ffff, #00d4ff); border-radius: 50%; width: 80px; height: 80px; margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-weight: 700; font-size: 1.8rem; color: #000;">
                            01
                        </div>
                        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin: 0 auto 1rem;">
                            <path d="M15.5 1h-8C6.12 1 5 2.12 5 3.5v17C5 21.88 6.12 23 7.5 23h8c1.38 0 2.5-1.12 2.5-2.5v-17C18 2.12 16.88 1 15.5 1zm-4 21c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm4.5-4H7V4h9v14z"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-top: 1rem;">DÉCOUVERTE</h4>
                        <p style="font-size: 0.9rem; color: var(--text-muted); margin-top: 0.5rem;">On analyse votre vision et vos objectifs</p>
                    </div>

                    <div class="process-step fade-in" style="text-align: center; opacity: 0.3; transition: opacity 0.5s;">
                        <div style="background: radial-gradient(135deg, #7b2fff, #9f47ff); border-radius: 50%; width: 80px; height: 80px; margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-weight: 700; font-size: 1.8rem; color: #000;">
                            02
                        </div>
                        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin: 0 auto 1rem;">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                            <polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-top: 1rem;">STRATÉGIE</h4>
                        <p style="font-size: 0.9rem; color: var(--text-muted); margin-top: 0.5rem;">Architecture technique et plan de bataille</p>
                    </div>

                    <div class="process-step fade-in" style="text-align: center; opacity: 0.3; transition: opacity 0.5s;">
                        <div style="background: radial-gradient(135deg, #ff2d78, #ff6b9d); border-radius: 50%; width: 80px; height: 80px; margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-weight: 700; font-size: 1.8rem; color: #000;">
                            03
                        </div>
                        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin: 0 auto 1rem;">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8m3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-top: 1rem;">DESIGN</h4>
                        <p style="font-size: 0.9rem; color: var(--text-muted); margin-top: 0.5rem;">Maquettes UI/UX qui transforment</p>
                    </div>

                    <div class="process-step fade-in" style="text-align: center; opacity: 0.3; transition: opacity 0.5s;">
                        <div style="background: radial-gradient(135deg, #00ff88, #00ffaa); border-radius: 50%; width: 80px; height: 80px; margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-weight: 700; font-size: 1.8rem; color: #000;">
                            04
                        </div>
                        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin: 0 auto 1rem;">
                            <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/>
                            <polyline points="17 6 23 6 23 12"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-top: 1rem;">BUILD</h4>
                        <p style="font-size: 0.9rem; color: var(--text-muted); margin-top: 0.5rem;">Développement agile avec demos</p>
                    </div>

                    <div class="process-step fade-in" style="text-align: center; opacity: 0.3; transition: opacity 0.5s;">
                        <div style="background: radial-gradient(135deg, #ffcc00, #ffdd33); border-radius: 50%; width: 80px; height: 80px; margin: 0 auto 1.5rem; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-weight: 700; font-size: 1.8rem; color: #000;">
                            05
                        </div>
                        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" style="margin: 0 auto 1rem;">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                        </svg>
                        <h4 style="font-family: 'Orbitron'; font-size: 1.1rem; margin-top: 1rem;">LAUNCH</h4>
                        <p style="font-size: 0.9rem; color: var(--text-muted); margin-top: 0.5rem;">Déploiement et suivi post-lancement</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- PORTFOLIO PREVIEW -->
    <section class="section">
        <div class="container">
            <div style="text-align: center; margin-bottom: 2rem;">
                <h2 class="section-title text-gradient" data-animate="reveal">NOS RÉALISATIONS</h2>
                <p style="color: var(--text-muted); font-size: 1.1rem;">Découvrez quelques projets qui définissent notre excellence</p>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem;" data-animate="stagger">
                
                <!-- PROJET 1 -->
                <?php if(!empty($projets)): ?>
                <?php foreach($projets as $index => $projet): ?>
                <?php
                    $images_projet = ['assets/images/projet1.jpg', 'assets/images/projet2.jpg', 'assets/images/projet3.jpg'];
                    $img = $images_projet[$index] ?? 'assets/images/projet1.jpg';
                    $technos_list = json_decode($projet['technos'] ?? '[]', true) ?: ['React', 'PHP', 'MySQL'];
                ?>
                <div class="portfolio-card-new fade-in" style="
                    background: rgba(8,15,26,0.9);
                    border: 1px solid rgba(0,255,255,0.12);
                    border-radius: 12px;
                    overflow: hidden;
                    transition: transform 0.4s, box-shadow 0.4s;
                    cursor: pointer;
                " onmouseover="this.style.transform='translateY(-10px)'; this.style.boxShadow='0 20px 60px rgba(0,255,255,0.15)'"
                   onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                    
                    <!-- Image du projet -->
                    <div style="position: relative; overflow: hidden; height: 200px;">
                        <!-- Placeholder visible SEULEMENT si image absente -->
                        <div class="img-placeholder" style="position: absolute; inset: 0; 
                             display: flex; align-items: center; justify-content: center; 
                             font-family: 'Orbitron'; font-size: 3rem; 
                             color: rgba(0,255,255,0.15); z-index: 0;">◈</div>
                        
                        <!-- Image par dessus le placeholder -->
                        <img src="<?= htmlspecialchars($img) ?>" 
                             alt="<?= htmlspecialchars($projet['titre']) ?>"
                             style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; 
                                    transition: transform 0.5s; z-index: 1;"
                             onmouseover="this.style.transform='scale(1.08)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="console.error('Image non trouvée: ' + this.src); this.style.display='none';">
                        
                        <!-- Overlay catégorie z-index plus haut -->
                        <div style="position: absolute; top: 1rem; left: 1rem; z-index: 2;">
                            <span style="background: linear-gradient(135deg, #00ffff, #7b2fff); 
                                         color: #000; padding: 0.3rem 0.8rem; 
                                         border-radius: 50px; font-size: 0.75rem; 
                                         font-weight: 700; font-family: 'Share Tech Mono';">
                                <?= strtoupper(htmlspecialchars($projet['categorie'])) ?>
                            </span>
                        </div>
                    </div>

                    <!-- Infos projet style "profil" -->
                    <div style="padding: 1.8rem;">
                        <!-- Titre + client -->
                        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.2rem;">
                            <div style="width: 48px; height: 48px; border-radius: 50%; 
                                        background: linear-gradient(135deg, #00ffff, #7b2fff);
                                        display: flex; align-items: center; justify-content: center;
                                        font-family: 'Orbitron'; font-weight: 700; color: #000; font-size: 1rem;
                                        flex-shrink: 0;">
                                <?= strtoupper(substr(htmlspecialchars($projet['titre']), 0, 1)) ?>
                            </div>
                            <div>
                                <h3 style="font-family: 'Orbitron'; font-size: 1rem; margin: 0; line-height: 1.3;">
                                    <?= htmlspecialchars($projet['titre']) ?>
                                </h3>
                                <span style="color: var(--text-muted); font-size: 0.85rem;">
                                    <?= htmlspecialchars($projet['client'] ?? 'Client Confidentiel') ?>
                                </span>
                            </div>
                        </div>

                        <!-- Description -->
                        <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6; margin-bottom: 1.5rem;">
                            <?= htmlspecialchars(substr($projet['description'] ?? '', 0, 100)) ?>...
                        </p>

                        <!-- Technos style "compétences" -->
                        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.5rem;">
                            <?php foreach(array_slice($technos_list, 0, 4) as $techno): ?>
                            <span style="background: rgba(0,255,255,0.08); 
                                         border: 1px solid rgba(0,255,255,0.2);
                                         color: var(--primary); 
                                         padding: 0.25rem 0.6rem; 
                                         border-radius: 4px; 
                                         font-size: 0.75rem;
                                         font-family: 'Share Tech Mono';">
                                <?= htmlspecialchars($techno) ?>
                            </span>
                            <?php endforeach; ?>
                        </div>

                        <!-- Bouton -->
                        <a href="portfolio.php" class="btn btn-outline" 
                           style="width: 100%; text-align: center; display: block; padding: 0.6rem;">
                            VOIR LE PROJET →
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>

                <?php else: ?>
                <!-- FALLBACK STATIQUE si BDD vide -->
                <!-- Projet 1 -->
                <div class="portfolio-card-new fade-in" style="background: rgba(8,15,26,0.9); border: 1px solid rgba(0,255,255,0.12); border-radius: 12px; overflow: hidden; transition: transform 0.4s, box-shadow 0.4s;"
                     onmouseover="this.style.transform='translateY(-10px)'; this.style.boxShadow='0 20px 60px rgba(0,255,255,0.15)'"
                     onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                    <div style="position: relative; overflow: hidden; height: 200px; background: linear-gradient(135deg, #020408, #0d1f3c);">
                        <!-- Placeholder visible SEULEMENT si image absente -->
                        <div class="img-placeholder" style="position: absolute; inset: 0; 
                             display: flex; align-items: center; justify-content: center; 
                             font-family: 'Orbitron'; font-size: 3rem; 
                             color: rgba(0,255,255,0.15); z-index: 0;">◈</div>
                        
                        <!-- Image par dessus le placeholder, z-index plus haut -->
                        <img src="assets/images/projet1.jpg" alt="Nexus Bank"
                             style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; 
                                    z-index: 1; transition: transform 0.5s;"
                             onmouseover="this.style.transform='scale(1.08)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="console.error('Image non trouvée: ' + this.src); this.style.display='none';">
                        
                        <!-- Badge catégorie z-index encore plus haut -->
                        <div style="position: absolute; top: 1rem; left: 1rem; z-index: 2;">
                            <span style="background: linear-gradient(135deg, #00ffff, #7b2fff); color: #000; padding: 0.3rem 0.8rem; border-radius: 50px; font-size: 0.75rem; font-weight: 700;">WEB</span>
                        </div>
                    </div>
                    <div style="padding: 1.8rem;">
                        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.2rem;">
                            <div style="width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, #00ffff, #7b2fff); display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-weight: 700; color: #000; font-size: 1.1rem; flex-shrink: 0;">N</div>
                            <div>
                                <h3 style="font-family: 'Orbitron'; font-size: 1rem; margin: 0;">Nexus Bank</h3>
                                <span style="color: var(--text-muted); font-size: 0.85rem;">FinTech Corp</span>
                            </div>
                        </div>
                        <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6; margin-bottom: 1.5rem;">Plateforme bancaire futuriste avec IA antifraude intégrée et dashboard temps réel.</p>
                        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.5rem;">
                            <span style="background: rgba(0,255,255,0.08); border: 1px solid rgba(0,255,255,0.2); color: var(--primary); padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">React</span>
                            <span style="background: rgba(0,255,255,0.08); border: 1px solid rgba(0,255,255,0.2); color: var(--primary); padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">Node.js</span>
                            <span style="background: rgba(0,255,255,0.08); border: 1px solid rgba(0,255,255,0.2); color: var(--primary); padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">AI</span>
                            <span style="background: rgba(0,255,255,0.08); border: 1px solid rgba(0,255,255,0.2); color: var(--primary); padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">MySQL</span>
                        </div>
                        <a href="portfolio.php" class="btn btn-outline" style="width: 100%; text-align: center; display: block; padding: 0.6rem;">VOIR LE PROJET →</a>
                    </div>
                </div>

                <!-- Projet 2 -->
                <div class="portfolio-card-new fade-in" style="background: rgba(8,15,26,0.9); border: 1px solid rgba(0,255,255,0.12); border-radius: 12px; overflow: hidden; transition: transform 0.4s, box-shadow 0.4s;"
                     onmouseover="this.style.transform='translateY(-10px)'; this.style.boxShadow='0 20px 60px rgba(123,47,255,0.15)'"
                     onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                    <div style="position: relative; overflow: hidden; height: 200px; background: linear-gradient(135deg, #0a0020, #1a0040);">
                        <!-- Placeholder visible SEULEMENT si image absente -->
                        <div class="img-placeholder" style="position: absolute; inset: 0; 
                             display: flex; align-items: center; justify-content: center; 
                             font-family: 'Orbitron'; font-size: 3rem; 
                             color: rgba(123,47,255,0.2); z-index: 0;">◈</div>
                        
                        <!-- Image par dessus le placeholder, z-index plus haut -->
                        <img src="assets/images/projet2.jpg" alt="SpaceX Dashboard"
                             style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; 
                                    z-index: 1; transition: transform 0.5s;"
                             onmouseover="this.style.transform='scale(1.08)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="console.error('Image non trouvée: ' + this.src); this.style.display='none';">
                        
                        <!-- Badge catégorie z-index encore plus haut -->
                        <div style="position: absolute; top: 1rem; left: 1rem; z-index: 2;">
                            <span style="background: linear-gradient(135deg, #7b2fff, #ff2d78); color: #fff; padding: 0.3rem 0.8rem; border-radius: 50px; font-size: 0.75rem; font-weight: 700;">IA</span>
                        </div>
                    </div>
                    <div style="padding: 1.8rem;">
                        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.2rem;">
                            <div style="width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, #7b2fff, #ff2d78); display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-weight: 700; color: #fff; font-size: 1.1rem; flex-shrink: 0;">S</div>
                            <div>
                                <h3 style="font-family: 'Orbitron'; font-size: 1rem; margin: 0;">SpaceX Dashboard</h3>
                                <span style="color: var(--text-muted); font-size: 0.85rem;">Space Analytics</span>
                            </div>
                        </div>
                        <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6; margin-bottom: 1.5rem;">Suivi temps réel des missions spatiales avec visualisation 3D de trajectoires orbitales.</p>
                        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.5rem;">
                            <span style="background: rgba(123,47,255,0.1); border: 1px solid rgba(123,47,255,0.3); color: #9f47ff; padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">Three.js</span>
                            <span style="background: rgba(123,47,255,0.1); border: 1px solid rgba(123,47,255,0.3); color: #9f47ff; padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">Python</span>
                            <span style="background: rgba(123,47,255,0.1); border: 1px solid rgba(123,47,255,0.3); color: #9f47ff; padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">WebGL</span>
                            <span style="background: rgba(123,47,255,0.1); border: 1px solid rgba(123,47,255,0.3); color: #9f47ff; padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">AWS</span>
                        </div>
                        <a href="portfolio.php" class="btn btn-outline" style="width: 100%; text-align: center; display: block; padding: 0.6rem;">VOIR LE PROJET →</a>
                    </div>
                </div>

                <!-- Projet 3 -->
                <div class="portfolio-card-new fade-in" style="background: rgba(8,15,26,0.9); border: 1px solid rgba(0,255,255,0.12); border-radius: 12px; overflow: hidden; transition: transform 0.4s, box-shadow 0.4s;"
                     onmouseover="this.style.transform='translateY(-10px)'; this.style.boxShadow='0 20px 60px rgba(255,45,120,0.15)'"
                     onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                    <div style="position: relative; overflow: hidden; height: 200px; background: linear-gradient(135deg, #200010, #400020);">
                        <!-- Placeholder visible SEULEMENT si image absente -->
                        <div class="img-placeholder" style="position: absolute; inset: 0; 
                             display: flex; align-items: center; justify-content: center; 
                             font-family: 'Orbitron'; font-size: 3rem; 
                             color: rgba(255,45,120,0.2); z-index: 0;">◈</div>
                        
                        <!-- Image par dessus le placeholder, z-index plus haut -->
                        <img src="assets/images/projet3.jpg" alt="Quantum Fitness"
                             style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; 
                                    z-index: 1; transition: transform 0.5s;"
                             onmouseover="this.style.transform='scale(1.08)'"
                             onmouseout="this.style.transform='scale(1)'"
                             onerror="console.error('Image non trouvée: ' + this.src); this.style.display='none';">
                        
                        <!-- Badge catégorie z-index encore plus haut -->
                        <div style="position: absolute; top: 1rem; left: 1rem; z-index: 2;">
                            <span style="background: linear-gradient(135deg, #ff2d78, #ffcc00); color: #000; padding: 0.3rem 0.8rem; border-radius: 50px; font-size: 0.75rem; font-weight: 700;">MOBILE</span>
                        </div>
                    </div>
                    <div style="padding: 1.8rem;">
                        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.2rem;">
                            <div style="width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, #ff2d78, #ffcc00); display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-weight: 700; color: #000; font-size: 1.1rem; flex-shrink: 0;">Q</div>
                            <div>
                                <h3 style="font-family: 'Orbitron'; font-size: 1rem; margin: 0;">Quantum Fitness</h3>
                                <span style="color: var(--text-muted); font-size: 0.85rem;">Health & Tech</span>
                            </div>
                        </div>
                        <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6; margin-bottom: 1.5rem;">Application mobile de coaching IA personnalisé avec analyse biométrique en temps réel.</p>
                        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.5rem;">
                            <span style="background: rgba(255,45,120,0.1); border: 1px solid rgba(255,45,120,0.3); color: #ff2d78; padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">Flutter</span>
                            <span style="background: rgba(255,45,120,0.1); border: 1px solid rgba(255,45,120,0.3); color: #ff2d78; padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">TensorFlow</span>
                            <span style="background: rgba(255,45,120,0.1); border: 1px solid rgba(255,45,120,0.3); color: #ff2d78; padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">Firebase</span>
                            <span style="background: rgba(255,45,120,0.1); border: 1px solid rgba(255,45,120,0.3); color: #ff2d78; padding: 0.25rem 0.6rem; border-radius: 4px; font-size: 0.75rem; font-family: 'Share Tech Mono';">Swift</span>
                        </div>
                        <a href="portfolio.php" class="btn btn-outline" style="width: 100%; text-align: center; display: block; padding: 0.6rem;">VOIR LE PROJET →</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Bouton voir tout centré en bas -->
            <div style="text-align: center; margin-top: 3rem;">
                <a href="portfolio.php" class="btn btn-primary" style="font-size: 1.1rem; padding: 1rem 3rem; display: inline-flex; align-items: center; gap: 0.75rem;">
                    VOIR TOUT LE PORTFOLIO
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                </a>
            </div>
        </div>
    </section>

    <!-- TESTIMONIALS -->
    <section class="section" style="background: rgba(8,15,26,0.7);">
        <div class="container">
            <h2 class="section-title text-gradient" data-animate="reveal">ILS NOUS FONT CONFIANCE</h2>
            
            <div class="testimonials-slider" data-animate="stagger">
                <div class="slider-container">
                    <?php foreach($temoignages as $temoignage): ?>
                    <div class="testimonial-slide fade-in">
                        <div class="card" style="max-width: 600px; margin: 0 auto;">
                            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 2rem;">
                                <div style="width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--secondary)); display: flex; align-items: center; justify-content: center; font-weight: bold; color: #000;">
                                    <?= strtoupper(substr(htmlspecialchars($temoignage['client_nom']), 0, 2)) ?>
                                </div>
                                <div>
                                    <h4><?= htmlspecialchars($temoignage['client_nom']) ?></h4>
                                    <span style="color: var(--text-muted);"><?= htmlspecialchars($temoignage['client_entreprise']) ?></span>
                                </div>
                            </div>
                            <p style="font-style: italic; font-size: 1.1rem; margin-bottom: 1.5rem;">
                                <?= truncateText(htmlspecialchars($temoignage['contenu']), 200) ?>
                            </p>
                            <div style="color: var(--primary); font-size: 1.5rem; font-weight: bold;">★ <?= $temoignage['note'] ?>/5</div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <?php if(empty($temoignages)): ?>
                    <div class="testimonial-slide fade-in">
                        <div class="card" style="max-width: 600px; margin: 0 auto;">
                            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 2rem;">
                                <div style="width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--secondary)); display: flex; align-items: center; justify-content: center; font-weight: bold; color: #000;">JD</div>
                                <div>
                                    <h4>Jean Dupont</h4>
                                    <span style="color: var(--text-muted);">TechCorp</span>
                                </div>
                            </div>
                            <p style="font-style: italic; font-size: 1.1rem; margin-bottom: 1.5rem;">
                                "Nexus Digital a transformé notre présence digitale. Résultats exceptionnels !"
                            </p>
                            <div style="color: var(--primary); font-size: 1.5rem; font-weight: bold;">★ 5/5</div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="slider-nav">
                    <button class="slider-prev" style="background: none; border: none; color: var(--primary); font-size: 2rem; cursor: pointer;">‹</button>
                    <div class="slider-dots"></div>
                    <button class="slider-next" style="background: none; border: none; color: var(--primary); font-size: 2rem; cursor: pointer;">›</button>
                </div>
            </div>
        </div>
    </section>

    <!-- NEXUS INSIGHTS - DERNIERS ARTICLES BLOG -->
    <section class="section" style="background: rgba(8,15,26,0.3);">
        <div class="container">
            <h2 class="section-title text-gradient" data-animate="reveal">NEXUS INSIGHTS</h2>
            <p style="text-align: center; color: var(--text-muted); font-size: 1.1rem; margin-bottom: 4rem;">Tendances, conseils et cas d'études</p>
            
            <div class="grid grid-3" data-animate="stagger">
                <?php 
                if(!empty($articles)): 
                    foreach($articles as $article): 
                        $categorie_colors = [
                            'web' => 'linear-gradient(135deg, #00ffff, #00d4ff)',
                            'ia' => 'linear-gradient(135deg, #7b2fff, #9f47ff)',
                            'mobile' => 'linear-gradient(135deg, #ff2d78, #ff6b9d)',
                            'design' => 'linear-gradient(135deg, #00ff88, #00ffaa)',
                            'autre' => 'linear-gradient(135deg, #ffcc00, #ffdd33)'
                        ];
                        $gradient = $categorie_colors[$article['categorie']] ?? $categorie_colors['autre'];
                ?>
                <div class="card fade-in" style="overflow: hidden; transition: transform 0.3s, box-shadow 0.3s; border: 1px solid rgba(0,255,255,0.1);">
                    <div style="height: 8px; background: <?= $gradient ?>; margin-bottom: 1.5rem;"></div>
                    <span style="display: inline-block; background: <?= $gradient ?>; color: #000; padding: 0.4rem 0.8rem; border-radius: 50px; font-size: 0.75rem; font-weight: 600; margin-bottom: 1rem;">
                        <?= ucfirst(htmlspecialchars($article['categorie'])) ?>
                    </span>
                    <h3 style="font-size: 1.2rem; margin-bottom: 1rem; line-height: 1.4;">
                        <?= htmlspecialchars(substr($article['titre'], 0, 60)) ?>...
                    </h3>
                    <p style="color: var(--text-muted); margin-bottom: 1.5rem; line-height: 1.6;">
                        <?= htmlspecialchars(substr($article['extrait'], 0, 100)) ?>...
                    </p>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.9rem; color: var(--text-muted);">
                        <span><?= formatDateFr($article['created_at']) ?> • <?= $article['temps_lecture'] ?? 5 ?> min</span>
                    </div>
                    <a href="blog-details.php?id=<?= $article['id'] ?>" class="btn btn-primary" style="margin-top: 1.5rem; display: inline-block;">LIRE L'ARTICLE</a>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <!-- Articles fallback -->
                <div class="card fade-in" style="overflow: hidden; transition: transform 0.3s; border: 1px solid rgba(0,255,255,0.1);">
                    <div style="height: 8px; background: linear-gradient(135deg, #7b2fff, #9f47ff); margin-bottom: 1.5rem;"></div>
                    <span style="display: inline-block; background: linear-gradient(135deg, #7b2fff, #9f47ff); color: #000; padding: 0.4rem 0.8rem; border-radius: 50px; font-size: 0.75rem; font-weight: 600; margin-bottom: 1rem;">
                        IA
                    </span>
                    <h3 style="font-size: 1.2rem; margin-bottom: 1rem; line-height: 1.4;">
                        L'IA va-t-elle remplacer les développeurs ?
                    </h3>
                    <p style="color: var(--text-muted); margin-bottom: 1.5rem; line-height: 1.6;">
                        Analyse approfondie sur le rôle de l'intelligence artificielle dans le développement logiciel...
                    </p>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.9rem; color: var(--text-muted);">
                        <span>28 avril 2025 • 7 min</span>
                    </div>
                    <a href="blog.php" class="btn btn-primary" style="margin-top: 1.5rem; display: inline-block;">LIRE L'ARTICLE</a>
                </div>

                <div class="card fade-in" style="overflow: hidden; transition: transform 0.3s; border: 1px solid rgba(0,255,255,0.1);">
                    <div style="height: 8px; background: linear-gradient(135deg, #00ffff, #00d4ff); margin-bottom: 1.5rem;"></div>
                    <span style="display: inline-block; background: linear-gradient(135deg, #00ffff, #00d4ff); color: #000; padding: 0.4rem 0.8rem; border-radius: 50px; font-size: 0.75rem; font-weight: 600; margin-bottom: 1rem;">
                        WEB
                    </span>
                    <h3 style="font-size: 1.2rem; margin-bottom: 1rem; line-height: 1.4;">
                        Three.js vs WebGL : lequel choisir ?
                    </h3>
                    <p style="color: var(--text-muted); margin-bottom: 1.5rem; line-height: 1.6;">
                        Comparaison complète pour vous aider à choisir la meilleure technologie 3D web...
                    </p>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.9rem; color: var(--text-muted);">
                        <span>15 avril 2025 • 5 min</span>
                    </div>
                    <a href="blog.php" class="btn btn-primary" style="margin-top: 1.5rem; display: inline-block;">LIRE L'ARTICLE</a>
                </div>

                <div class="card fade-in" style="overflow: hidden; transition: transform 0.3s; border: 1px solid rgba(0,255,255,0.1);">
                    <div style="height: 8px; background: linear-gradient(135deg, #ff2d78, #ff6b9d); margin-bottom: 1.5rem;"></div>
                    <span style="display: inline-block; background: linear-gradient(135deg, #ff2d78, #ff6b9d); color: #000; padding: 0.4rem 0.8rem; border-radius: 50px; font-size: 0.75rem; font-weight: 600; margin-bottom: 1rem;">
                        CASE STUDY
                    </span>
                    <h3 style="font-size: 1.2rem; margin-bottom: 1rem; line-height: 1.4;">
                        Comment nous avons boosté le CA de TechCorp de 300%
                    </h3>
                    <p style="color: var(--text-muted); margin-bottom: 1.5rem; line-height: 1.6;">
                        Découvrez la stratégie digitale qui a transformé une PME en leader du secteur...
                    </p>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.9rem; color: var(--text-muted);">
                        <span>02 avril 2025 • 8 min</span>
                    </div>
                    <a href="blog.php" class="btn btn-primary" style="margin-top: 1.5rem; display: inline-block;">LIRE L'ARTICLE</a>
                </div>
                <?php endif; ?>
            </div>

            <div style="text-align: center; margin-top: 3rem;">
                <a href="blog.php" class="btn btn-outline" style="font-size: 1rem; padding: 0.75rem 2rem;">VOIR TOUS LES ARTICLES</a>
            </div>
        </div>
    </section>

    <!-- CTA FINAL -->
    <section class="section" style="background: var(--bg-deep); position: relative; overflow: hidden;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; position: relative; z-index: 1;">
            <!-- Gauche -->
            <div class="container" style="max-width: none;">
                <h2 style="font-family: 'Orbitron'; font-size: 2.5rem; line-height: 1.3; margin-bottom: 1rem; color: var(--primary);">
                    TRANSFORMONS VOTRE VISION EN RÉALITÉ
                </h2>
                <p style="font-size: 1.2rem; color: var(--text-muted); margin-bottom: 2rem; line-height: 1.6;">
                    Prêt à bâtir quelque chose d'extraordinaire ? Parlons de votre prochain grand projet.
                </p>
                
                <div style="margin-bottom: 2rem;">
                    <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00ffff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                        <span>Délais respectés et livrables prédéfinis</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00ffff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                        <span>Budget maîtrisé et clairement défini</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 1rem;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00ffff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                        <span>Qualité premium garantie ou remboursement</span>
                    </div>
                </div>

                <div style="display: flex; gap: 1.5rem; flex-wrap: wrap;">
                    <a href="contact.php" class="btn btn-primary" style="font-size: 1.1rem; padding: 1rem 2.5rem;">DÉMARRER UN PROJET</a>
                    <a href="pricing.php" class="btn btn-outline" style="font-size: 1.1rem; padding: 1rem 2.5rem;">VOIR NOS TARIFS</a>
                </div>
            </div>

            <!-- Droite - Formulaire -->
            <div class="container" style="max-width: none;">
                <div style="background: rgba(0,255,255,0.08); backdrop-filter: blur(10px); border: 1px solid rgba(0,255,255,0.2); border-radius: 8px; padding: 2.5rem; box-shadow: 0 8px 32px rgba(0,0,0,0.3);">
                    <h3 style="font-family: 'Orbitron'; font-size: 1.3rem; margin-bottom: 1.5rem; color: var(--primary);">CONTACT RAPIDE</h3>
                    
                    <form id="quick-contact-form" style="display: flex; flex-direction: column; gap: 1.2rem;">
                        <div>
                            <input type="text" name="name" placeholder="Votre nom" required style="width: 100%; padding: 0.75rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(0,255,255,0.2); border-radius: 4px; color: var(--text); font-family: 'Share Tech Mono';" />
                        </div>
                        
                        <div>
                            <input type="email" name="email" placeholder="Votre email" required style="width: 100%; padding: 0.75rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(0,255,255,0.2); border-radius: 4px; color: var(--text); font-family: 'Share Tech Mono';" />
                        </div>
                        
                        <div>
                            <select name="service" style="width: 100%; padding: 0.75rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(0,255,255,0.2); border-radius: 4px; color: var(--text); font-family: 'Share Tech Mono';">
                                <option value="">Sélectionnez un service</option>
                                <option value="web">Web Futuriste</option>
                                <option value="mobile">Mobile Natif</option>
                                <option value="ia">Intelligence Artificielle</option>
                                <option value="design">Design UX/UI</option>
                                <option value="autre">Autre projet</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" style="font-size: 1.1rem; padding: 0.85rem;">DISCUTONS DE VOTRE PROJET</button>
                    </form>

                    <div id="form-success" style="display: none; margin-top: 1rem; padding: 1rem; background: rgba(0,255,136,0.2); border: 1px solid #00ff88; border-radius: 4px; color: #00ff88; text-align: center;">
                        ✓ Message envoyé avec succès ! Nous vous recontacterons bientôt.
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Grille lignes infinie -->
        <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; overflow: hidden; z-index: 0; perspective: 1px; perspective-origin: 50% calc(50% + 100px);">
            <div style="position: absolute; width: 200%; height: 200%; background-image: 
                linear-gradient(90deg, transparent 49%, rgba(0,255,255,0.03) 50%),
                linear-gradient(0deg, transparent 49%, rgba(0,255,255,0.03) 50%);
                background-size: 40px 40px;
                animation: gridMove 20s linear infinite;"></div>
        </div>
    </section>

<?php require_once 'includes/footer.php'; ?>

 </body>
 </html>
