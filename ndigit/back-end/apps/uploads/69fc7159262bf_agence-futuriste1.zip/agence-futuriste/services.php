<?php 
require_once 'includes/header.php'; 
require_once 'config/db.php'; 
require_once 'includes/functions.php';

try {
    $services = $pdo->query("SELECT * FROM services ORDER BY ordre")->fetchAll();
} catch(PDOException $e) {
    $services = [];
}

// Données de fallback si DB vide
if(empty($services)) {
    $services = [
        [
            'nom' => 'Web Premium',
            'slug' => 'web-premium',
            'description_courte' => 'Sites et apps web next-gen avec WebGL, Three.js et animations avancées',
            'description_longue' => 'Nous créons des expériences web qui transcendent les limites du navigateur. Sites vitrines ultra-modernes, e-commerce révolutionnaires, plateformes complexes — tous propulsés par les dernières technologies frontend.',
            'features' => json_encode(['React 19 & Next.js', 'Three.js / WebGL', 'Animations fluides', 'Web Components', 'Progressive Web Apps', 'Performance 100/100'])
        ],
        [
            'nom' => 'Applications Mobiles',
            'slug' => 'mobile-apps',
            'description_courte' => 'Apps iOS/Android natives et cross-platform haute performance',
            'description_longue' => 'Développement mobile professionnel. Flutter pour cross-platform optimal, développement natif iOS/Android quand performance critique. API robustes, offline-first, push notifications, intégrations bancaires.',
            'features' => json_encode(['Flutter / Native iOS', 'Android Kotlin', 'Offline functionality', 'Real-time sync', 'Payment gateways', 'App Store optimization'])
        ],
        [
            'nom' => 'IA & Machine Learning',
            'slug' => 'ia-ml',
            'description_courte' => 'Modèles IA générative, Computer Vision, NLP & RAG deployment',
            'description_longue' => 'Division IA dédiée. GPT-4 fine-tuning, Computer Vision (reconnaissance faciale, détection d\'objets), NLP avancé. Chatbots intelligents, recommandation systèmes, prédictions temps réel.',
            'features' => json_encode(['GPT-4 / Claude API', 'Computer Vision', 'NLP / LLM', 'RAG pipelines', 'Fine-tuning models', 'Inference optimization'])
        ],
        [
            'nom' => 'Design & UX',
            'slug' => 'design-ux',
            'description_courte' => 'Conception digitale systématique et testing utilisateur continu',
            'description_longue' => 'Au-delà des jolis pixels. Recherche utilisateur approfondie, design systems documentés, prototypage interactif, A/B testing scientifique. Chaque écran augmente conversion.',
            'features' => json_encode(['User Research', 'Design Systems', 'Interactive Prototypes', 'A/B Testing', 'Accessibility (WCAG)', 'User Testing (10K+ users)'])
        ],
        [
            'nom' => 'Cybersécurité Cloud',
            'slug' => 'cybersecurity-cloud',
            'description_courte' => 'Infrastructure sécurisée, ISO 27001, Zero Trust architecture',
            'description_longue' => 'Hébergement sur AWS/GCP, infrastructure as code, monitoring 24/7. Conformité RGPD/ISO 27001, audits de sécurité réguliers, backups automatiques, disaster recovery plan initié.',
            'features' => json_encode(['AWS / GCP', 'Zero Trust Model', 'Kubernetes', 'CI/CD DevOps', 'Security audits', 'RGPD compliance'])
        ],
        [
            'nom' => 'Web3 & Metaverse',
            'slug' => 'web3-metaverse',
            'description_courte' => 'Smart contracts, NFT, DeFi, expériences immersives VR/AR',
            'description_longue' => 'Blockchain native. Smart contracts audités (Solidity), NFT marketplace, tokens, liquidity pools. Expériences Metaverse — monde virtuel 3D, avatars, économies virtuelles.',
            'features' => json_encode(['Solidity contracts', 'NFT / Tokenomics', 'DeFi protocols', 'AR/VR experiences', 'Metaverse worlds', 'Wallet integration'])
        ]
    ];
}

$page_script = 'assets/js/services.js';
?>

<main>
    <!-- HERO -->
    <section class="hero" style="padding-top: 120px;">
        <canvas id="services-hero-canvas" class="hero-canvas" data-wireframe-hero="polyhedra"></canvas>
        <div class="hero-content container" style="position: relative; z-index: 2;">
            <h1 class="hero-title" style="color: #FFFFFF;">NOS SERVICES</h1>
            <p class="hero-subtitle" style="font-size: 1.3rem;">6 domaines d'expertise pour transformer votre vision en réalité digitale</p>
        </div>
    </section>

    <!-- SERVICES GRID 2 COLONNES -->
    <section class="section">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 2.5rem; margin-bottom: 3rem;">
                
                <!-- Web Premium -->
                <div class="glass" style="padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(0,255,255,0.2); transition: all 0.3s; cursor: pointer;" onmouseover="this.style.borderColor='#00FFFF'; this.style.boxShadow='0 0 30px rgba(0,255,255,0.2)'" onmouseout="this.style.borderColor='rgba(0,255,255,0.2)'; this.style.boxShadow=''">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #00FFFF, #7B2FFF); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem; font-size: 2rem; font-weight: 900; color: #000;">WEB</div>
                    <h3 style="color: #00FFFF; margin-bottom: 1rem; font-family: 'Orbitron';">Web Premium</h3>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;">Sites et applications web next-gen avec WebGL, Three.js et animations avancées. Nous créons des expériences web qui transcendent les limites du navigateur.</p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem;">
                        <div style="background: rgba(0,255,255,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #00FFFF;">React 19 & Next.js</div>
                        <div style="background: rgba(0,255,255,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #00FFFF;">Three.js / WebGL</div>
                        <div style="background: rgba(0,255,255,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #00FFFF;">Animations fluides</div>
                        <div style="background: rgba(0,255,255,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #00FFFF;">PWA</div>
                    </div>
                </div>

                <!-- Mobile Apps -->
                <div class="glass" style="padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(123,47,255,0.2); transition: all 0.3s; cursor: pointer;" onmouseover="this.style.borderColor='#7B2FFF'; this.style.boxShadow='0 0 30px rgba(123,47,255,0.2)'" onmouseout="this.style.borderColor='rgba(123,47,255,0.2)'; this.style.boxShadow=''">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #7B2FFF, #FF2D78); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem; font-size: 2rem; font-weight: 900; color: #fff;">📱</div>
                    <h3 style="color: #7B2FFF; margin-bottom: 1rem; font-family: 'Orbitron';">Applications Mobiles</h3>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;">Apps iOS/Android natives et cross-platform haute performance. Flutter pour cross-platform optimal, développement natif quand performance critique.</p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem;">
                        <div style="background: rgba(123,47,255,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #7B2FFF;">Flutter / Native</div>
                        <div style="background: rgba(123,47,255,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #7B2FFF;">Offline-first</div>
                        <div style="background: rgba(123,47,255,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #7B2FFF;">Real-time sync</div>
                        <div style="background: rgba(123,47,255,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #7B2FFF;">Payments</div>
                    </div>
                </div>

                <!-- IA & ML -->
                <div class="glass" style="padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(255,45,120,0.2); transition: all 0.3s; cursor: pointer;" onmouseover="this.style.borderColor='#FF2D78'; this.style.boxShadow='0 0 30px rgba(255,45,120,0.2)'" onmouseout="this.style.borderColor='rgba(255,45,120,0.2)'; this.style.boxShadow=''">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #FF2D78, #00FF88); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem; font-size: 2rem; font-weight: 900; color: #000;">🧠</div>
                    <h3 style="color: #FF2D78; margin-bottom: 1rem; font-family: 'Orbitron';">IA & Machine Learning</h3>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;">Modèles IA générative, Computer Vision, NLP & RAG deployment. Chatbots intelligents, recommandation systèmes, prédictions temps réel.</p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem;">
                        <div style="background: rgba(255,45,120,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #FF2D78;">GPT-4 / Claude</div>
                        <div style="background: rgba(255,45,120,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #FF2D78;">Computer Vision</div>
                        <div style="background: rgba(255,45,120,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #FF2D78;">NLP / LLM</div>
                        <div style="background: rgba(255,45,120,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #FF2D78;">RAG pipelines</div>
                    </div>
                </div>

                <!-- Design & UX -->
                <div class="glass" style="padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(0,255,136,0.2); transition: all 0.3s; cursor: pointer;" onmouseover="this.style.borderColor='#00FF88'; this.style.boxShadow='0 0 30px rgba(0,255,136,0.2)'" onmouseout="this.style.borderColor='rgba(0,255,136,0.2)'; this.style.boxShadow=''">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #00FF88, #FFCC00); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem; font-size: 2rem; font-weight: 900; color: #000;">🎨</div>
                    <h3 style="color: #00FF88; margin-bottom: 1rem; font-family: 'Orbitron';">Design & UX</h3>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;">Conception digitale systématique et testing utilisateur continu. Recherche approfondie, design systems documentés, A/B testing scientifique.</p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem;">
                        <div style="background: rgba(0,255,136,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #00FF88;">User Research</div>
                        <div style="background: rgba(0,255,136,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #00FF88;">Design Systems</div>
                        <div style="background: rgba(0,255,136,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #00FF88;">A/B Testing</div>
                        <div style="background: rgba(0,255,136,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #00FF88;">WCAG</div>
                    </div>
                </div>

                <!-- Cybersécurité Cloud -->
                <div class="glass" style="padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(255,170,0,0.2); transition: all 0.3s; cursor: pointer;" onmouseover="this.style.borderColor='#FFA800'; this.style.boxShadow='0 0 30px rgba(255,170,0,0.2)'" onmouseout="this.style.borderColor='rgba(255,170,0,0.2)'; this.style.boxShadow=''">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #FFA800, #FF6B35); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem; font-size: 2rem; font-weight: 900; color: #000;">🔐</div>
                    <h3 style="color: #FFA800; margin-bottom: 1rem; font-family: 'Orbitron';">Cybersécurité Cloud</h3>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;">Infrastructure sécurisée, ISO 27001, Zero Trust architecture. Monitoring 24/7, conformité RGPD, audits réguliers, disaster recovery plan.</p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem;">
                        <div style="background: rgba(255,170,0,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #FFA800;">AWS / GCP</div>
                        <div style="background: rgba(255,170,0,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #FFA800;">Zero Trust</div>
                        <div style="background: rgba(255,170,0,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #FFA800;">Kubernetes</div>
                        <div style="background: rgba(255,170,0,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #FFA800;">RGPD</div>
                    </div>
                </div>

                <!-- Web3 & Metaverse -->
                <div class="glass" style="padding: 2.5rem; border-radius: 12px; border: 1px solid rgba(100,149,237,0.2); transition: all 0.3s; cursor: pointer;" onmouseover="this.style.borderColor='#6495ED'; this.style.boxShadow='0 0 30px rgba(100,149,255,0.2)'" onmouseout="this.style.borderColor='rgba(100,149,237,0.2)'; this.style.boxShadow=''">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #6495ED, #00FFFF); border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem; font-size: 2rem; font-weight: 900; color: #fff;">🌐</div>
                    <h3 style="color: #6495ED; margin-bottom: 1rem; font-family: 'Orbitron';">Web3 & Metaverse</h3>
                    <p style="color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;">Smart contracts, NFT, DeFi, expériences immersives VR/AR. Blockchain native, NFT marketplace, tokens, mondes virtuels 3D.</p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem;">
                        <div style="background: rgba(100,149,237,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #6495ED;">Solidity</div>
                        <div style="background: rgba(100,149,237,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #6495ED;">NFT / Tokens</div>
                        <div style="background: rgba(100,149,237,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #6495ED;">AR/VR</div>
                        <div style="background: rgba(100,149,237,0.1); padding: 0.75rem; border-radius: 6px; border-left: 3px solid #6495ED;">DeFi</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION COMPARAISON -->
    <section class="section" style="background: rgba(123,47,255,0.05);">
        <div class="container">
            <h2 class="section-title text-gradient" style="text-align: center; margin-bottom: 3rem;">FUTURISTE VS AGENCES CLASSIQUES</h2>
            
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="border-bottom: 2px solid rgba(0,255,255,0.2);">
                            <th style="text-align: left; padding: 1.5rem; color: #FFFFFF; font-family: 'Orbitron';">CRITÈRE</th>
                            <th style="text-align: center; padding: 1.5rem; color: #00FFFF; font-family: 'Orbitron'; border-left: 1px solid rgba(0,255,255,0.1);">FUTURISTE</th>
                            <th style="text-align: center; padding: 1.5rem; color: var(--text-muted); font-family: 'Orbitron'; border-left: 1px solid rgba(100,100,100,0.1);">AGENCES CLASSIQUES</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="border-bottom: 1px solid rgba(0,255,255,0.1);">
                            <td style="padding: 1.5rem;">Technologies</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(0,255,255,0.1); color: #00FF88;">✓ Latest versioning</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(100,100,100,0.1); color: var(--text-muted);">Outdated stacks</td>
                        </tr>
                        <tr style="border-bottom: 1px solid rgba(0,255,255,0.1);">
                            <td style="padding: 1.5rem;">Performance</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(0,255,255,0.1); color: #00FF88;">✓ 100/100 Lighthouse</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(100,100,100,0.1); color: var(--text-muted);">60-75/100</td>
                        </tr>
                        <tr style="border-bottom: 1px solid rgba(0,255,255,0.1);">
                            <td style="padding: 1.5rem;">IA Integration</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(0,255,255,0.1); color: #00FF88;">✓ Native AI studio</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(100,100,100,0.1); color: var(--text-muted);">No capability</td>
                        </tr>
                        <tr style="border-bottom: 1px solid rgba(0,255,255,0.1);">
                            <td style="padding: 1.5rem;">3D Experiences</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(0,255,255,0.1); color: #00FF88;">✓ WebGL / Three.js</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(100,100,100,0.1); color: var(--text-muted);">Basic CSS only</td>
                        </tr>
                        <tr style="border-bottom: 1px solid rgba(0,255,255,0.1);">
                            <td style="padding: 1.5rem;">Web3 Support</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(0,255,255,0.1); color: #00FF88;">✓ Smart contracts</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(100,100,100,0.1); color: var(--text-muted);">None</td>
                        </tr>
                        <tr>
                            <td style="padding: 1.5rem;">Innovation Culture</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(0,255,255,0.1); color: #00FF88;">✓ R&D budget 20%</td>
                            <td style="text-align: center; padding: 1.5rem; border-left: 1px solid rgba(100,100,100,0.1); color: var(--text-muted);">Reactive only</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <!-- PROCESSUS -->
    <section class="section">
        <div class="container">
            <h2 class="section-title text-gradient" style="text-align: center; margin-bottom: 3rem;">NOTRE PROCESSUS</h2>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; position: relative;">
                
                <!-- Ligne de connexion -->
                <svg style="position: absolute; top: 40px; left: 10%; right: 10%; height: 4px; pointer-events: none;">
                    <line x1="0" y1="0" x2="100%" y2="0" stroke="url(#processGradient)" stroke-width="3"/>
                    <defs>
                        <linearGradient id="processGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stop-color="#00FFFF"/>
                            <stop offset="50%" stop-color="#7B2FFF"/>
                            <stop offset="100%" stop-color="#FF2D78"/>
                        </linearGradient>
                    </defs>
                </svg>

                <!-- ÉTAPE 01 -->
                <div style="flex: 1; text-align: center; position: relative;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #00FFFF, #7B2FFF); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-size: 1.8rem; font-weight: 900; color: #fff; margin: 0 auto 1rem; box-shadow: 0 0 30px rgba(0,255,255,0.4); position: relative; z-index: 2; background: linear-gradient(135deg, #00FFFF, #7B2FFF);">01</div>
                    <h4 style="font-weight: 700; color: #00FFFF; margin-bottom: 0.5rem;">DÉCOUVERTE</h4>
                    <p style="color: var(--text-muted); font-size: 0.95rem;">Audit complet de vos besoins business, concurrence, marché</p>
                </div>

                <!-- ÉTAPE 02 -->
                <div style="flex: 1; text-align: center; position: relative;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #7B2FFF, #FF2D78); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-size: 1.8rem; font-weight: 900; color: #fff; margin: 0 auto 1rem; box-shadow: 0 0 30px rgba(123,47,255,0.4); position: relative; z-index: 2;">02</div>
                    <h4 style="font-weight: 700; color: #7B2FFF; margin-bottom: 0.5rem;">STRATÉGIE</h4>
                    <p style="color: var(--text-muted); font-size: 0.95rem;">Plan détaillé avec architecture, timeline, ressources</p>
                </div>

                <!-- ÉTAPE 03 -->
                <div style="flex: 1; text-align: center; position: relative;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #FF2D78, #00FF88); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-size: 1.8rem; font-weight: 900; color: #000; margin: 0 auto 1rem; box-shadow: 0 0 30px rgba(255,45,120,0.4); position: relative; z-index: 2;">03</div>
                    <h4 style="font-weight: 700; color: #FF2D78; margin-bottom: 0.5rem;">DESIGN</h4>
                    <p style="color: var(--text-muted); font-size: 0.95rem;">UX/UI, prototypes 3D, moodboards, user flows</p>
                </div>

                <!-- ÉTAPE 04 -->
                <div style="flex: 1; text-align: center; position: relative;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #00FF88, #FFCC00); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-size: 1.8rem; font-weight: 900; color: #000; margin: 0 auto 1rem; box-shadow: 0 0 30px rgba(0,255,136,0.4); position: relative; z-index: 2;">04</div>
                    <h4 style="font-weight: 700; color: #00FF88; margin-bottom: 0.5rem;">DÉVELOPPEMENT</h4>
                    <p style="color: var(--text-muted); font-size: 0.95rem;">Code production, intégrations, tests automatisés</p>
                </div>

                <!-- ÉTAPE 05 -->
                <div style="flex: 1; text-align: center; position: relative;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #FFCC00, #FF6B35); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: 'Orbitron'; font-size: 1.8rem; font-weight: 900; color: #000; margin: 0 auto 1rem; box-shadow: 0 0 30px rgba(255,204,0,0.4); position: relative; z-index: 2;">05</div>
                    <h4 style="font-weight: 700; color: #FFCC00; margin-bottom: 0.5rem;">LIVRAISON</h4>
                    <p style="color: var(--text-muted); font-size: 0.95rem;">Production, formation équipe, monitoring 24/7</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA BOTTOM -->
    <section class="section" style="background: linear-gradient(135deg, rgba(0,255,255,0.1), rgba(123,47,255,0.1));">
        <div class="container" style="text-align: center;">
            <h2 style="font-size: 2rem; margin-bottom: 1.5rem;">Prêt pour un devis ou une consultation?</h2>
            <p style="color: var(--text-muted); margin-bottom: 2rem; font-size: 1.1rem;">Parlons de vos ambitions digitales lors d'une session gratuite de 30min</p>
            <a href="contact.php" class="btn btn-primary" style="display: inline-block; padding: 1rem 3rem; font-size: 1.1rem;">RÉSERVER UN APPEL</a>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
