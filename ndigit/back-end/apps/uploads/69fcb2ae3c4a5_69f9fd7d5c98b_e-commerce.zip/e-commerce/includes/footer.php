    <!-- Footer -->
    <footer class="bg-foreground text-background/80 mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-12">
                <div class="md:col-span-1">
                    <span class="font-serif text-2xl font-bold tracking-widest text-white block mb-4">MAISON</span>
                    <p class="text-sm leading-relaxed text-background/60 mb-6">
                        Curated luxury for the modern wardrobe. Timeless pieces, exceptional quality.
                    </p>
                    <div class="flex gap-4">
                        <a href="#" class="text-background/50 hover:text-white transition-colors" data-testid="link-instagram">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
                        </a>
                        <a href="#" class="text-background/50 hover:text-white transition-colors" data-testid="link-twitter">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 4s-7 0-10 6-4 8-4 8 3-1 6-4 6-7 6-7Z"/><path d="M2 20h5"/><path d="M9 20h6"/><path d="M14 20h5"/></svg>
                        </a>
                        <a href="#" class="text-background/50 hover:text-white transition-colors" data-testid="link-youtube">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 17c0-6 0-9 .5-11.5a3 3 0 0 1 2-2C7.5 3 12 3 12 3s4.5 0 7 .5a3 3 0 0 1 2 2c.5 2.5.5 5.5.5 11.5s0 9-.5 11.5a3 3 0 0 1-2 2c-2.5.5-7 .5-7 .5s-4.5 0-7-.5a3 3 0 0 1-2-2C2.5 23 2.5 20 2.5 17Z"/><polygon points="10 15 15 12 10 9"/></svg>
                        </a>
                        <a href="#" class="text-background/50 hover:text-white transition-colors" data-testid="link-email">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                        </a>
                    </div>
                </div>

                <div>
                    <h4 class="text-white font-semibold text-sm tracking-widest uppercase mb-4">Shop</h4>
                    <ul class="space-y-2">
                        <?php foreach (['New Arrivals', 'Dresses', 'Tops', 'Jackets', 'Shoes', 'Accessories', 'Sale'] as $item): ?>
                        <li>
                            <a href="/shop.php" class="text-sm text-background/60 hover:text-white transition-colors"><?php echo e($item); ?></a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div>
                    <h4 class="text-white font-semibold text-sm tracking-widest uppercase mb-4">Help</h4>
                    <ul class="space-y-2">
                        <?php foreach (['Contact Us', 'Shipping & Returns', 'Size Guide', 'Care Instructions', 'FAQ', 'Track Your Order'] as $item): ?>
                        <li>
                            <a href="/contact.php" class="text-sm text-background/60 hover:text-white transition-colors"><?php echo e($item); ?></a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div>
                    <h4 class="text-white font-semibold text-sm tracking-widest uppercase mb-4">Newsletter</h4>
                    <p class="text-sm text-background/60 mb-4">Be the first to discover new arrivals and exclusive offers.</p>
                    <div class="flex gap-2">
                        <input type="email" 
                               placeholder="Your email" 
                               class="flex-1 bg-white/10 border border-white/20 rounded-md px-3 py-2 text-sm text-white placeholder-background/40 outline-none focus:border-primary"
                               data-testid="input-newsletter-email">
                        <button class="bg-primary text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors" data-testid="button-newsletter-subscribe">
                            Join
                        </button>
                    </div>
                </div>
            </div>

            <div class="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
                <p class="text-xs text-background/40">© 2026 MAISON. All rights reserved.</p>
                <div class="flex gap-6">
                    <a href="#" class="text-xs text-background/40 hover:text-background/70 transition-colors">Privacy Policy</a>
                    <a href="#" class="text-xs text-background/40 hover:text-background/70 transition-colors">Terms of Service</a>
                    <a href="#" class="text-xs text-background/40 hover:text-background/70 transition-colors">Cookie Policy</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Quick View Modal -->
    <div id="quickview-modal" class="fixed inset-0 z-50 hidden" style="display: none;">
        <div class="absolute inset-0 bg-black/60" onclick="closeQuickView()"></div>
        <div class="absolute inset-4 md:inset-10 bg-white rounded-lg overflow-hidden flex flex-col md:flex-row max-w-6xl mx-auto my-auto" style="max-height: 90vh;">
            <button onclick="closeQuickView()" class="absolute top-4 right-4 z-10 w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
            
            <div class="w-full md:w-1/2 bg-muted overflow-y-auto">
                <img id="qv-image" src="" alt="" class="w-full h-full object-cover">
            </div>
            
            <div class="w-full md:w-1/2 p-6 md:p-10 overflow-y-auto">
                <p id="qv-category" class="text-xs text-muted-foreground tracking-widest uppercase mb-2"></p>
                <h2 id="qv-name" class="font-serif text-3xl md:text-4xl font-bold mb-4"></h2>
                
                <div class="flex items-center gap-2 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="fill-accent text-accent"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <span id="qv-rating" class="font-medium"></span>
                    <span id="qv-reviews" class="text-muted-foreground"></span>
                </div>

                <div class="flex items-baseline gap-3 mb-6">
                    <span id="qv-price" class="font-serif text-3xl font-bold"></span>
                    <span id="qv-original-price" class="text-xl text-muted-foreground line-through hidden"></span>
                </div>

                <p id="qv-description" class="text-muted-foreground leading-relaxed mb-6"></p>

                <div id="qv-stock" class="hidden mb-4">
                    <p class="text-destructive font-semibold text-sm"></p>
                </div>

                <div class="mb-6">
                    <h3 class="font-semibold text-sm mb-3">Color</h3>
                    <div id="qv-colors" class="flex gap-3"></div>
                </div>

                <div class="mb-6">
                    <h3 class="font-semibold text-sm mb-3">Size</h3>
                    <div id="qv-sizes" class="flex flex-wrap gap-3"></div>
                </div>

                <div class="flex gap-3 pt-4">
                    <button id="qv-add-cart" class="flex-1 h-14 bg-primary text-white font-semibold tracking-wider hover:bg-primary/90 rounded-md flex items-center justify-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                        Add to Cart
                    </button>
                    <button id="qv-wishlist" class="w-14 h-14 border border-border rounded-md flex items-center justify-center hover:border-primary transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                    </button>
                </div>

                <a id="qv-full-details" href="#" class="block mt-4 text-primary text-sm font-medium hover:underline">
                    View Full Details →
                </a>
            </div>
        </div>
    </div>

    <script>
    // Product data for quick view
    const allProducts = <?php echo json_encode($products); ?>;
    const wishlistItems = <?php echo json_encode($wishlist_items); ?>;
    let selectedSize = null;

    function showQuickView(productId) {
        const product = allProducts.find(p => p.id === productId);
        if (!product) return;

        document.getElementById('qv-image').src = product.images[0];
        document.getElementById('qv-image').alt = product.name;
        document.getElementById('qv-category').textContent = product.category;
        document.getElementById('qv-name').textContent = product.name;
        document.getElementById('qv-rating').textContent = product.rating;
        document.getElementById('qv-reviews').textContent = `(${product.reviews} reviews)`;
        document.getElementById('qv-price').textContent = formatPrice(product.price);
        document.getElementById('qv-description').textContent = product.description;

        const originalPrice = document.getElementById('qv-original-price');
        if (product.originalPrice) {
            originalPrice.textContent = formatPrice(product.originalPrice);
            originalPrice.classList.remove('hidden');
        } else {
            originalPrice.classList.add('hidden');
        }

        const stockDiv = document.getElementById('qv-stock');
        if (product.stock <= 3) {
            stockDiv.classList.remove('hidden');
            stockDiv.querySelector('p').textContent = `⚠️ Only ${product.stock} left in stock!`;
        } else {
            stockDiv.classList.add('hidden');
        }

        const colorsDiv = document.getElementById('qv-colors');
        colorsDiv.innerHTML = product.colors.map(color => 
            `<button class="w-10 h-10 rounded-full border-2 border-border hover:border-primary transition-colors" style="background-color: ${color.value}" title="${color.name}"></button>`
        ).join('');

        const sizesDiv = document.getElementById('qv-sizes');
        selectedSize = product.sizes[0];
        sizesDiv.innerHTML = product.sizes.map((size, i) => 
            `<button class="size-btn min-w-[60px] px-4 py-3 border border-border rounded-md text-sm font-medium hover:border-primary transition-colors ${i === 0 ? 'bg-primary text-white' : ''}" 
                     onclick="selectSize(this, '${size}')">${size}</button>`
        ).join('');

        const inWishlist = wishlistItems.includes(productId);
        const wishlistBtn = document.getElementById('qv-wishlist');
        if (inWishlist) {
            wishlistBtn.classList.add('bg-primary', 'text-white');
            wishlistBtn.querySelector('svg').setAttribute('fill', 'currentColor');
        } else {
            wishlistBtn.classList.remove('bg-primary', 'text-white');
            wishlistBtn.querySelector('svg').setAttribute('fill', 'none');
        }
        wishlistBtn.onclick = () => toggleWishlist(productId, product.name);

        document.getElementById('qv-add-cart').onclick = () => {
            addToCart(productId, product.name, product.price, product.images[0], selectedSize || product.sizes[0], '');
        };

        document.getElementById('qv-full-details').href = `/e-commerce/product.php?id=${productId}`;

        const modal = document.getElementById('quickview-modal');
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }

    function closeQuickView() {
        const modal = document.getElementById('quickview-modal');
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    function selectSize(btn, size) {
        document.querySelectorAll('#qv-sizes .size-btn').forEach(b => {
            b.classList.remove('bg-primary', 'text-white');
        });
        btn.classList.add('bg-primary', 'text-white');
        selectedSize = size;
    }

    function formatPrice(price) {
        return '$' + price.toLocaleString();
    }

    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeQuickView();
            const mobileMenu = document.getElementById('mobile-menu');
            if (mobileMenu.style.display === 'block') {
                toggleMobileMenu();
            }
            const cartDrawer = document.getElementById('cart-drawer');
            if (cartDrawer.style.display === 'block') {
                toggleCart();
            }
        }
    });
    </script>

    <script>
    // Toggle mobile menu
    function toggleMobileMenu() {
        const menu = document.getElementById('mobile-menu');
        const content = document.getElementById('mobile-menu-content');
        
        if (menu.style.display === 'none' || menu.style.display === '') {
            menu.style.display = 'block';
            setTimeout(() => {
                content.style.transform = 'translateX(0)';
            }, 10);
        } else {
            content.style.transform = 'translateX(-100%)';
            setTimeout(() => {
                menu.style.display = 'none';
            }, 300);
        }
    }

    // Toggle search
    function toggleSearch() {
        const searchBar = document.getElementById('search-bar');
        if (searchBar) {
            searchBar.classList.toggle('hidden');
        }
    }

    // Toggle cart
    function toggleCart() {
        const drawer = document.getElementById('cart-drawer');
        const content = document.getElementById('cart-drawer-content');
        
        if (drawer.style.display === 'none' || drawer.style.display === '') {
            drawer.style.display = 'block';
            setTimeout(() => {
                content.style.transform = 'translateX(0)';
            }, 10);
        } else {
            content.style.transform = 'translateX(100%)';
            setTimeout(() => {
                drawer.style.display = 'none';
            }, 300);
        }
    }

    // Cart functions
    function addToCart(productId, name, price, image, size, color) {
        fetch('/e-commerce/api/cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'add', id: productId, name, price, image, size, color, quantity: 1 })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Added to cart ✓', `1x ${name} added to your bag.`);
                location.reload();
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function updateCartQuantity(id, size, color, quantity) {
        if (quantity <= 0) {
            removeFromCart(id, size, color);
            return;
        }
        
        fetch('/e-commerce/api/cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'update', id, size, color, quantity })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) location.reload();
        })
        .catch(error => console.error('Error:', error));
    }

    function removeFromCart(id, size, color) {
        fetch('/e-commerce/api/cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'remove', id, size, color })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) location.reload();
        })
        .catch(error => console.error('Error:', error));
    }

    // Wishlist functions
    function toggleWishlist(productId, name) {
        fetch('/e-commerce/api/wishlist.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'toggle', id: productId, name })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(data.message);
                location.reload();
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // Toast notification
    function showToast(title, description = '') {
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-4 right-4 bg-white border border-border rounded-lg shadow-lg p-4 z-50 max-w-sm';
        toast.style.animation = 'slideIn 0.3s ease-out';
        toast.innerHTML = `<p class="font-medium text-sm">${title}</p>${description ? `<p class="text-xs text-muted-foreground mt-1">${description}</p>` : ''}`;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(10px)';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Add slide-in animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    `;
    document.head.appendChild(style);

    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        const navbar = document.getElementById('navbar');
        if (navbar) {
            if (window.scrollY > 20) {
                navbar.classList.add('bg-white/95', 'backdrop-blur-md', 'shadow-sm');
            } else {
                navbar.classList.remove('bg-white/95', 'backdrop-blur-md', 'shadow-sm');
            }
        }
    });
    </script>

    <script src="/assets/js/main.js"></script>
</body>
</html>
