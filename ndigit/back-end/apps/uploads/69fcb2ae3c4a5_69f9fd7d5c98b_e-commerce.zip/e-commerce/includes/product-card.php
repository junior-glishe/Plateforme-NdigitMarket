<?php
$badge_colors = [
    'New' => 'bg-secondary text-white',
    'Sale' => 'bg-accent text-white',
    'Limited' => 'bg-destructive text-white',
    'Selling Fast' => 'bg-primary text-white',
];

$in_wishlist = in_array($product['id'], $wishlist_items);
?>

<div class="group relative product-card" data-product-id="<?php echo e($product['id']); ?>">
    <a href="<?php echo url('/product.php?id=' . $product['id']); ?>" class="block">
        <!-- Image container -->
        <div class="relative overflow-hidden bg-muted rounded-lg aspect-[3/4]">
            <img src="<?php echo e($product['images'][0]); ?>" 
                 alt="<?php echo e($product['name']); ?>" 
                 class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 product-image-first">
            <img src="<?php echo isset($product['images'][1]) ? e($product['images'][1]) : e($product['images'][0]); ?>" 
                 alt="<?php echo e($product['name']); ?>" 
                 class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 absolute inset-0 opacity-0 group-hover:opacity-100 product-image-second">

            <!-- Badge -->
            <?php if ($product['badge']): ?>
            <span class="absolute top-3 left-3 px-2 py-0.5 text-[10px] font-bold tracking-wider rounded-sm <?php echo $badge_colors[$product['badge']]; ?>">
                <?php echo $product['badge'] === 'Selling Fast' ? '🔥 Selling Fast' : e($product['badge']); ?>
            </span>
            <?php endif; ?>

            <!-- Stock warning -->
            <?php if ($product['stock'] <= 3): ?>
            <span class="absolute top-3 right-3 px-2 py-0.5 text-[10px] font-bold tracking-wider rounded-sm bg-destructive text-white">
                Only <?php echo $product['stock']; ?> left
            </span>
            <?php endif; ?>

            <!-- Hover actions -->
            <div class="hover-actions absolute inset-x-0 bottom-0 flex flex-col gap-2 p-3 transition-all duration-300 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0">
                <button onclick="event.preventDefault(); event.stopPropagation(); addToCart('<?php echo $product['id']; ?>', '<?php echo addslashes($product['name']); ?>', <?php echo $product['price']; ?>, '<?php echo $product['images'][0]; ?>', '<?php echo $product['sizes'][0]; ?>', '')" 
                        class="w-full bg-foreground text-background py-2.5 text-xs font-semibold tracking-wider hover:bg-primary transition-colors duration-200 rounded-md flex items-center justify-center gap-2"
                        data-testid="button-add-to-cart-<?php echo e($product['id']); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                    Add to Cart
                </button>
                <div class="flex gap-2">
                    <button onclick="event.preventDefault(); event.stopPropagation(); showQuickView('<?php echo $product['id']; ?>')" 
                            class="flex-1 bg-white/90 text-foreground py-2 text-xs font-medium rounded-md hover:bg-white transition-colors flex items-center justify-center gap-1"
                            data-testid="button-quick-view-<?php echo e($product['id']); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.062 12a8.083 8.083 0 0 1 .001-.062c.007-.166.05-.492.22-.938a7 7 0 0 1 14.434 0c.17.446.213.772.22.938l.001.062-.001.062c-.007.166-.05.492-.22.938a7 7 0 0 1-14.434 0c-.17-.446-.213-.772-.22-.938Z"/><circle cx="12" cy="12" r="3"/></svg>
                        Quick View
                    </button>
                    <button onclick="event.preventDefault(); event.stopPropagation(); toggleWishlist('<?php echo $product['id']; ?>', '<?php echo addslashes($product['name']); ?>')" 
                            class="flex-shrink-0 w-9 h-9 rounded-md flex items-center justify-center transition-colors <?php echo $in_wishlist ? 'bg-primary text-white' : 'bg-white/90 text-foreground hover:bg-white'; ?>"
                            data-testid="button-wishlist-<?php echo e($product['id']); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="<?php echo $in_wishlist ? 'currentColor' : 'none'; ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                    </button>
                </div>
            </div>

            <!-- Wishlist on mobile (always visible) -->
            <button onclick="event.preventDefault(); event.stopPropagation(); toggleWishlist('<?php echo $product['id']; ?>', '<?php echo addslashes($product['name']); ?>')" 
                    class="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center sm:hidden transition-colors <?php echo $in_wishlist ? 'bg-primary text-white' : 'bg-white/90 text-foreground'; ?>"
                    data-testid="button-wishlist-mobile-<?php echo e($product['id']); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="<?php echo $in_wishlist ? 'currentColor' : 'none'; ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
            </button>
        </div>

        <!-- Product info -->
        <div class="mt-3 space-y-1">
            <p class="text-xs text-muted-foreground tracking-wider uppercase"><?php echo e($product['category']); ?></p>
            <h3 class="font-medium text-sm text-foreground group-hover:text-primary transition-colors leading-snug"><?php echo e($product['name']); ?></h3>
            <div class="flex items-center gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="fill-accent text-accent"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <span class="text-xs text-muted-foreground"><?php echo $product['rating']; ?> (<?php echo $product['reviews']; ?>)</span>
            </div>
            <div class="flex items-center gap-2">
                <span class="font-semibold text-sm"><?php echo format_price($product['price']); ?></span>
                <?php if ($product['originalPrice']): ?>
                <span class="text-xs text-muted-foreground line-through"><?php echo format_price($product['originalPrice']); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </a>
</div>
