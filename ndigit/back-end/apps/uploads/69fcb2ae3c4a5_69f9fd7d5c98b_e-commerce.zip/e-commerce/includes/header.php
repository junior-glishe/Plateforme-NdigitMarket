<?php
require_once __DIR__ . '/../config.php';

$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$cart_count = 0;
$cart_total = 0;

foreach ($cart_items as $item) {
    $cart_count += $item['quantity'];
    $cart_total += $item['price'] * $item['quantity'];
}

$wishlist_items = isset($_SESSION['wishlist']) ? $_SESSION['wishlist'] : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? e($page_title) . ' - ' . SITE_NAME : SITE_NAME; ?></title>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/style.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#ffffff',
                        foreground: '#1a1a1f',
                        border: '#e2e4e9',
                        primary: '#6366f1',
                        secondary: '#10b981',
                        accent: '#f59e0b',
                        destructive: '#ef4444',
                        muted: '#f5f5f7',
                        'muted-foreground': '#71717a',
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        serif: ['Playfair Display', 'serif'],
                    }
                }
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body>
    <!-- Header -->
    <header id="navbar" class="fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-white" data-testid="navbar">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16 lg:h-20">
                <!-- Mobile menu button -->
                <button class="lg:hidden p-2 text-foreground" onclick="toggleMobileMenu()" data-testid="button-mobile-menu">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
                </button>

                <!-- Logo -->
                <a href="/" class="flex-shrink-0" data-testid="link-logo">
                    <span class="font-serif text-2xl lg:text-3xl font-bold tracking-widest text-foreground"><?php echo SITE_NAME; ?></span>
                </a>

                <!-- Desktop nav -->
                <nav class="hidden lg:flex items-center gap-8">
                    <?php
                    $nav_links = [
                        ['href' => url('/'), 'label' => 'Home'],
                        ['href' => url('/shop.php'), 'label' => 'Shop'],
                        ['href' => url('/blog.php'), 'label' => 'Blog'],
                        ['href' => url('/contact.php'), 'label' => 'Contact'],
                    ];
                    foreach ($nav_links as $link):
                        $current_page = basename($_SERVER['PHP_SELF']);
                        $link_file = $link['href'] === url('/') ? 'index.php' : basename($link['href']);
                        $is_active = ($current_page === $link_file) ? 'text-primary' : 'text-foreground/70 hover:text-foreground';
                    ?>
                    <a href="<?php echo e($link['href']); ?>" 
                       class="text-sm font-medium tracking-wide transition-colors duration-200 relative group <?php echo $is_active; ?>"
                       data-testid="link-nav-<?php echo strtolower($link['label']); ?>">
                        <?php echo e($link['label']); ?>
                        <span class="absolute -bottom-1 left-0 h-0.5 bg-primary transition-all duration-300 <?php echo ($current_page === $link_file) ? 'w-full' : 'w-0 group-hover:w-full'; ?>"></span>
                    </a>
                    <?php endforeach; ?>
                </nav>

                <!-- Actions -->
                <div class="flex items-center gap-1 sm:gap-2">
                    <button class="p-2 text-foreground/70 hover:text-foreground transition-colors" onclick="toggleSearch()" data-testid="button-search">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    </button>
                    <a href="<?php echo url('/wishlist.php'); ?>" class="relative p-2 text-foreground/70 hover:text-foreground transition-colors" data-testid="link-wishlist">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                        <?php if (count($wishlist_items) > 0): ?>
                        <span class="absolute -top-0.5 -right-0.5 w-4 h-4 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                            <?php echo count($wishlist_items); ?>
                        </span>
                        <?php endif; ?>
                    </a>
                    <button class="relative p-2 text-foreground/70 hover:text-foreground transition-colors" onclick="toggleCart()" data-testid="button-cart">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                        <?php if ($cart_count > 0): ?>
                        <span class="absolute -top-0.5 -right-0.5 w-4 h-4 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                            <?php echo $cart_count; ?>
                        </span>
                        <?php endif; ?>
                    </button>
                </div>
            </div>

            <!-- Search bar -->
            <div id="search-bar" class="hidden py-3 border-t border-border">
                <input type="search" 
                       placeholder="Search for pieces..." 
                       class="w-full bg-transparent text-foreground placeholder-muted-foreground text-sm outline-none px-2"
                       data-testid="input-search">
            </div>
        </div>
    </header>

    <!-- Mobile menu drawer -->
    <div id="mobile-menu" class="fixed inset-0 z-50 hidden" style="display: none;">
        <div class="absolute inset-0 bg-black/50" onclick="toggleMobileMenu()"></div>
        <div class="absolute left-0 top-0 bottom-0 w-72 bg-white p-6 transition-transform duration-300 ease-in-out" 
             id="mobile-menu-content" 
             style="transform: translateX(-100%);">
            <div class="flex items-center justify-between mb-8">
                <span class="font-serif text-xl font-bold tracking-widest">MAISON</span>
                <button onclick="toggleMobileMenu()" data-testid="button-close-mobile-menu">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </button>
            </div>
            <nav class="flex flex-col gap-1">
                <?php foreach ($nav_links as $link): ?>
                <a href="<?php echo e($link['href']); ?>" 
                   class="flex items-center justify-between py-3 px-2 text-base font-medium border-b border-border/50 hover:text-primary transition-colors"
                   data-testid="link-mobile-nav-<?php echo strtolower($link['label']); ?>">
                    <?php echo e($link['label']); ?>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-muted-foreground"><path d="m9 18 6-6-6-6"/></svg>
                </a>
                <?php endforeach; ?>
            </nav>
            <div class="mt-8 space-y-2">
                <a href="<?php echo url('/wishlist.php'); ?>" class="flex items-center gap-3 py-2 text-sm text-muted-foreground hover:text-foreground">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                    Wishlist (<?php echo count($wishlist_items); ?>)
                </a>
                <button onclick="toggleCart(); toggleMobileMenu();" class="flex items-center gap-3 py-2 text-sm text-muted-foreground hover:text-foreground">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                    My Bag (<?php echo $cart_count; ?>)
                </button>
            </div>
        </div>
    </div>

    <!-- Cart Drawer -->
    <div id="cart-drawer" class="fixed inset-0 z-50 hidden">
        <div class="absolute inset-0 bg-black/50" onclick="toggleCart()"></div>
        <div class="absolute right-0 top-0 bottom-0 w-full sm:w-96 bg-white flex flex-col transform translate-x-full transition-transform duration-300" id="cart-drawer-content">
            <div class="p-6 border-b border-border">
                <h2 class="font-serif text-xl tracking-wide">Your Bag (<?php echo $cart_count; ?>)</h2>
            </div>

            <div class="flex-1 overflow-y-auto p-6 space-y-4" id="cart-items-container">
                <?php if (empty($cart_items)): ?>
                <div class="flex flex-col items-center justify-center h-48 text-muted-foreground">
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mb-3 opacity-30"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                    <p class="text-sm">Your bag is empty</p>
                    <a href="/shop.php" onclick="toggleCart()" class="mt-2 text-primary text-sm underline">Continue Shopping</a>
                </div>
                <?php else: ?>
                    <?php foreach ($cart_items as $index => $item): ?>
                    <div class="flex gap-4" data-testid="cart-item-<?php echo e($item['id']); ?>">
                        <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>" class="w-20 h-24 object-cover rounded-md flex-shrink-0">
                        <div class="flex-1 min-w-0">
                            <p class="font-medium text-sm leading-tight truncate"><?php echo e($item['name']); ?></p>
                            <?php if (isset($item['size'])): ?>
                            <p class="text-xs text-muted-foreground mt-0.5">Size: <?php echo e($item['size']); ?></p>
                            <?php endif; ?>
                            <p class="text-sm font-semibold mt-1"><?php echo format_price($item['price']); ?></p>
                            <div class="flex items-center justify-between mt-2">
                                <div class="flex items-center gap-2 border border-border rounded-full px-2 py-1">
                                    <button onclick="updateCartQuantity('<?php echo $item['id']; ?>', '<?php echo $item['size'] ?? ''; ?>', '<?php echo $item['color'] ?? ''; ?>', <?php echo $item['quantity'] - 1; ?>)" class="text-foreground/60 hover:text-foreground" data-testid="button-decrease-<?php echo $item['id']; ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/></svg>
                                    </button>
                                    <span class="text-xs font-medium w-4 text-center"><?php echo $item['quantity']; ?></span>
                                    <button onclick="updateCartQuantity('<?php echo $item['id']; ?>', '<?php echo $item['size'] ?? ''; ?>', '<?php echo $item['color'] ?? ''; ?>', <?php echo $item['quantity'] + 1; ?>)" class="text-foreground/60 hover:text-foreground" data-testid="button-increase-<?php echo $item['id']; ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
                                    </button>
                                </div>
                                <button onclick="removeFromCart('<?php echo $item['id']; ?>', '<?php echo $item['size'] ?? ''; ?>', '<?php echo $item['color'] ?? ''; ?>')" class="text-muted-foreground hover:text-destructive transition-colors" data-testid="button-remove-<?php echo $item['id']; ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <?php if (!empty($cart_items)): ?>
            <div class="p-6 border-t border-border space-y-4 bg-muted/30">
                <div class="flex items-center justify-between">
                    <span class="text-sm text-muted-foreground">Subtotal</span>
                    <span class="font-semibold text-lg"><?php echo format_price($cart_total); ?></span>
                </div>
                <?php if ($cart_total < 150): ?>
                <p class="text-xs text-muted-foreground bg-secondary/10 text-secondary rounded-md px-3 py-2">
                    Add $<?php echo (150 - $cart_total); ?> more for free shipping
                </p>
                <?php endif; ?>
                <a href="<?php echo url('/checkout.php'); ?>" onclick="toggleCart()">
                    <button class="w-full h-12 text-sm font-semibold tracking-wider bg-primary text-white hover:bg-primary/90 rounded-md" data-testid="button-checkout">
                        Proceed to Checkout
                    </button>
                </a>
                <a href="<?php echo url('/cart.php'); ?>" onclick="toggleCart()">
                    <button class="w-full h-10 text-xs border border-border rounded-md hover:bg-muted" data-testid="link-view-cart">
                        View Full Cart
                    </button>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
