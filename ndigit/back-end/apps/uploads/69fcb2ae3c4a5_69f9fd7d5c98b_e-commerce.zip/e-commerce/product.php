<?php
$page_title = 'Product Detail';
require_once 'config.php';

$product_id = isset($_GET['id']) ? $_GET['id'] : '';
$product = get_product_by_id($product_id);

if (!$product) {
    header('Location: /shop.php');
    exit;
}

require_once 'includes/header.php';

$in_wishlist = in_array($product['id'], $wishlist_items);
$badge_colors = [
    'New' => 'bg-secondary text-white',
    'Sale' => 'bg-accent text-white',
    'Limited' => 'bg-destructive text-white',
    'Selling Fast' => 'bg-primary text-white',
];
?>

<div class="pt-24 lg:pt-28 pb-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Breadcrumb -->
        <nav class="text-sm text-muted-foreground mb-8">
            <a href="/" class="hover:text-foreground">Home</a> / 
            <a href="/shop.php" class="hover:text-foreground">Shop</a> / 
            <span class="text-foreground"><?php echo e($product['name']); ?></span>
        </nav>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <!-- Images -->
            <div class="space-y-4">
                <div class="aspect-[3/4] overflow-hidden rounded-lg bg-muted">
                    <img id="main-image" src="<?php echo e($product['images'][0]); ?>" 
                         alt="<?php echo e($product['name']); ?>" 
                         class="w-full h-full object-cover">
                </div>
                <?php if (count($product['images']) > 1): ?>
                <div class="grid grid-cols-2 gap-4">
                    <?php foreach ($product['images'] as $i => $img): ?>
                    <button onclick="document.getElementById('main-image').src='<?php echo e($img); ?>'" 
                            class="aspect-[3/4] overflow-hidden rounded-lg bg-muted">
                        <img src="<?php echo e($img); ?>" alt="<?php echo e($product['name']); ?>" class="w-full h-full object-cover">
                    </button>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Product Info -->
            <div class="space-y-6">
                <?php if ($product['badge']): ?>
                <span class="inline-block px-3 py-1 text-xs font-bold tracking-wider rounded-sm <?php echo $badge_colors[$product['badge']]; ?>">
                    <?php echo e($product['badge']); ?>
                </span>
                <?php endif; ?>

                <h1 class="font-serif text-4xl sm:text-5xl font-bold"><?php echo e($product['name']); ?></h1>

                <div class="flex items-center gap-4">
                    <div class="flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="fill-accent text-accent"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <span class="font-medium"><?php echo $product['rating']; ?></span>
                        <span class="text-muted-foreground">(<?php echo $product['reviews']; ?> reviews)</span>
                    </div>
                </div>

                <div class="flex items-baseline gap-4">
                    <span class="font-serif text-3xl font-bold"><?php echo format_price($product['price']); ?></span>
                    <?php if ($product['originalPrice']): ?>
                    <span class="text-xl text-muted-foreground line-through"><?php echo format_price($product['originalPrice']); ?></span>
                    <?php endif; ?>
                </div>

                <p class="text-muted-foreground leading-relaxed"><?php echo e($product['description']); ?></p>

                <?php if ($product['stock'] <= 3): ?>
                <p class="text-destructive font-semibold text-sm">⚠️ Only <?php echo $product['stock']; ?> left in stock!</p>
                <?php endif; ?>

                <!-- Colors -->
                <div>
                    <h3 class="font-semibold text-sm mb-3">Color</h3>
                    <div class="flex gap-3">
                        <?php foreach ($product['colors'] as $color): ?>
                        <button class="w-10 h-10 rounded-full border-2 border-border hover:border-primary transition-colors" 
                                style="background-color: <?php echo e($color['value']); ?>" 
                                title="<?php echo e($color['name']); ?>">
                        </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Sizes -->
                <div>
                    <h3 class="font-semibold text-sm mb-3">Size</h3>
                    <div class="flex flex-wrap gap-3">
                        <?php foreach ($product['sizes'] as $size): ?>
                        <button class="size-btn min-w-[60px] px-4 py-3 border border-border rounded-md text-sm font-medium hover:border-primary transition-colors" 
                                onclick="document.querySelectorAll('.size-btn').forEach(b => b.classList.remove('bg-primary', 'text-white')); this.classList.add('bg-primary', 'text-white');">
                            <?php echo e($size); ?>
                        </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Actions -->
                <div class="flex gap-4 pt-4">
                    <button onclick="addToCart('<?php echo $product['id']; ?>', '<?php echo addslashes($product['name']); ?>', <?php echo $product['price']; ?>, '<?php echo $product['images'][0]; ?>', document.querySelector('.size-btn.bg-primary')?.textContent || '<?php echo $product['sizes'][0]; ?>', '')" 
                            class="flex-1 h-14 bg-primary text-white font-semibold tracking-wider hover:bg-primary/90 rounded-md flex items-center justify-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                        Add to Cart
                    </button>
                    <button onclick="toggleWishlist('<?php echo $product['id']; ?>', '<?php echo addslashes($product['name']); ?>')" 
                            class="w-14 h-14 border border-border rounded-md flex items-center justify-center hover:border-primary transition-colors <?php echo $in_wishlist ? 'bg-primary text-white' : ''; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="<?php echo $in_wishlist ? 'currentColor' : 'none'; ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <section class="mt-20">
            <h2 class="font-serif text-3xl font-bold mb-8">You May Also Like</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-8">
                <?php
                $related = array_filter($products, function($p) use ($product) {
                    return $p['id'] !== $product['id'] && $p['category'] === $product['category'];
                });
                $related = array_slice($related, 0, 4);
                foreach ($related as $rel_product):
                ?>
                    <?php $product = $rel_product; include 'includes/product-card.php'; ?>
                <?php endforeach; ?>
            </div>
        </section>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
