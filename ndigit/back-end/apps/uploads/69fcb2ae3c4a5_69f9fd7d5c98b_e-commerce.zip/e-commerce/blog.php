<?php
$page_title = 'Blog - Fashion Insights';
require_once 'config.php';
require_once 'includes/header.php';

$blog_posts = [
    [
        'title' => 'The Art of Building a Capsule Wardrobe',
        'excerpt' => 'Discover how to curate a timeless collection of versatile pieces that work together seamlessly.',
        'image' => 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&q=80&w=800',
        'date' => 'March 15, 2025',
        'category' => 'Style Guide',
    ],
    [
        'title' => 'Spring 2025: Trends That Matter',
        'excerpt' => 'From fluid silhouettes to bold accessories, here are the trends defining this season.',
        'image' => 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&q=80&w=800',
        'date' => 'March 10, 2025',
        'category' => 'Trends',
    ],
    [
        'title' => 'How to Care for Luxury Fabrics',
        'excerpt' => 'Expert tips on maintaining your silk, cashmere, and other premium materials.',
        'image' => 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=800',
        'date' => 'March 5, 2025',
        'category' => 'Care Guide',
    ],
    [
        'title' => 'Investment Pieces Worth Every Penny',
        'excerpt' => 'Why quality over quantity is the secret to a sophisticated wardrobe.',
        'image' => 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=800',
        'date' => 'February 28, 2025',
        'category' => 'Shopping Tips',
    ],
];
?>

<div class="pt-24 lg:pt-28 pb-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="mb-12">
            <h1 class="font-serif text-4xl sm:text-5xl font-bold mb-4">Blog</h1>
            <p class="text-muted-foreground">Fashion insights, style guides, and care tips</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <?php foreach ($blog_posts as $post): ?>
            <article class="group">
                <div class="overflow-hidden rounded-lg mb-4 aspect-[16/9]">
                    <img src="<?php echo e($post['image']); ?>" alt="<?php echo e($post['title']); ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700">
                </div>
                <div class="space-y-2">
                    <div class="flex items-center gap-3 text-sm text-muted-foreground">
                        <span class="text-primary font-medium"><?php echo e($post['category']); ?></span>
                        <span>•</span>
                        <span><?php echo e($post['date']); ?></span>
                    </div>
                    <h2 class="font-serif text-2xl font-bold group-hover:text-primary transition-colors"><?php echo e($post['title']); ?></h2>
                    <p class="text-muted-foreground leading-relaxed"><?php echo e($post['excerpt']); ?></p>
                    <a href="#" class="inline-block text-primary font-medium text-sm hover:underline mt-2">
                        Read More →
                    </a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
