<?php
// Configuration générale
define('SITE_NAME', 'MAISON');
define('SITE_URL', 'http://localhost/e-commerce');
define('BASE_PATH', '/e-commerce');

// Démarrer la session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Inclure les données produits
require_once __DIR__ . '/data/products.php';

// Fonctions utilitaires
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function format_price($price) {
    return '$' . number_format($price, 0);
}

function active_link($page) {
    $current = basename($_SERVER['PHP_SELF']);
    return ($current === $page) ? 'text-primary' : 'text-foreground/70 hover:text-foreground';
}

function url($path) {
    return BASE_PATH . $path;
}
