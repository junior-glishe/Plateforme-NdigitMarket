<?php
$page_title = 'Wishlist';
require_once 'config.php';
require_once 'includes/header.php';

$wishlist_ids = isset($_SESSION['wishlist']) ? $_SESSION['wishlist'] : [];
$wishlist_products = array_filter($products, function($p) use ($wishlist_ids) {
    return in_array($p['id'], $wishlist_ids);
});
?>

<div class="pt-24 lg:pt-28 pb-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 class="font-serif text-4xl sm:text-5xl font-bold mb-8">My Wishlist</h1>

        <?php if (empty($wishlist_products)): ?>
        <div class="text-center py-20">
            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-auto mb-4 opacity-30"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
            <p class="text-muted-foreground text-lg mb-4">Your wishlist is empty</p>
            <a href="/shop.php">
                <button class="bg-primary text-white px-8 py-3 rounded-md font-semibold hover:bg-primary/90">Discover Products</button>
            </a>
        </div>
        <?php else: ?>
        <p class="text-muted-foreground mb-8"><?php echo count($wishlist_products); ?> items</p>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-8">
            <?php foreach ($wishlist_products as $product): ?>
                <?php include 'includes/product-card.php'; ?>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
