# E-Commerce MAISON - Version PHP

Un site e-commerce complet développé en PHP avec le même design que la version React originale.

## 🚀 Installation

### Prérequis
- XAMPP (ou tout autre serveur PHP avec Apache)
- PHP 7.4 ou supérieur
- Un navigateur web moderne


## 📁 Structure du projet

```
e-commerce/
├── api/                    # Endpoints AJAX
│   ├── cart.php           # Gestion du panier
│   └── wishlist.php       # Gestion de la wishlist
├── assets/
│   ├── css/
│   │   └── style.css      # Styles Tailwind CSS
│   └── js/
│       └── main.js        # JavaScript principal
├── data/
│   └── products.php       # Données des produits
├── includes/
│   ├── header.php         # En-tête commun
│   ├── footer.php         # Pied de page commun
│   └── product-card.php   # Carte produit réutilisable
├── config.php             # Configuration globale
├── index.php              # Page d'accueil
├── shop.php               # Page boutique
├── product.php            # Page détail produit
├── cart.php               # Page panier
├── wishlist.php           # Page wishlist
├── checkout.php           # Page checkout
├── blog.php               # Page blog
├── contact.php            # Page contact
└── .htaccess              # Configuration Apache
```

## ✨ Fonctionnalités

### Pages principales
- ✅ **Accueil** - Hero slider, catégories, produits vedettes, testimonials
- ✅ **Boutique** - Grille de produits avec filtres et recherche
- ✅ **Détail produit** - Images, sélection taille/couleur, produits similaires
- ✅ **Panier** - Gestion complète avec sessions PHP
- ✅ **Wishlist** - Liste de souhaits persistante
- ✅ **Checkout** - Processus de commande
- ✅ **Blog** - Articles fashion
- ✅ **Contact** - Formulaire de contact

### Fonctionnalités interactives
- ✅ Panier dynamique avec AJAX
- ✅ Wishlist avec persistance en session
- ✅ Slider hero automatique
- ✅ Navigation responsive
- ✅ Menu mobile drawer
- ✅ Panier latéral (mini cart)
- ✅ Recherche de produits
- ✅ Filtrage par catégorie
- ✅ Tri des produits (prix, notes)
- ✅ Notifications toast
- ✅ Hover effects sur les produits

## 🎨 Design

Le design est **exactement identique** à la version React :
- Mêmes couleurs (Tailwind CSS)
- Mêmes polices (Inter + Playfair Display)
- Mêmes espacements et layouts
- Mêmes animations et transitions
- Icons SVG inline (pas de dépendance externe)

## 🔧 Technologies utilisées

- **Backend**: PHP 7.4+
- **Frontend**: HTML5, CSS3, JavaScript vanilla
- **CSS Framework**: Tailwind CSS (via CDN)
- **Icons**: SVG inline (Lucide-style)
- **Storage**: Sessions PHP pour panier et wishlist

## 📝 Notes importantes

### Sessions PHP
Le panier et la wishlist sont stockés dans des sessions PHP. Cela signifie :
- Les données persistent pendant la navigation
- Les données sont perdues si le navigateur est fermé
- Pas besoin de base de données pour cette version

### Tailwind CSS
Le fichier `style.css` utilise Tailwind CSS via CDN. Pour une utilisation en production, il est recommandé de :
1. Installer Tailwind CSS localement
2. Compiler les styles pour de meilleures performances

### Images
Toutes les images proviennent d'Unsplash et sont chargées directement depuis leur CDN.

## 🌐 URLs du site

- Accueil : `http://localhost/e-commerce/`
- Boutique : `http://localhost/e-commerce/shop.php`
- Panier : `http://localhost/e-commerce/cart.php`
- Wishlist : `http://localhost/e-commerce/wishlist.php`
- Blog : `http://localhost/e-commerce/blog.php`
- Contact : `http://localhost/e-commerce/contact.php`

## 🔄 Différences avec la version React

1. **Routing** : Navigation PHP traditionnelle au lieu de React Router
2. **State Management** : Sessions PHP au lieu de React Context
3. **Animations** : CSS transitions au lieu de Framer Motion
4. **Components** : Includes PHP au lieu de composants React
5. **Build** : Aucun build nécessaire, PHP est interprété directement

## 🚀 Améliorations futures possibles

- Ajouter une base de données MySQL
- Système d'authentification utilisateur
- Panel d'administration
- Paiement en ligne (Stripe, PayPal)
- Optimisation des images
- Cache pour de meilleures performances
- SEO optimization

## 📄 License

Ce projet est une conversion PHP du projet React original MAISON.

---

**Développé avec ❤️ en PHP**
