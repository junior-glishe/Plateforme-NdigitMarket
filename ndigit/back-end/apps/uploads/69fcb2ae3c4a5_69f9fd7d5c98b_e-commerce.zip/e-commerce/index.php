<?php
$page_title = 'Luxury Fashion & Timeless Pieces';
require_once 'config.php';
require_once 'includes/header.php';

$featured = array_slice($products, 0, 8);
$new_arrivals = array_filter($products, function($p) { return $p['badge'] === 'New'; });
$new_arrivals = array_slice($new_arrivals, 0, 4);

$hero_slides = [
    [
        'img' => 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&q=80&w=1600',
        'headline' => 'The New Collection',
        'sub' => 'Discover pieces crafted for the modern wardrobe',
        'cta' => 'Shop Now',
    ],
    [
        'img' => 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&q=80&w=1600',
        'headline' => 'Explore New Arrivals',
        'sub' => 'Fresh silhouettes. Timeless elegance.',
        'cta' => 'Discover the Collection',
    ],
    [
        'img' => 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=1600',
        'headline' => 'Elevated Essentials',
        'sub' => 'Investment pieces worth every cent',
        'cta' => 'Shop Essentials',
    ],
];

$categories = [
    ['label' => 'Dresses', 'img' => 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&q=80&w=600'],
    ['label' => 'Jackets', 'img' => 'https://images.unsplash.com/photo-1539533113208-f6df8cc8b543?auto=format&fit=crop&q=80&w=600'],
    ['label' => 'Accessories', 'img' => 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=600'],
    ['label' => 'Shoes', 'img' => 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&q=80&w=600'],
];
?>

<div class="pt-16 lg:pt-20">
    <!-- Hero Section -->
    <section class="relative h-[85vh] min-h-[580px] overflow-hidden" data-testid="section-hero">
        <?php foreach ($hero_slides as $i => $slide): ?>
        <div class="hero-slide absolute inset-0 transition-opacity duration-1000 <?php echo $i === 0 ? 'opacity-100' : 'opacity-0'; ?>" data-index="<?php echo $i; ?>">
            <img src="<?php echo e($slide['img']); ?>" alt="<?php echo e($slide['headline']); ?>" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent"></div>
        </div>
        <?php endforeach; ?>

        <div class="relative h-full flex items-center">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
                <div id="hero-content" class="max-w-xl">
                    <p class="text-white/70 text-xs tracking-[0.3em] uppercase mb-4">MAISON — SS 2025</p>
                    <h1 id="hero-headline" class="font-serif text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6">
                        <?php echo e($hero_slides[0]['headline']); ?>
                    </h1>
                    <p id="hero-sub" class="text-white/80 text-lg mb-8"><?php echo e($hero_slides[0]['sub']); ?></p>
                    <div class="flex flex-wrap gap-3">
                        <a href="/shop.php">
                            <button id="hero-cta" class="h-13 px-8 text-sm font-semibold tracking-wider bg-primary text-white hover:bg-primary/90 rounded-md" data-testid="button-hero-shop-now">
                                <?php echo e($hero_slides[0]['cta']); ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="inline ml-2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                            </button>
                        </a>
                        <a href="/shop.php">
                            <button class="h-13 px-8 text-sm font-semibold tracking-wider border border-white/40 text-white hover:bg-white/20 rounded-md bg-white/10" data-testid="button-hero-discover">
                                Explore New Arrivals
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide dots -->
        <div class="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
            <?php foreach ($hero_slides as $i => $slide): ?>
            <button onclick="goToSlide(<?php echo $i; ?>)" 
                    class="hero-dot h-1 rounded-full transition-all duration-300 <?php echo $i === 0 ? 'w-8 bg-white' : 'w-2 bg-white/40'; ?>" 
                    data-index="<?php echo $i; ?>"
                    data-testid="button-hero-dot-<?php echo $i; ?>">
            </button>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Trust bar -->
    <section class="bg-foreground text-background py-4">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex flex-wrap items-center justify-center gap-6 sm:gap-12">
                <?php
                $trust = [
                    ['icon' => 'truck', 'label' => 'Free Shipping', 'sub' => 'On orders over $150'],
                    ['icon' => 'rotate', 'label' => 'Easy Returns', 'sub' => '30-day hassle-free returns'],
                    ['icon' => 'shield', 'label' => 'Secure Payment', 'sub' => '100% protected checkout'],
                    ['icon' => 'users', 'label' => '10,000+ Customers', 'sub' => 'Trusted worldwide'],
                ];
                foreach ($trust as $item):
                ?>
                <div class="flex items-center gap-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-primary flex-shrink-0">
                        <?php if ($item['icon'] === 'truck'): ?>
                        <path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.4-4.25a1 1 0 0 0-.78-.376H15"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/>
                        <?php elseif ($item['icon'] === 'rotate'): ?>
                        <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>
                        <?php elseif ($item['icon'] === 'shield'): ?>
                        <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 4.81 17 6 19 6a1 1 0 0 1 1 1z"/>
                        <?php else: ?>
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                        <?php endif; ?>
                    </svg>
                    <div>
                        <p class="text-xs font-semibold text-white"><?php echo e($item['label']); ?></p>
                        <p class="text-[11px] text-background/50"><?php echo e($item['sub']); ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Categories -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div class="flex items-end justify-between mb-10">
            <div>
                <p class="text-xs tracking-widest uppercase text-muted-foreground mb-2">Explore</p>
                <h2 class="font-serif text-3xl sm:text-4xl font-bold">Shop by Category</h2>
            </div>
            <a href="/shop.php" class="hidden sm:flex items-center gap-1 text-sm text-primary hover:gap-2 transition-all" data-testid="link-all-categories">
                View All <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
            </a>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <?php foreach ($categories as $cat): ?>
            <a href="/shop.php?category=<?php echo urlencode($cat['label']); ?>" data-testid="link-category-<?php echo strtolower($cat['label']); ?>">
                <div class="group relative overflow-hidden rounded-lg aspect-[3/4]">
                    <img src="<?php echo e($cat['img']); ?>" alt="<?php echo e($cat['label']); ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                    <div class="absolute bottom-4 left-4">
                        <p class="font-serif text-white text-lg font-semibold"><?php echo e($cat['label']); ?></p>
                        <p class="text-white/70 text-xs flex items-center gap-1 mt-1 group-hover:gap-2 transition-all">
                            Shop now <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </p>
                    </div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Featured Products -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div class="flex items-end justify-between mb-10">
            <div>
                <p class="text-xs tracking-widest uppercase text-muted-foreground mb-2">Curated for you</p>
                <h2 class="font-serif text-3xl sm:text-4xl font-bold">Featured Pieces</h2>
            </div>
            <a href="/shop.php" class="hidden sm:flex items-center gap-1 text-sm text-primary hover:gap-2 transition-all" data-testid="link-all-products">
                View All <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
            </a>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-8">
            <?php foreach ($featured as $product): ?>
            <div>
                <?php include 'includes/product-card.php'; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="mt-10 text-center sm:hidden">
            <a href="/shop.php">
                <button class="px-8 border border-border rounded-md hover:bg-muted" data-testid="button-view-all-mobile">View All Products</button>
            </a>
        </div>
    </section>

    <!-- Banner CTA -->
    <section class="relative h-72 sm:h-96 overflow-hidden">
        <img src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=1600" alt="New arrivals" class="w-full h-full object-cover">
        <div class="absolute inset-0 bg-primary/70"></div>
        <div class="absolute inset-0 flex flex-col items-center justify-center text-white text-center px-4">
            <p class="text-xs tracking-[0.3em] uppercase mb-3 opacity-80">Limited Time</p>
            <h2 class="font-serif text-3xl sm:text-5xl font-bold mb-4">New Arrivals Are Here</h2>
            <p class="text-white/80 mb-6 max-w-md">Fresh pieces just landed. Free shipping on your first order.</p>
            <a href="/shop.php">
                <button class="bg-white text-primary hover:bg-white/90 px-8 font-semibold rounded-md" data-testid="button-banner-cta">
                    Explore New Arrivals
                </button>
            </a>
        </div>
    </section>

    <!-- New Arrivals -->
    <?php if (count($new_arrivals) > 0): ?>
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div class="flex items-end justify-between mb-10">
            <div>
                <p class="text-xs tracking-widest uppercase text-muted-foreground mb-2">Just Landed</p>
                <h2 class="font-serif text-3xl sm:text-4xl font-bold">New Arrivals</h2>
            </div>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-8">
            <?php foreach ($new_arrivals as $product): ?>
                <?php include 'includes/product-card.php'; ?>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- Testimonial -->
    <section class="bg-muted py-16">
        <div class="max-w-3xl mx-auto px-4 text-center">
            <div class="flex justify-center mb-4">
                <?php for ($i = 0; $i < 5; $i++): ?>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="fill-accent text-accent"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <?php endfor; ?>
            </div>
            <p class="font-serif text-2xl sm:text-3xl text-foreground leading-relaxed mb-6">
                "MAISON has completely elevated my wardrobe. The quality is extraordinary and the service is unmatched."
            </p>
            <p class="text-sm text-muted-foreground font-medium tracking-wide">— Sophie R., Paris</p>
            <p class="text-xs text-muted-foreground mt-1">Trusted by 10,000+ customers worldwide</p>
        </div>
    </section>
</div>

<script>
// Hero slider
let currentSlide = 0;
const slides = document.querySelectorAll('.hero-slide');
const dots = document.querySelectorAll('.hero-dot');
const heroHeadline = document.getElementById('hero-headline');
const heroSub = document.getElementById('hero-sub');
const heroCta = document.getElementById('hero-cta');

const heroData = <?php echo json_encode($hero_slides); ?>;

function goToSlide(index) {
    slides[currentSlide].classList.remove('opacity-100');
    slides[currentSlide].classList.add('opacity-0');
    dots[currentSlide].classList.remove('w-8', 'bg-white');
    dots[currentSlide].classList.add('w-2', 'bg-white/40');
    
    currentSlide = index;
    
    slides[currentSlide].classList.remove('opacity-0');
    slides[currentSlide].classList.add('opacity-100');
    dots[currentSlide].classList.remove('w-2', 'bg-white/40');
    dots[currentSlide].classList.add('w-8', 'bg-white');
    
    heroHeadline.textContent = heroData[currentSlide].headline;
    heroSub.textContent = heroData[currentSlide].sub;
    heroCta.textContent = heroData[currentSlide].cta;
}

setInterval(() => {
    goToSlide((currentSlide + 1) % slides.length);
}, 5000);
</script>

<?php require_once 'includes/footer.php'; ?>
