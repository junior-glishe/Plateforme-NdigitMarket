<?php
$page_title = 'Checkout';
require_once 'config.php';

$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$cart_total = 0;
foreach ($cart_items as $item) {
    $cart_total += $item['price'] * $item['quantity'];
}

if (empty($cart_items)) {
    header('Location: ' . url('/cart.php'));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle order submission
    $_SESSION['cart'] = [];
    header('Location: ' . url('/shop.php?success=1'));
    exit;
}

require_once 'includes/header.php';
?>

<div class="pt-24 lg:pt-28 pb-20">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 class="font-serif text-4xl sm:text-5xl font-bold mb-12">Checkout</h1>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <!-- Checkout Form -->
            <div class="space-y-8">
                <form method="POST" id="checkout-form">
                    <div>
                        <h2 class="font-serif text-2xl font-bold mb-4">Contact Information</h2>
                        <input type="email" 
                               name="email" 
                               placeholder="Email" 
                               required
                               class="w-full border border-border rounded-md px-4 py-3 outline-none focus:border-primary mb-3">
                        <input type="tel" 
                               name="phone" 
                               placeholder="Phone" 
                               required
                               class="w-full border border-border rounded-md px-4 py-3 outline-none focus:border-primary">
                    </div>

                    <div class="mt-8">
                        <h2 class="font-serif text-2xl font-bold mb-4">Shipping Address</h2>
                        <div class="grid grid-cols-2 gap-3">
                            <input type="text" 
                                   name="first_name" 
                                   placeholder="First Name" 
                                   required
                                   class="border border-border rounded-md px-4 py-3 outline-none focus:border-primary">
                            <input type="text" 
                                   name="last_name" 
                                   placeholder="Last Name" 
                                   required
                                   class="border border-border rounded-md px-4 py-3 outline-none focus:border-primary">
                        </div>
                        <input type="text" 
                               name="address" 
                               placeholder="Address" 
                               required
                               class="w-full border border-border rounded-md px-4 py-3 outline-none focus:border-primary mt-3">
                        <input type="text" 
                               name="city" 
                               placeholder="City" 
                               required
                               class="w-full border border-border rounded-md px-4 py-3 outline-none focus:border-primary mt-3">
                        <div class="grid grid-cols-2 gap-3 mt-3">
                            <input type="text" 
                                   name="state" 
                                   placeholder="State" 
                                   required
                                   class="border border-border rounded-md px-4 py-3 outline-none focus:border-primary">
                            <input type="text" 
                                   name="zip" 
                                   placeholder="ZIP Code" 
                                   required
                                   class="border border-border rounded-md px-4 py-3 outline-none focus:border-primary">
                        </div>
                    </div>

                    <div class="mt-8">
                        <h2 class="font-serif text-2xl font-bold mb-4">Payment Method</h2>
                        <p class="text-sm text-muted-foreground mb-4">Payment will be processed securely. For demo purposes, no actual payment is required.</p>
                    </div>

                    <button type="submit" class="w-full h-14 bg-primary text-white font-semibold tracking-wider hover:bg-primary/90 rounded-md mt-8">
                        Complete Order - <?php echo format_price($cart_total); ?>
                    </button>
                </form>
            </div>

            <!-- Order Summary -->
            <div>
                <div class="p-6 border border-border rounded-lg bg-muted/30 sticky top-24">
                    <h2 class="font-serif text-2xl font-bold mb-6">Order Summary</h2>
                    
                    <div class="space-y-4 mb-6">
                        <?php foreach ($cart_items as $item): ?>
                        <div class="flex gap-4">
                            <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>" class="w-16 h-20 object-cover rounded-md">
                            <div class="flex-1">
                                <p class="font-medium text-sm"><?php echo e($item['name']); ?></p>
                                <?php if (isset($item['size'])): ?>
                                <p class="text-xs text-muted-foreground">Size: <?php echo e($item['size']); ?></p>
                                <?php endif; ?>
                                <p class="text-sm mt-1">Qty: <?php echo $item['quantity']; ?></p>
                            </div>
                            <p class="font-semibold"><?php echo format_price($item['price'] * $item['quantity']); ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="border-t border-border pt-4 space-y-3">
                        <div class="flex justify-between">
                            <span class="text-muted-foreground">Subtotal</span>
                            <span class="font-semibold"><?php echo format_price($cart_total); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-muted-foreground">Shipping</span>
                            <span class="font-semibold"><?php echo $cart_total >= 150 ? 'FREE' : format_price(15); ?></span>
                        </div>
                        <div class="border-t border-border pt-3 flex justify-between">
                            <span class="font-semibold text-lg">Total</span>
                            <span class="font-serif text-2xl font-bold"><?php echo format_price($cart_total >= 150 ? $cart_total : $cart_total + 15); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
