<?php
$products = [
    [
        'id' => 'p1',
        'name' => 'Lumière Silk Maxi Dress',
        'category' => 'Dresses',
        'price' => 890,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['XS', 'S', 'M', 'L'],
        'colors' => [['name' => 'Noir', 'value' => '#000000'], ['name' => 'Emerald', 'value' => '#10B981']],
        'stock' => 3,
        'rating' => 4.9,
        'reviews' => 124,
        'badge' => 'Selling Fast',
        'description' => 'A breathtaking pure silk maxi dress designed to drape perfectly. Features a subtle cowl neckline and a dramatic open back. Crafted in Como, Italy from the finest mulberry silk.'
    ],
    [
        'id' => 'p2',
        'name' => 'Oversized Cashmere Coat',
        'category' => 'Jackets',
        'price' => 1250,
        'originalPrice' => 1500,
        'images' => [
            'https://images.unsplash.com/photo-1539533113208-f6df8cc8b543?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['S', 'M', 'L'],
        'colors' => [['name' => 'Camel', 'value' => '#D4B595'], ['name' => 'Noir', 'value' => '#000000']],
        'stock' => 8,
        'rating' => 4.8,
        'reviews' => 89,
        'badge' => 'Sale',
        'description' => 'The ultimate winter staple. Spun from 100% pure cashmere, this oversized coat envelops you in unparalleled luxury and warmth. Impeccably tailored with a relaxed silhouette.'
    ],
    [
        'id' => 'p3',
        'name' => 'Sculptural Blazer',
        'category' => 'Jackets',
        'price' => 680,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1594938298603-c8148c4b4291?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['XS', 'S', 'M', 'L', 'XL'],
        'colors' => [['name' => 'Ivory', 'value' => '#F5F5DC'], ['name' => 'Navy', 'value' => '#1E3A5F'], ['name' => 'Noir', 'value' => '#000000']],
        'stock' => 12,
        'rating' => 4.7,
        'reviews' => 56,
        'badge' => 'New',
        'description' => 'A statement blazer with bold sculptural shoulders and a precisely tailored body. Wear it open over a slip dress or buttoned with wide-leg trousers.'
    ],
    [
        'id' => 'p4',
        'name' => 'Fluid Wide-Leg Trousers',
        'category' => 'Pants',
        'price' => 420,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1594938298603-c8148c4b4291?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1603400521630-9f2de124b33b?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['XS', 'S', 'M', 'L'],
        'colors' => [['name' => 'Stone', 'value' => '#B5A99A'], ['name' => 'Noir', 'value' => '#000000'], ['name' => 'Ivory', 'value' => '#FFFDD0']],
        'stock' => 15,
        'rating' => 4.6,
        'reviews' => 73,
        'badge' => null,
        'description' => 'Elegantly fluid wide-leg trousers in premium crepe. A high-rise waist and clean, architectural lines make these the most versatile piece in your wardrobe.'
    ],
    [
        'id' => 'p5',
        'name' => 'Minimal Ribbed Knit Top',
        'category' => 'Tops',
        'price' => 195,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['XS', 'S', 'M', 'L', 'XL'],
        'colors' => [['name' => 'Cream', 'value' => '#FFFDD0'], ['name' => 'Sage', 'value' => '#8FAF8A'], ['name' => 'Noir', 'value' => '#000000']],
        'stock' => 30,
        'rating' => 4.5,
        'reviews' => 211,
        'badge' => 'New',
        'description' => 'A clean, modern ribbed knit top with a fitted silhouette and subtle stretch. Pairs effortlessly with everything from tailored trousers to denim.'
    ],
    [
        'id' => 'p6',
        'name' => 'Strappy Leather Mules',
        'category' => 'Shoes',
        'price' => 565,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1605812860427-4024433a70fd?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['35', '36', '37', '38', '39', '40'],
        'colors' => [['name' => 'Cognac', 'value' => '#9F4A0A'], ['name' => 'Noir', 'value' => '#000000']],
        'stock' => 2,
        'rating' => 4.9,
        'reviews' => 45,
        'badge' => 'Limited',
        'description' => 'Artisan-crafted Italian leather mules with delicate adjustable straps and a sculpted 6cm heel. A gallery-worthy shoe for the modern wardrobe.'
    ],
    [
        'id' => 'p7',
        'name' => 'Chain-Link Mini Bag',
        'category' => 'Accessories',
        'price' => 345,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1614179689702-355944cd0918?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['One Size'],
        'colors' => [['name' => 'Gold', 'value' => '#CFB53B'], ['name' => 'Silver', 'value' => '#C0C0C0']],
        'stock' => 6,
        'rating' => 4.8,
        'reviews' => 38,
        'badge' => 'Selling Fast',
        'description' => 'A compact structured mini bag with a polished chain-link strap. Holds your essentials in style. Finished with a signature turn-lock closure in burnished hardware.'
    ],
    [
        'id' => 'p8',
        'name' => 'Wrap Midi Dress',
        'category' => 'Dresses',
        'price' => 520,
        'originalPrice' => 650,
        'images' => [
            'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1550614000-4895a10e1bfd?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['XS', 'S', 'M', 'L'],
        'colors' => [['name' => 'Midnight', 'value' => '#191970'], ['name' => 'Blush', 'value' => '#FFB6C1']],
        'stock' => 9,
        'rating' => 4.7,
        'reviews' => 95,
        'badge' => 'Sale',
        'description' => 'A timeless wrap midi dress with a flattering V-neckline and fluid skirt. Made from a premium silk-blend crepe that moves beautifully with every step.'
    ],
    [
        'id' => 'p9',
        'name' => 'Cropped Leather Jacket',
        'category' => 'Jackets',
        'price' => 1100,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['XS', 'S', 'M', 'L'],
        'colors' => [['name' => 'Noir', 'value' => '#000000'], ['name' => 'Cognac', 'value' => '#9F4A0A']],
        'stock' => 4,
        'rating' => 5.0,
        'reviews' => 31,
        'badge' => 'Limited',
        'description' => 'A refined take on the classic leather jacket. Cut in a precise cropped silhouette from Italian nappa leather. Buttery-soft yet structured — the jacket that defines an era.'
    ],
    [
        'id' => 'p10',
        'name' => 'Sheer Organza Blouse',
        'category' => 'Tops',
        'price' => 285,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['XS', 'S', 'M', 'L'],
        'colors' => [['name' => 'White', 'value' => '#FFFFFF'], ['name' => 'Powder Blue', 'value' => '#B0C4DE']],
        'stock' => 18,
        'rating' => 4.4,
        'reviews' => 67,
        'badge' => 'New',
        'description' => 'A whisper-light organza blouse with voluminous sleeves and delicate pintuck detailing. Feminine, ethereal, and unexpectedly versatile.'
    ],
    [
        'id' => 'p11',
        'name' => 'High-Rise Tailored Shorts',
        'category' => 'Pants',
        'price' => 310,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1523381294911-8d3cead13475?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['XS', 'S', 'M', 'L'],
        'colors' => [['name' => 'Ecru', 'value' => '#F5F5DC'], ['name' => 'Noir', 'value' => '#000000'], ['name' => 'Camel', 'value' => '#D4A574']],
        'stock' => 20,
        'rating' => 4.6,
        'reviews' => 42,
        'badge' => null,
        'description' => 'Impeccably tailored high-rise shorts with a wide-leg cut. In a premium stretch-free cotton, these shorts are as polished as they are comfortable.'
    ],
    [
        'id' => 'p12',
        'name' => 'Gold Sculptural Earrings',
        'category' => 'Accessories',
        'price' => 185,
        'originalPrice' => null,
        'images' => [
            'https://images.unsplash.com/photo-1535632787350-4e68ef0ac584?auto=format&fit=crop&q=80&w=800',
            'https://images.unsplash.com/photo-1611085583191-a3b181a88401?auto=format&fit=crop&q=80&w=800'
        ],
        'sizes' => ['One Size'],
        'colors' => [['name' => 'Gold', 'value' => '#CFB53B']],
        'stock' => 25,
        'rating' => 4.9,
        'reviews' => 188,
        'badge' => 'New',
        'description' => 'Bold sculptural drop earrings hand-cast in 18k gold-plated brass. A single pair that transforms every outfit from understated to unforgettable.'
    ]
];

$categories = ['All', 'Dresses', 'Tops', 'Pants', 'Jackets', 'Shoes', 'Accessories'];

function get_product_by_id($id) {
    global $products;
    foreach ($products as $product) {
        if ($product['id'] === $id) {
            return $product;
        }
    }
    return null;
}
