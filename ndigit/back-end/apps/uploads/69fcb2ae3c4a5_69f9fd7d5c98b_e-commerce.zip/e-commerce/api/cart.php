<?php
session_start();
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

if ($action === 'add') {
    $item = [
        'id' => $input['id'],
        'name' => $input['name'],
        'price' => $input['price'],
        'image' => $input['image'],
        'size' => $input['size'] ?? '',
        'color' => $input['color'] ?? '',
        'quantity' => $input['quantity'] ?? 1,
    ];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    $found = false;
    foreach ($_SESSION['cart'] as &$cart_item) {
        if ($cart_item['id'] === $item['id'] && $cart_item['size'] === $item['size'] && $cart_item['color'] === $item['color']) {
            $cart_item['quantity'] += $item['quantity'];
            $found = true;
            break;
        }
    }

    if (!$found) {
        $_SESSION['cart'][] = $item;
    }

    echo json_encode(['success' => true]);
} elseif ($action === 'update') {
    $id = $input['id'];
    $size = $input['size'] ?? '';
    $color = $input['color'] ?? '';
    $quantity = $input['quantity'];

    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] === $id && $item['size'] === $size && $item['color'] === $color) {
                if ($quantity <= 0) {
                    $_SESSION['cart'] = array_filter($_SESSION['cart'], function($i) use ($id, $size, $color) {
                        return !($i['id'] === $id && $i['size'] === $size && $i['color'] === $color);
                    });
                } else {
                    $item['quantity'] = $quantity;
                }
                break;
            }
        }
    }

    echo json_encode(['success' => true]);
} elseif ($action === 'remove') {
    $id = $input['id'];
    $size = $input['size'] ?? '';
    $color = $input['color'] ?? '';

    if (isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array_filter($_SESSION['cart'], function($item) use ($id, $size, $color) {
            return !($item['id'] === $id && $item['size'] === $size && $item['color'] === $color);
        });
        $_SESSION['cart'] = array_values($_SESSION['cart']);
    }

    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
