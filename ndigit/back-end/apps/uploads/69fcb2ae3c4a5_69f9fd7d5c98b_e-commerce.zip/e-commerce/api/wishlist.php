<?php
session_start();
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

if ($action === 'toggle') {
    $id = $input['id'];
    $name = $input['name'] ?? '';

    if (!isset($_SESSION['wishlist'])) {
        $_SESSION['wishlist'] = [];
    }

    $index = array_search($id, $_SESSION['wishlist']);
    
    if ($index !== false) {
        unset($_SESSION['wishlist'][$index]);
        $_SESSION['wishlist'] = array_values($_SESSION['wishlist']);
        echo json_encode(['success' => true, 'message' => 'Removed from wishlist', 'added' => false]);
    } else {
        $_SESSION['wishlist'][] = $id;
        echo json_encode(['success' => true, 'message' => 'Added to wishlist ♡', 'added' => true]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
