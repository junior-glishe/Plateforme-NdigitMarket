<?php
$page_title = 'Contact Us';
require_once 'config.php';
require_once 'includes/header.php';

$success = isset($_GET['success']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submission
    header('Location: /contact.php?success=1');
    exit;
}
?>

<div class="pt-24 lg:pt-28 pb-20">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="mb-12">
            <h1 class="font-serif text-4xl sm:text-5xl font-bold mb-4">Contact Us</h1>
            <p class="text-muted-foreground">We'd love to hear from you. Get in touch with our team.</p>
        </div>

        <?php if ($success): ?>
        <div class="mb-8 p-4 bg-secondary/10 border border-secondary rounded-lg">
            <p class="text-secondary font-semibold">✓ Thank you! Your message has been sent successfully.</p>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
            <!-- Contact Form -->
            <div>
                <form method="POST" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">Name</label>
                        <input type="text" 
                               name="name" 
                               required
                               class="w-full border border-border rounded-md px-4 py-3 outline-none focus:border-primary">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Email</label>
                        <input type="email" 
                               name="email" 
                               required
                               class="w-full border border-border rounded-md px-4 py-3 outline-none focus:border-primary">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Subject</label>
                        <input type="text" 
                               name="subject" 
                               required
                               class="w-full border border-border rounded-md px-4 py-3 outline-none focus:border-primary">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Message</label>
                        <textarea name="message" 
                                  rows="5" 
                                  required
                                  class="w-full border border-border rounded-md px-4 py-3 outline-none focus:border-primary resize-none"></textarea>
                    </div>
                    <button type="submit" class="w-full h-12 bg-primary text-white font-semibold hover:bg-primary/90 rounded-md">
                        Send Message
                    </button>
                </form>
            </div>

            <!-- Contact Info -->
            <div class="space-y-8">
                <div>
                    <h3 class="font-serif text-xl font-bold mb-3">Customer Service</h3>
                    <p class="text-muted-foreground mb-2">Available Monday - Friday, 9am - 6pm EST</p>
                    <p class="text-foreground font-medium">support@maison.com</p>
                </div>

                <div>
                    <h3 class="font-serif text-xl font-bold mb-3">Visit Us</h3>
                    <p class="text-muted-foreground">
                        123 Fashion Avenue<br>
                        New York, NY 10001<br>
                        United States
                    </p>
                </div>

                <div>
                    <h3 class="font-serif text-xl font-bold mb-3">Follow Us</h3>
                    <div class="flex gap-4">
                        <a href="#" class="w-10 h-10 border border-border rounded-full flex items-center justify-center hover:border-primary transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
                        </a>
                        <a href="#" class="w-10 h-10 border border-border rounded-full flex items-center justify-center hover:border-primary transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 4s-7 0-10 6-4 8-4 8 3-1 6-4 6-7 6-7Z"/><path d="M2 20h5"/><path d="M9 20h6"/><path d="M14 20h5"/></svg>
                        </a>
                        <a href="#" class="w-10 h-10 border border-border rounded-full flex items-center justify-center hover:border-primary transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 17c0-6 0-9 .5-11.5a3 3 0 0 1 2-2C7.5 3 12 3 12 3s4.5 0 7 .5a3 3 0 0 1 2 2c.5 2.5.5 5.5.5 11.5s0 9-.5 11.5a3 3 0 0 1-2 2c-2.5.5-7 .5-7 .5s-4.5 0-7-.5a3 3 0 0 1-2-2C2.5 23 2.5 20 2.5 17Z"/><polygon points="10 15 15 12 10 9"/></svg>
                        </a>
                    </div>
                </div>

                <div class="p-6 bg-muted rounded-lg">
                    <h4 class="font-semibold mb-2">Quick Response Guarantee</h4>
                    <p class="text-sm text-muted-foreground">We typically respond to all inquiries within 24 hours during business days.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
