// Navbar scroll effect
let navbar = document.getElementById('navbar');
if (navbar) {
    window.addEventListener('scroll', function() {
        if (window.scrollY > 20) {
            navbar.classList.add('bg-white/95', 'backdrop-blur-md', 'shadow-sm');
        } else {
            navbar.classList.remove('bg-white/95', 'backdrop-blur-md', 'shadow-sm');
        }
    });
}

// Toggle mobile menu
function toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    const content = document.getElementById('mobile-menu-content');
    
    if (menu.style.display === 'none' || menu.style.display === '') {
        menu.style.display = 'block';
        setTimeout(() => {
            content.style.transform = 'translateX(0)';
        }, 10);
    } else {
        content.style.transform = 'translateX(-100%)';
        setTimeout(() => {
            menu.style.display = 'none';
        }, 300);
    }
}

// Toggle search
function toggleSearch() {
    const searchBar = document.getElementById('search-bar');
    searchBar.classList.toggle('hidden');
}

// Toggle cart
function toggleCart() {
    const drawer = document.getElementById('cart-drawer');
    const content = document.getElementById('cart-drawer-content');
    
    if (drawer.classList.contains('hidden')) {
        drawer.classList.remove('hidden');
        setTimeout(() => {
            content.classList.remove('translate-x-full');
        }, 10);
    } else {
        content.classList.add('translate-x-full');
        setTimeout(() => {
            drawer.classList.add('hidden');
        }, 300);
    }
}

// Cart functions
function addToCart(productId, name, price, image, size, color) {
    fetch('/api/cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'add',
            id: productId,
            name: name,
            price: price,
            image: image,
            size: size,
            color: color,
            quantity: 1
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Added to cart ✓', `${1}x ${name} added to your bag.`);
            location.reload();
        }
    })
    .catch(error => console.error('Error:', error));
}

function updateCartQuantity(id, size, color, quantity) {
    if (quantity <= 0) {
        removeFromCart(id, size, color);
        return;
    }
    
    fetch('/api/cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'update',
            id: id,
            size: size,
            color: color,
            quantity: quantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    })
    .catch(error => console.error('Error:', error));
}

function removeFromCart(id, size, color) {
    fetch('/api/cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'remove',
            id: id,
            size: size,
            color: color
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    })
    .catch(error => console.error('Error:', error));
}

// Wishlist functions
function toggleWishlist(productId, name) {
    fetch('/api/wishlist.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'toggle',
            id: productId,
            name: name
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast(data.message);
            location.reload();
        }
    })
    .catch(error => console.error('Error:', error));
}

// Toast notification
function showToast(title, description = '') {
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-4 right-4 bg-white border border-border rounded-lg shadow-lg p-4 z-50 max-w-sm animate-slide-in';
    toast.innerHTML = `
        <p class="font-medium text-sm">${title}</p>
        ${description ? `<p class="text-xs text-muted-foreground mt-1">${description}</p>` : ''}
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    .animate-slide-in {
        animation: slideIn 0.3s ease-out;
    }
`;
document.head.appendChild(style);
