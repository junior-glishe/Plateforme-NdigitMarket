<?php
$page_title = 'Shopping Cart';
require_once 'config.php';
require_once 'includes/header.php';

$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$cart_total = 0;
foreach ($cart_items as $item) {
    $cart_total += $item['price'] * $item['quantity'];
}
?>

<div class="pt-24 lg:pt-28 pb-20">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 class="font-serif text-4xl sm:text-5xl font-bold mb-8">Shopping Cart</h1>

        <?php if (empty($cart_items)): ?>
        <div class="text-center py-20">
            <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-auto mb-4 opacity-30"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            <p class="text-muted-foreground text-lg mb-4">Your cart is empty</p>
            <a href="/shop.php">
                <button class="bg-primary text-white px-8 py-3 rounded-md font-semibold hover:bg-primary/90">Continue Shopping</button>
            </a>
        </div>
        <?php else: ?>
        <div class="space-y-6">
            <?php foreach ($cart_items as $item): ?>
            <div class="flex gap-6 p-6 border border-border rounded-lg">
                <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>" class="w-24 h-28 object-cover rounded-md">
                <div class="flex-1">
                    <h3 class="font-semibold text-lg mb-1"><?php echo e($item['name']); ?></h3>
                    <?php if (isset($item['size'])): ?>
                    <p class="text-sm text-muted-foreground mb-2">Size: <?php echo e($item['size']); ?></p>
                    <?php endif; ?>
                    <p class="font-semibold text-lg"><?php echo format_price($item['price']); ?></p>
                    
                    <div class="flex items-center justify-between mt-4">
                        <div class="flex items-center gap-3 border border-border rounded-full px-3 py-2">
                            <button onclick="updateCartQuantity('<?php echo $item['id']; ?>', '<?php echo $item['size'] ?? ''; ?>', '<?php echo $item['color'] ?? ''; ?>', <?php echo $item['quantity'] - 1; ?>)" class="text-foreground/60 hover:text-foreground">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/></svg>
                            </button>
                            <span class="font-medium w-6 text-center"><?php echo $item['quantity']; ?></span>
                            <button onclick="updateCartQuantity('<?php echo $item['id']; ?>', '<?php echo $item['size'] ?? ''; ?>', '<?php echo $item['color'] ?? ''; ?>', <?php echo $item['quantity'] + 1; ?>)" class="text-foreground/60 hover:text-foreground">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
                            </button>
                        </div>
                        <button onclick="removeFromCart('<?php echo $item['id']; ?>', '<?php echo $item['size'] ?? ''; ?>', '<?php echo $item['color'] ?? ''; ?>')" class="text-muted-foreground hover:text-destructive transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                        </button>
                    </div>
                </div>
                <div class="text-right">
                    <p class="font-semibold text-lg"><?php echo format_price($item['price'] * $item['quantity']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="mt-12 p-8 border border-border rounded-lg bg-muted/30">
            <div class="flex items-center justify-between mb-6">
                <span class="text-lg">Subtotal</span>
                <span class="font-serif text-3xl font-bold"><?php echo format_price($cart_total); ?></span>
            </div>
            <?php if ($cart_total < 150): ?>
            <p class="text-sm text-muted-foreground mb-4 p-3 bg-secondary/10 rounded-md">
                Add <?php echo format_price(150 - $cart_total); ?> more for free shipping
            </p>
            <?php else: ?>
            <p class="text-sm text-secondary mb-4 p-3 bg-secondary/10 rounded-md font-semibold">
                ✓ You've unlocked free shipping!
            </p>
            <?php endif; ?>
            <a href="/checkout.php">
                <button class="w-full h-14 bg-primary text-white font-semibold tracking-wider hover:bg-primary/90 rounded-md">
                    Proceed to Checkout
                </button>
            </a>
            <a href="/shop.php" class="block mt-3">
                <button class="w-full h-12 border border-border rounded-md hover:bg-muted">
                    Continue Shopping
                </button>
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
