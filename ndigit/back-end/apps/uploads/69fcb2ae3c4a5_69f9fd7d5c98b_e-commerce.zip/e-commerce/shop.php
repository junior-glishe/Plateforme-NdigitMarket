<?php
$page_title = 'Shop - Luxury Fashion';
require_once 'config.php';
require_once 'includes/header.php';

// Filter and search logic
$category = isset($_GET['category']) ? $_GET['category'] : 'All';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'default';

$filtered = $products;

if ($category !== 'All') {
    $filtered = array_filter($filtered, function($p) use ($category) {
        return $p['category'] === $category;
    });
}

if ($search) {
    $filtered = array_filter($filtered, function($p) use ($search) {
        return stripos($p['name'], $search) !== false || stripos($p['description'], $search) !== false;
    });
}

if ($sort === 'price_low') {
    usort($filtered, function($a, $b) { return $a['price'] - $b['price']; });
} elseif ($sort === 'price_high') {
    usort($filtered, function($a, $b) { return $b['price'] - $a['price']; });
} elseif ($sort === 'rating') {
    usort($filtered, function($a, $b) { return $b['rating'] - $a['rating']; });
}
?>

<div class="pt-24 lg:pt-28 pb-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-12">
            <h1 class="font-serif text-4xl sm:text-5xl font-bold mb-4">Shop</h1>
            <p class="text-muted-foreground">Discover our curated collection of luxury pieces</p>
        </div>

        <div class="flex flex-col lg:flex-row gap-8">
            <!-- Sidebar filters -->
            <aside class="lg:w-64 flex-shrink-0">
                <div class="space-y-6">
                    <!-- Categories -->
                    <div>
                        <h3 class="font-semibold text-sm tracking-wider uppercase mb-3">Categories</h3>
                        <div class="space-y-2">
                            <?php foreach ($categories as $cat): ?>
                            <a href="?category=<?php echo urlencode($cat); ?>&sort=<?php echo e($sort); ?>" 
                               class="block text-sm <?php echo $category === $cat ? 'text-primary font-semibold' : 'text-foreground/70 hover:text-foreground'; ?> transition-colors">
                                <?php echo e($cat); ?>
                                <?php if ($cat !== 'All'): ?>
                                <span class="text-xs text-muted-foreground ml-1">
                                    (<?php echo count(array_filter($products, function($p) use ($cat) { return $p['category'] === $cat; })); ?>)
                                </span>
                                <?php endif; ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Sort -->
                    <div>
                        <h3 class="font-semibold text-sm tracking-wider uppercase mb-3">Sort By</h3>
                        <select onchange="window.location.href='?category=<?php echo urlencode($category); ?>&sort=' + this.value" 
                                class="w-full border border-border rounded-md px-3 py-2 text-sm outline-none focus:border-primary">
                            <option value="default" <?php echo $sort === 'default' ? 'selected' : ''; ?>>Default</option>
                            <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                            <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                            <option value="rating" <?php echo $sort === 'rating' ? 'selected' : ''; ?>>Highest Rated</option>
                        </select>
                    </div>
                </div>
            </aside>

            <!-- Products grid -->
            <div class="flex-1">
                <div class="mb-6 flex items-center justify-between">
                    <p class="text-sm text-muted-foreground"><?php echo count($filtered); ?> products</p>
                    
                    <!-- Search -->
                    <form class="flex gap-2">
                        <input type="search" 
                               name="search" 
                               placeholder="Search products..." 
                               value="<?php echo e($search); ?>"
                               class="border border-border rounded-md px-3 py-2 text-sm outline-none focus:border-primary w-48 sm:w-64">
                        <input type="hidden" name="category" value="<?php echo e($category); ?>">
                        <input type="hidden" name="sort" value="<?php echo e($sort); ?>">
                        <button type="submit" class="bg-primary text-white px-4 py-2 rounded-md text-sm hover:bg-primary/90">
                            Search
                        </button>
                    </form>
                </div>

                <?php if (empty($filtered)): ?>
                <div class="text-center py-20">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-auto mb-4 opacity-30"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    <p class="text-muted-foreground">No products found</p>
                    <a href="/shop.php" class="text-primary text-sm mt-2 inline-block underline">Clear filters</a>
                </div>
                <?php else: ?>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-8">
                    <?php foreach ($filtered as $product): ?>
                        <?php include 'includes/product-card.php'; ?>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
